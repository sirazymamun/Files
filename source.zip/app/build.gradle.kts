plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Injected by the GitHub workflow from apk-version.txt
val appVersion = providers.gradleProperty("appVersion").orElse("7.1.13").get()
val appVersionCode = providers.gradleProperty("appVersionCode").orElse("7010013").get().toInt()

android {
    namespace = "com.example.httpsserver"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.httpsserver"
        minSdk = 24
        targetSdk = 34
        versionCode = appVersionCode
        versionName = appVersion
    }

    val releaseStore = providers.environmentVariable("FILES_RELEASE_STORE_FILE").orNull
    if (!releaseStore.isNullOrBlank()) {
        signingConfigs {
            create("filesRelease") {
                storeFile = file(releaseStore)
                storePassword = providers.environmentVariable("FILES_RELEASE_STORE_PASSWORD").get()
                keyAlias = providers.environmentVariable("FILES_RELEASE_KEY_ALIAS").get()
                keyPassword = providers.environmentVariable("FILES_RELEASE_KEY_PASSWORD").get()
            }
        }
        buildTypes.getByName("release").signingConfig = signingConfigs.getByName("filesRelease")
    }
    buildTypes.getByName("release") {
        isDebuggable = false
        isMinifyEnabled = false
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.all { it.jvmArgs("--add-opens=java.base/java.io=ALL-UNNAMED"); it.systemProperty("robolectric.dependency.repo.url", "https://repo.maven.apache.org/maven2") }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources {
            excludes += "META-INF/versions/9/OSGI-INF/MANIFEST.MF"
            excludes += "META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
        }
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-auth:22.0.0")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.0.4")
    implementation("net.lingala.zip4j:zip4j:2.11.5")
    implementation("com.github.junrar:junrar:8.1.2")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.drawerlayout:drawerlayout:1.2.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.13")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("com.google.zxing:core:3.5.3")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
}
