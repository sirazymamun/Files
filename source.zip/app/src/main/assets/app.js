'use strict';
const CUR=JSON.parse(document.getElementById('currentPath').textContent);
const byId=id=>document.getElementById(id);
const STORAGE=JSON.parse(byId('currentStorage').textContent);
const storageUrl=url=>url+(url.includes('?')?'&':'?')+'storage='+encodeURIComponent(STORAGE);
byId('storageSelect').onchange=function(){location.href='/?storage='+encodeURIComponent(this.value);};
async function post(url,body){const r=await fetch(storageUrl(url),{method:'POST',headers:{'X-Requested-With':'tv2u'},body});const t=await r.text();if(!r.ok)throw new Error(t);return t;}
function mk(kind){const name=prompt(kind==='dir'?'Folder name':'File name');if(!name)return;const p=new URLSearchParams({path:CUR,name});if(kind==='file')p.set('content',prompt('Text to put in the file (optional)')||'');post(kind==='dir'?'/mkdir':'/mkfile',p).then(()=>{if(kind==='dir')location.href=storageUrl('/?path='+encodeURIComponent(CUR+'/'+name));else location.reload();}).catch(e=>alert(e.message));}
byId('uploadFiles').onclick=()=>byId('uf').click();byId('uploadFolder').onclick=()=>byId('ud').click();byId('newFolder').onclick=()=>mk('dir');byId('newFile').onclick=()=>mk('file');
byId('uf').onchange=function(){up(this.files);};byId('ud').onchange=function(){up(this.files);};
let renamePath='';
document.querySelectorAll('[data-rename]').forEach(button=>button.onclick=()=>{renamePath=button.dataset.rename;byId('renameName').value=button.dataset.name;byId('renameError').textContent='';byId('renameDialog').showModal();byId('renameName').select();});
byId('cancelRename').onclick=()=>byId('renameDialog').close();
byId('renameForm').onsubmit=async e=>{e.preventDefault();const name=byId('renameName').value.trim();if(!name||(name==='.'||name==='..')||/[\\/\x00-\x1f\x7f]/.test(name)){byId('renameError').textContent='Enter a name without a slash, control character, or dot-only path.';return;}byId('saveRename').disabled=true;try{await post('/rename',new URLSearchParams({path:renamePath,name}));location.reload();}catch(err){byId('renameError').textContent=err.message;}finally{byId('saveRename').disabled=false;}};
// Browser-only display settings; never alter server-side access controls.
const displayDefaults={showFolders:true,showFiles:true,hideEmptyFolders:false};
let displayPrefs={...displayDefaults};
try{const saved=JSON.parse(localStorage.getItem('files-server-display-v1')||'{}');for(const key of Object.keys(displayDefaults)){if(typeof saved[key]==='boolean')displayPrefs[key]=saved[key];}}catch(_){/* Default to showing both folders and files. */}
for(const key of Object.keys(displayDefaults)){
  const input=byId(key);input.checked=displayPrefs[key];
  input.addEventListener('change',()=>{displayPrefs[key]=input.checked;try{localStorage.setItem('files-server-display-v1',JSON.stringify(displayPrefs));}catch(_){}applyDisplayFilters();});
}
function applyDisplayFilters(){
  const q=byId('search').value.toLocaleLowerCase();let count=0;
  document.querySelectorAll('tr[data-file]').forEach(row=>{
    const folder=row.dataset.kind==='folder';
    const typeVisible=folder?displayPrefs.showFolders:displayPrefs.showFiles;
    const emptyHidden=folder&&displayPrefs.hideEmptyFolders&&row.dataset.emptyFolder==='true';
    row.hidden=!typeVisible||emptyHidden||!row.dataset.file.toLocaleLowerCase().includes(q);
    if(row.hidden){const checkbox=row.querySelector('.file-select');if(checkbox)checkbox.checked=false;}else count++;
  });
  byId('noResults').hidden=count!==0;
  byId('noResults').textContent=q?'No matching files or folders.':'No items match your display options.';
  updateSelection();
}
byId('search').oninput=applyDisplayFilters;

function up(files){const blocked=new Set(['android','lost.dir','system volume information','$recycle.bin','desktop.ini','thumbs.db','thumbcache.db']);const list=Array.from(files).filter(f=>!(f.webkitRelativePath||f.name).split('/').some(s=>s.startsWith('.')||blocked.has(s.toLowerCase())));if(!list.length)return;const box=byId('prog');box.textContent='';let i=0,failed=0;function next(){if(i>=list.length){if(failed){const done=document.createElement('div');done.textContent='Upload finished with '+failed+' error(s). Refresh to view uploaded files.';box.appendChild(done);}else setTimeout(()=>location.reload(),700);return;}const f=list[i++],rel=f.webkitRelativePath||f.name,row=document.createElement('div');row.textContent=rel+' 0%';box.appendChild(row);const fd=new FormData();fd.append('path',encodeURIComponent(CUR));fd.append('rel',encodeURIComponent(rel));fd.append('file',f);const x=new XMLHttpRequest();x.open('POST',storageUrl('/upload'));x.setRequestHeader('X-Requested-With','tv2u');x.upload.onprogress=e=>{if(e.lengthComputable)row.textContent=rel+' '+Math.round(e.loaded*100/e.total)+'%';};x.onload=()=>{if(x.status!==200)failed++;row.textContent=rel+(x.status===200?' — uploaded':' — failed: '+x.responseText);next();};x.onerror=()=>{failed++;row.textContent=rel+' — connection failed';next();};x.send(fd);}next();}
const dz=byId('drop');dz.ondragover=e=>{e.preventDefault();dz.classList.add('on');};dz.ondragleave=()=>dz.classList.remove('on');dz.ondrop=e=>{e.preventDefault();dz.classList.remove('on');const items=e.dataTransfer.items;if(!items){up(e.dataTransfer.files);return;}const files=[];let folders=false;for(const item of items){const entry=item.webkitGetAsEntry&&item.webkitGetAsEntry();if(entry&&entry.isDirectory){folders=true;continue;}if(item.kind==='file'){const f=item.getAsFile();if(f)files.push(f);}}if(folders)alert('For folders, use Upload folder.');up(files);};

// Explicit file/folder selection, named confirmation, and per-item deletion results.
const checkboxes=()=>Array.from(document.querySelectorAll('.file-select'));
const visibleChecks=()=>checkboxes().filter(c=>!c.closest('tr').hidden);
let deleting=false,pendingDelete=[];
function updateSelection(){const visible=visibleChecks(),selected=visible.filter(c=>c.checked);byId('selectedCount').textContent=selected.length+' selected';byId('deleteSelected').disabled=deleting||!selected.length;byId('clearSelection').disabled=deleting||!selected.length;byId('selectAll').checked=!!visible.length&&selected.length===visible.length;byId('selectAll').indeterminate=selected.length>0&&selected.length<visible.length;byId('selectAll').disabled=deleting||!visible.length;}
checkboxes().forEach(c=>c.onchange=updateSelection);
byId('selectAll').onchange=function(){visibleChecks().forEach(c=>c.checked=this.checked);updateSelection();};
byId('clearSelection').onclick=()=>{checkboxes().forEach(c=>c.checked=false);updateSelection();};
function askDelete(paths){if(deleting||!paths.length)return;if(paths.length>200){alert('Select at most 200 items at a time.');return;}pendingDelete=paths;byId('confirmDelete').disabled=false;byId('deleteSummary').textContent='Delete '+paths.length+' item'+(paths.length===1?'':'s')+'?' ;byId('deleteNames').replaceChildren();paths.forEach(path=>{const li=document.createElement('li');const selected=checkboxes().find(c=>c.dataset.path===path);li.textContent=(selected?.dataset.kind==='folder'?'Folder: ':'File: ')+path.split('/').pop();byId('deleteNames').appendChild(li);});byId('deleteError').textContent='';byId('deleteForm').dispatchEvent(new Event('submit',{cancelable:true,bubbles:true}));}
document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>askDelete([b.dataset.delete]));
byId('deleteSelected').onclick=()=>askDelete(visibleChecks().filter(c=>c.checked).map(c=>c.dataset.path));
byId('cancelDelete').onclick=()=>byId('deleteDialog').close();
byId('deleteDialog').addEventListener('cancel',e=>{if(deleting)e.preventDefault();});
byId('deleteForm').onsubmit=async e=>{e.preventDefault();if(deleting||!pendingDelete.length)return;deleting=true;byId('confirmDelete').disabled=true;byId('cancelDelete').disabled=true;byId('search').disabled=true;checkboxes().forEach(c=>c.disabled=true);document.querySelectorAll('[data-delete]').forEach(b=>b.disabled=true);updateSelection();byId('deleteError').textContent='Moving to Recycle Bin…';byId('deleteStatus').textContent='Moving to Recycle Bin…';
try{const body=new URLSearchParams({folder:CUR,confirm:'delete'});pendingDelete.forEach(path=>body.append('path',path));const data=JSON.parse(await post('/delete',body));let deleted=0;const failures=[];for(const result of data.results){if(result.deleted){deleted++;const c=checkboxes().find(c=>c.dataset.path===result.path);if(c)c.closest('tr').remove();}else failures.push(result.path.split('/').pop()+': '+result.message);}byId('deleteDialog').close();byId('deleteStatus').textContent=deleted+' item(s) moved to Recycle Bin.'+(failures.length?'\n'+failures.join('\n'):'');if(!document.querySelector('tr[data-file]')){const row=document.createElement('tr'),cell=document.createElement('td');cell.colSpan=4;cell.className='empty';cell.textContent='This folder is empty.';row.appendChild(cell);document.querySelector('tbody').appendChild(row);}byId('search').dispatchEvent(new Event('input'));const count=document.querySelector('.count');if(count)count.textContent=document.querySelectorAll('tr[data-file]').length+' items';}
catch(err){byId('deleteError').textContent='Deletion result could not be confirmed: '+err.message+'. Refresh the list before trying again.';byId('deleteStatus').textContent=byId('deleteError').textContent;}
finally{deleting=false;pendingDelete=[];byId('confirmDelete').disabled=true;byId('cancelDelete').disabled=false;byId('search').disabled=false;checkboxes().forEach(c=>c.disabled=false);document.querySelectorAll('[data-delete]').forEach(b=>b.disabled=false);updateSelection();}};
updateSelection();

// Two concurrent, bounded server scans. Listing remains interactive while sizes load.
async function loadFolderSizes(){
 const cells=Array.from(document.querySelectorAll('[data-folder-size]'));let next=0;
 const format=bytes=>{if(bytes<1024)return bytes+' B';const units=['KB','MB','GB','TB'];let n=bytes/1024,i=0;while(n>=1024&&i<units.length-1){n/=1024;i++;}return n.toFixed(1)+' '+units[i];};
 async function worker(){while(next<cells.length){const cell=cells[next++];const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),15000);
  try{const response=await fetch(storageUrl('/size?path='+encodeURIComponent(cell.dataset.folderSize)),{signal:controller.signal,cache:'no-store'});if(!response.ok)throw new Error('Size unavailable');const data=await response.json();if(!Number.isFinite(data.bytes)||data.bytes<0)throw new Error('Size unavailable');cell.textContent=format(data.bytes);cell.title=data.bytes+' bytes · '+data.files+' files (visible shared content)';}
  catch(_){cell.textContent='Unavailable';cell.title='Could not finish reading this folder. Refresh to retry.';}finally{clearTimeout(timer);}
 }}
 await Promise.all([worker(),worker()]);
}
loadFolderSizes();

applyDisplayFilters();
