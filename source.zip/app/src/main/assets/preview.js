'use strict';
(() => {
  const byId = id => document.getElementById(id);
  const data = byId('previewData').dataset;
  let busy = false;
  function navigate(direction) {
    if (busy) return;
    const link = byId(direction < 0 ? 'previousFile' : 'nextFile');
    if (link) location.assign(link.href);
  }
  byId('previewDelete').onclick = async () => {
    if (busy) return;
    busy = true;
    byId('previewDelete').disabled = true;
    byId('previewStatus').textContent = 'Moving to Recycle Bin…';
    try {
      // Close media streams before removing a file currently being previewed.
      document.querySelectorAll('video,audio').forEach(media => { media.pause(); media.removeAttribute('src'); media.load(); });
      const response = await fetch('/delete?storage=' + encodeURIComponent(data.storage), {
        method: 'POST', headers: {'X-Requested-With': 'tv2u'},
        body: new URLSearchParams({folder: data.folder, path: data.path, confirm: 'delete'})
      });
      if (!response.ok) throw new Error(await response.text());
      const result = (await response.json()).results?.find(item => item.path === data.path);
      if (!result?.deleted) throw new Error(result?.message || 'Deletion was not confirmed');
      byId('previewStatus').textContent = 'Moved to Recycle Bin.';
      location.replace(data.after);
    } catch (error) {
      byId('previewStatus').textContent = 'Could not confirm deletion: ' + error.message + '. Refresh before trying again.';
      busy = false;
      byId('previewDelete').disabled = false;
    }
  };
  document.addEventListener('keydown', e => {
    if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey ||
        e.target.closest?.('input,textarea,select,button,a,video,audio,iframe,[contenteditable]')) return;
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
      e.preventDefault(); navigate(e.key === 'ArrowLeft' ? -1 : 1);
    }
  });
  // Keep vertical page/text scrolling, pinch zoom and media controls available.
  let start = null;
  const preview = byId('previewContent');
  preview.addEventListener('touchstart', e => {
    start = (!window.visualViewport || window.visualViewport.scale === 1) && e.touches.length === 1 && !e.target.closest('video,audio,iframe,pre,a,button')
      ? {x: e.touches[0].clientX, y: e.touches[0].clientY} : null;
  }, {passive: true});
  preview.addEventListener('touchmove', e => { if (e.touches.length !== 1) start = null; }, {passive: true});
  preview.addEventListener('touchcancel', () => { start = null; }, {passive: true});
  preview.addEventListener('touchend', e => {
    if (!start || !e.changedTouches.length) return;
    const dx = e.changedTouches[0].clientX - start.x, dy = e.changedTouches[0].clientY - start.y;
    start = null;
    if (e.touches.length === 0 && Math.abs(dx) >= 65 && Math.abs(dx) > Math.abs(dy) * 1.5) navigate(dx < 0 ? 1 : -1);
  }, {passive: true});
})();
