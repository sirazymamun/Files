'use strict';
document.addEventListener('click',async event=>{
 const button=event.target.closest('[data-properties]');if(!button)return;
 const dialog=document.createElement('dialog');dialog.className='properties-dialog';
 const title=document.createElement('h2');title.textContent='Properties';
 const content=document.createElement('div');content.textContent='Reading properties…';
 const close=document.createElement('button');close.textContent='Close';close.onclick=()=>dialog.close();
 const copy=document.createElement('button');copy.textContent='Copy';copy.disabled=true;
 dialog.append(title,content,copy,close);document.body.append(dialog);dialog.addEventListener('close',()=>dialog.remove());dialog.showModal();close.focus();
 try{
  const storage=button.dataset.storage||new URLSearchParams(location.search).get('storage')||'primary';
  const response=await fetch('/properties?'+new URLSearchParams({path:button.dataset.properties,storage}),{cache:'no-store'});
  if(!response.ok)throw Error(await response.text());const data=await response.json();content.replaceChildren();const list=document.createElement('dl');
  for(const [key,value] of Object.entries(data)){const dt=document.createElement('dt');dt.textContent=key;const dd=document.createElement('dd');dd.textContent=String(value);list.append(dt,dd);}content.append(list);copy.disabled=false;
  copy.onclick=async()=>{try{await navigator.clipboard.writeText(Object.entries(data).map(([k,v])=>k+'\n'+v).join('\n\n'));copy.textContent='Copied';}catch{copy.textContent='Select text to copy';}};
 }catch(error){content.textContent=error.message;}
});
