package com.example.httpsserver

import android.util.Base64
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.ExtensionsGenerator
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder
import org.json.JSONObject
import java.io.IOException
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey

/** Minimal ACME v2 (RFC 8555) client for Let's Encrypt using the DNS-01 challenge. */
class AcmeClient(
    private val accountKey: KeyPair,
    var kid: String?,
    private val log: (String) -> Unit
) {
    private val dirUrl = "https://acme-v02.api.letsencrypt.org/directory"
    private var newNonceUrl = ""
    private var nonce: String? = null

    private class Resp(val code: Int, val body: String, val location: String?)

    private fun b64(b: ByteArray): String =
        Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    private fun unsigned(n: BigInteger): ByteArray {
        val a = n.toByteArray()
        return if (a.size > 1 && a[0] == 0.toByte()) a.copyOfRange(1, a.size) else a
    }

    private fun jwkJson(): String {
        val k = accountKey.public as RSAPublicKey
        return """{"e":"${b64(unsigned(k.publicExponent))}","kty":"RSA","n":"${b64(unsigned(k.modulus))}"}"""
    }

    private fun thumbprint(): String = b64(MessageDigest.getInstance("SHA-256").digest(jwkJson().toByteArray()))

    private fun request(method: String, url: String, body: String? = null, accept: String? = null): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", "tv2u-server/1.0")
        accept?.let { c.setRequestProperty("Accept", it) }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/jose+json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        c.getHeaderField("Replay-Nonce")?.let { nonce = it }
        return Resp(code, text, c.getHeaderField("Location"))
    }

    private fun errorDetail(body: String): String =
        runCatching { JSONObject(body).optString("detail", body) }.getOrDefault(body)

    private fun post(url: String, payload: String?, useJwk: Boolean = false, accept: String? = null): Resp {
        for (attempt in 0..2) {
            if (nonce == null) request("HEAD", newNonceUrl)
            val header = JSONObject().put("alg", "RS256").put("nonce", nonce!!).put("url", url)
            if (useJwk) header.put("jwk", JSONObject(jwkJson())) else header.put("kid", kid)
            val p = b64(header.toString().toByteArray())
            val pl = if (payload == null) "" else b64(payload.toByteArray())
            val sig = Signature.getInstance("SHA256withRSA").run {
                initSign(accountKey.private)
                update("$p.$pl".toByteArray())
                sign()
            }
            val body = JSONObject().put("protected", p).put("payload", pl).put("signature", b64(sig)).toString()
            nonce = null
            val r = request("POST", url, body, accept)
            if (r.code == 400 && r.body.contains("badNonce") && attempt < 2) continue
            if (r.code >= 400) throw IOException("Let's Encrypt: ${errorDetail(r.body)}")
            return r
        }
        throw IOException("Let's Encrypt: nonce error")
    }

    private fun failure(j: JSONObject): String {
        j.optJSONObject("error")?.let { return it.optString("detail") }
        val chs = j.optJSONArray("challenges")
        if (chs != null) for (i in 0 until chs.length()) {
            chs.optJSONObject(i)?.optJSONObject("error")?.let { return it.optString("detail") }
        }
        return "validation failed"
    }

    private fun poll(url: String, ok: Set<String>, tries: Int = 30): JSONObject {
        for (i in 0 until tries) {
            val j = JSONObject(post(url, null).body)
            val s = j.getString("status")
            if (s in ok) return j
            if (s == "invalid") throw IOException(failure(j))
            Thread.sleep(3000)
        }
        throw IOException("Timed out waiting for Let's Encrypt")
    }

    fun obtainCertificate(domain: String, publishTxt: (String) -> Unit): Pair<PrivateKey, List<X509Certificate>> {
        log("Contacting Let's Encrypt…")
        val dir = JSONObject(request("GET", dirUrl).body)
        newNonceUrl = dir.getString("newNonce")
        request("HEAD", newNonceUrl)

        if (kid == null) {
            kid = post(dir.getString("newAccount"), """{"termsOfServiceAgreed":true}""", useJwk = true).location
        }

        val order = post(dir.getString("newOrder"), """{"identifiers":[{"type":"dns","value":"$domain"}]}""")
        val orderUrl = order.location ?: throw IOException("Let's Encrypt: no order URL")
        val orderJson = JSONObject(order.body)
        val authzUrl = orderJson.getJSONArray("authorizations").getString(0)
        val finalizeUrl = orderJson.getString("finalize")

        val authz = JSONObject(post(authzUrl, null).body)
        if (authz.getString("status") != "valid") {
            val chs = authz.getJSONArray("challenges")
            var ch: JSONObject? = null
            for (i in 0 until chs.length()) if (chs.getJSONObject(i).getString("type") == "dns-01") ch = chs.getJSONObject(i)
            val challenge = ch ?: throw IOException("Let's Encrypt: no DNS challenge offered")
            val keyAuth = challenge.getString("token") + "." + thumbprint()
            val txt = b64(MessageDigest.getInstance("SHA-256").digest(keyAuth.toByteArray()))
            publishTxt(txt)
            log("Waiting for DNS…")
            Thread.sleep(5000)
            post(challenge.getString("url"), "{}")
            log("Validating domain…")
            poll(authzUrl, setOf("valid"))
        }

        poll(orderUrl, setOf("ready", "valid"), 10)

        log("Creating certificate…")
        val domainKey = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val ext = ExtensionsGenerator().apply {
            addExtension(Extension.subjectAlternativeName, false, GeneralNames(GeneralName(GeneralName.dNSName, domain)))
        }
        val csr = JcaPKCS10CertificationRequestBuilder(X500Name("CN=$domain"), domainKey.public)
            .addAttribute(PKCSObjectIdentifiers.pkcs_9_at_extensionRequest, ext.generate())
            .build(JcaContentSignerBuilder("SHA256withRSA").build(domainKey.private))
            .encoded
        post(finalizeUrl, """{"csr":"${b64(csr)}"}""")

        val done = poll(orderUrl, setOf("valid"))
        val certUrl = done.getString("certificate")
        val pem = post(certUrl, null, accept = "application/pem-certificate-chain").body
        val chain = CertificateFactory.getInstance("X.509")
            .generateCertificates(pem.byteInputStream())
            .map { it as X509Certificate }
        return Pair(domainKey.private, chain)
    }
}
