package com.example.httpsserver

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Tiny client for the public acme-dns service: lets the app publish DNS-01 challenges without any DNS password. */
object AcmeDns {
    private const val SERVER = "https://auth.acme-dns.io"

    data class Creds(val user: String, val pass: String, val sub: String, val full: String)

    private fun post(path: String, body: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(SERVER + path).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code >= 400) throw IOException("acme-dns error $code: $text")
        return text
    }

    fun register(): Creds {
        val j = JSONObject(post("/register", "{}"))
        return Creds(j.getString("username"), j.getString("password"), j.getString("subdomain"), j.getString("fulldomain"))
    }

    fun update(c: Creds, txt: String) {
        val body = JSONObject().put("subdomain", c.sub).put("txt", txt).toString()
        post("/update", body, mapOf("X-Api-User" to c.user, "X-Api-Key" to c.pass))
    }
}
