package com.example.httpsserver

import java.io.File
import java.io.IOException
import java.util.Properties
import java.util.UUID

/** Exports installer APKs only, including every split; never copies private app data. */
internal object ApkBackup {
 data class Source(val file:File,val size:Long=file.length(),val modified:Long=file.lastModified())
 data class Snapshot(val packageName:String,val label:String,val version:String,val versionCode:Long,val sources:List<Source>)
 fun safeName(value:String):String = value.replace(Regex("[^\\p{L}\\p{N}._ -]"),"_").trim().trim('.').take(90).ifBlank{"App"}
 // Resolve only Android's trusted Context.cacheDir alias; reject links beneath it.
 fun shareDirectory(cacheDir:File):File {
  val base=cacheDir.canonicalFile;require(base.isDirectory){"App cache is unavailable"}
  val parent=File(base,"app-shares");require(parent.canonicalFile==parent.absoluteFile){"Share folder is a link"}
  if(!parent.exists())check(parent.mkdir()){"Cannot create share folder"}
  require(parent.isDirectory && parent.canonicalFile==parent.absoluteFile){"Share folder is unavailable or a link"}
  val session=File(parent,UUID.randomUUID().toString());check(session.mkdir()){"Cannot create share session"}
  require(session.canonicalFile==session.absoluteFile){"Share session is a link"};return session
 }
 fun write(snapshot:Snapshot,folder:File):File {
  require(snapshot.sources.isNotEmpty()){"No installer files found"};require(folder.isDirectory && folder.canonicalFile==folder.absoluteFile){"Backup destination is unavailable or a link"}
  val paths=snapshot.sources.map{it.file.canonicalPath};require(paths.distinct().size==paths.size){"Duplicate APK parts"}
  fun unchanged(source:Source){check(source.size>0 && source.file.isFile && source.file.canRead() && source.file.length()==source.size && source.file.lastModified()==source.modified){"App changed or an APK part cannot be read. Refresh and retry."}}
  snapshot.sources.forEach(::unchanged)
  val required=snapshot.sources.fold(0L){total,item->Math.addExact(total,item.size)}
  if(folder.usableSpace>0)check(required<folder.usableSpace-16L*1024*1024){"Not enough free space for this backup"}
  val split=snapshot.sources.size>1
  var name=safeName(snapshot.label)+" "+safeName(snapshot.version.ifBlank{snapshot.versionCode.toString()});while(name.toByteArray(Charsets.UTF_8).size>180)name=name.dropLast(1)
  val temporary=File(folder,".FilesBackup-${UUID.randomUUID()}.part");check(if(split)temporary.mkdir()else temporary.createNewFile())
  val made=mutableListOf(temporary);var reserved:File?=null
  fun copy(source:Source,out:java.io.OutputStream){unchanged(source);source.file.inputStream().use{input->val b=ByteArray(65536);var copied=0L;while(true){if(Thread.currentThread().isInterrupted)throw IOException("Backup cancelled");val n=input.read(b);if(n<0)break;out.write(b,0,n);copied+=n};check(copied==source.size){"APK changed during backup"}};unchanged(source)}
  try {
   if(!split)temporary.outputStream().use{copy(snapshot.sources.first(),it)}
   else {
    snapshot.sources.forEachIndexed{index,source->
     val tag=java.security.MessageDigest.getInstance("SHA-256").digest(snapshot.packageName.toByteArray(Charsets.UTF_8)).take(6).joinToString(""){"%02x".format(it.toInt() and 255)}
     val part=File(temporary,name+"-"+tag+if(index==0)"-base.apk" else "-split_${index.toString().padStart(3,'0')}.apk")
     check(part.createNewFile());made.add(part);part.outputStream().use{copy(source,it)};part.setLastModified(source.modified)
    }
    val info=File(temporary,"backup.properties");check(info.createNewFile());made.add(info)
    Properties().apply{setProperty("package",snapshot.packageName);setProperty("name",snapshot.label);setProperty("versionName",snapshot.version);setProperty("versionCode",snapshot.versionCode.toString());setProperty("apkCount",snapshot.sources.size.toString());setProperty("format","Separate APK parts; install base and every split together; no app data")}.also{props->info.outputStream().use{props.store(it,"Files app backup")}}
   }
   snapshot.sources.forEach(::unchanged)
   var suffix=0
   while(true){val candidate=File(folder,name+(if(suffix==0)"" else " ($suffix)")+(if(split)"" else ".apk"));if(if(split)candidate.mkdir()else candidate.createNewFile()){reserved=candidate;break};suffix++;check(suffix<10000){"Too many files with this backup name"}}
   check(temporary.renameTo(reserved!!)){"Could not finish backup"}
   return reserved!!
  }catch(e:Exception){reserved?.delete();throw e}finally{made.asReversed().forEach{it.delete()}}
 }
 fun apkFiles(export:File):List<File> {
  val parts=if(export.isDirectory)export.listFiles()?.filter{it.extension.equals("apk",true)}?.sortedBy{it.name} ?: emptyList() else listOf(export)
  require(parts.isNotEmpty() && parts.all{it.isFile && it.canRead() && it.canonicalFile==it.absoluteFile && it.extension.equals("apk",true)}){"Exported APK parts are unavailable"}
  return parts
 }
 // The caller owns this newly created export. Do not recursively follow any directory/link.
 fun discard(export:File){if(export.isDirectory)export.listFiles()?.forEach{it.delete()};export.delete()}
}
