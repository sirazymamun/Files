package com.example.httpsserver

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File

/** Delegates a user-selected APK to Android's installer; never installs silently. */
class ApkInstallerActivity:Activity(){
 private lateinit var file:File
 private lateinit var root:File
 private var stage=0
 override fun onCreate(state:Bundle?){
  super.onCreate(state)
  root=File(intent.getStringExtra("root") ?: "");file=File(intent.getStringExtra("file") ?: "")
  stage=state?.getInt("stage") ?: 0
  if(!validate())return
  if(stage==0)requestInstall()
 }
 override fun onSaveInstanceState(out:Bundle){out.putInt("stage",if(stage==2 || stage==3)stage else 0);super.onSaveInstanceState(out)}
 private fun validate():Boolean=try{
  FileManagerOps(root,intent.getBooleanExtra("showHidden",false)).checked(file);require(file.isFile && file.canRead() && file.extension.equals("apk",true)){"Choose a readable APK file."};true
 }catch(e:Exception){error(e.message ?: "APK is unavailable");false}
 private fun requestInstall(){
  if(Build.VERSION.SDK_INT>=26 && !packageManager.canRequestPackageInstalls()){
   stage=1
   AlertDialog.Builder(this).setTitle("Allow APK installation").setMessage("Enable ‘Allow from this source’ for Files in Android settings, then return to continue installation.")
    .setPositiveButton("Allow"){_,_->try{stage=2;startActivityForResult(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:$packageName")),81)}catch(e:Exception){error("This device cannot open install permission settings. Check Android Settings → Apps → Special access → Install unknown apps.")}}
    .setNegativeButton("Cancel"){_,_->finish()}.setOnCancelListener{finish()}.show()
  }else launchInstaller()
 }
 private fun launchInstaller(){
  if(!validate())return
  try{val uri=FileProvider.getUriForFile(this,"$packageName.files",file)
   val request=Intent(Intent.ACTION_VIEW).setDataAndType(uri,APK_MIME).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
   request.clipData=ClipData.newRawUri(file.name,uri)
   stage=3;startActivityForResult(request,82)
  }catch(e:Exception){error("Android package installer could not open this APK. ${e.message ?: "No compatible installer is available on this device."}")}
 }
 private fun error(message:String){stage=4;AlertDialog.Builder(this).setTitle("Install APK").setMessage(message).setPositiveButton("Close"){_,_->finish()}.setOnCancelListener{finish()}.show()}
 @Deprecated("Platform result") override fun onActivityResult(request:Int,result:Int,data:Intent?){super.onActivityResult(request,result,data)
  if(request==81){if(Build.VERSION.SDK_INT<26 || packageManager.canRequestPackageInstalls())launchInstaller()else error("Installation permission was not allowed. You can try again after enabling ‘Allow from this source’ for Files.")}
  else if(request==82)finish()
 }
 companion object{
  const val APK_MIME="application/vnd.android.package-archive"
  fun open(activity:Activity,root:File,file:File,showHidden:Boolean=false){activity.startActivity(Intent(activity,ApkInstallerActivity::class.java).putExtra("showHidden",showHidden).putExtra("root",root.path).putExtra("file",file.path))}
 }
}
