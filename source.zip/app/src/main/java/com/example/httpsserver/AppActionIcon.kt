package com.example.httpsserver
import android.graphics.*
import android.graphics.drawable.Drawable
internal class AppActionIcon(private val action:String):Drawable(){
 private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE;strokeWidth=4f;strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND;style=Paint.Style.STROKE}
 override fun getIntrinsicWidth()=64
 override fun getIntrinsicHeight()=64
 override fun draw(c:Canvas){val save=c.save();c.translate(bounds.left.toFloat(),bounds.top.toFloat());c.scale(bounds.width()/64f,bounds.height()/64f)
  when(action){
   "Backup"->{c.drawRoundRect(14f,12f,50f,52f,3f,3f,p);c.drawRect(21f,13f,42f,27f,p);c.drawRect(22f,36f,43f,51f,p)}
   "Uninstall"->{c.drawLine(17f,20f,48f,20f,p);c.drawLine(25f,13f,40f,13f,p);c.drawRect(21f,21f,45f,51f,p);c.drawLine(29f,29f,29f,44f,p);c.drawLine(37f,29f,37f,44f,p)}
   "Share"->{for(x in listOf(19f to 32f,46f to 16f,46f to 48f))c.drawCircle(x.first,x.second,5f,p);c.drawLine(24f,29f,41f,19f,p);c.drawLine(24f,35f,41f,45f,p)}
   "Open"->{c.drawLine(14f,17f,14f,50f,p);c.drawLine(14f,50f,47f,50f,p);c.drawLine(47f,50f,47f,39f,p);c.drawLine(27f,38f,50f,14f,p);c.drawLine(34f,14f,50f,14f,p);c.drawLine(50f,14f,50f,30f,p)}
   "Store"->{c.drawRect(16f,27f,49f,51f,p);c.drawRect(23f,37f,32f,51f,p);c.drawLine(14f,25f,51f,25f,p);c.drawLine(18f,14f,47f,14f,p);c.drawLine(18f,14f,14f,25f,p);c.drawLine(47f,14f,51f,25f,p)}
   "Select all"->{c.drawRect(15f,15f,49f,49f,p);c.drawLine(22f,32f,29f,40f,p);c.drawLine(29f,40f,43f,23f,p)}
   "Close"->{c.drawLine(18f,18f,46f,46f,p);c.drawLine(18f,46f,46f,18f,p)}
  };c.restoreToCount(save)
 }
 override fun setAlpha(alpha:Int){p.alpha=alpha}
 override fun setColorFilter(filter:ColorFilter?){p.colorFilter=filter}
 @Deprecated("Platform") override fun getOpacity()=PixelFormat.TRANSLUCENT
}
