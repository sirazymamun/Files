package com.example.httpsserver
import java.io.File
import java.util.Locale
internal object ArchiveActions {
 fun supported(file:File)=file.isFile && file.extension.lowercase(Locale.ROOT) in setOf("zip","rar")
 fun canExtract(files:Collection<File>)=files.isNotEmpty() && files.all(::supported)
 fun folderName(file:File)=file.nameWithoutExtension.trim().ifBlank{"Archive"}.take(150)
 fun choices(files:List<File>)=listOf("Extract here",if(files.size==1)"Extract to \"${folderName(files.single())}/\"" else "Extract each to archive-name folder","Choose destination…")
}
