package com.example.httpsserver

import android.content.Context

/** Random six-digit numeric login password, kept on the phone. */
object Auth {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tv2u", Context.MODE_PRIVATE)

    @Synchronized
    fun password(ctx: Context): String {
        val stored = prefs(ctx).getString("web_pass", null)
        // Replace an old alphabetic / eight-digit password once; retain a valid six-digit password.
        return if (NumericPassword.isValid(stored)) stored!! else regenerate(ctx)
    }

    @Synchronized
    fun regenerate(ctx: Context): String {
        val password = NumericPassword.generate()
        prefs(ctx).edit().putString("web_pass", password).apply()
        return password
    }
}
