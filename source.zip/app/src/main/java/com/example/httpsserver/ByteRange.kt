package com.example.httpsserver

internal data class ByteRange(val start: Long, val end: Long) {
    companion object {
        fun parse(header: String, total: Long): ByteRange? {
            if (total <= 0) return null
            val m = Regex("bytes=([0-9]*)-([0-9]*)").matchEntire(header.trim()) ?: return null
            val first = m.groupValues[1]
            val last = m.groupValues[2]
            val start: Long
            val end: Long
            if (first.isEmpty()) {
                val suffix = last.toLongOrNull()?.takeIf { it > 0 } ?: return null
                start = (total - suffix).coerceAtLeast(0)
                end = total - 1
            } else {
                start = first.toLongOrNull() ?: return null
                end = if (last.isEmpty()) total - 1 else (last.toLongOrNull() ?: return null).coerceAtMost(total - 1)
            }
            return if (start >= 0 && start < total && end >= start) ByteRange(start, end) else null
        }
    }
}
