package com.example.httpsserver

import android.content.Context
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.Certificate
import java.security.cert.X509Certificate
import java.util.Date

object CertHelper {
    private const val ALIAS = "server"
    private val PASS = "changeit".toCharArray()

    fun localIp(): String? =
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
            ?.hostAddress

    private fun domainFile(ctx: Context) = File(ctx.filesDir, "domain.p12")

    private fun loadDomainStore(ctx: Context): KeyStore? {
        val f = domainFile(ctx)
        if (!f.exists()) return null
        return runCatching {
            KeyStore.getInstance("PKCS12").apply { f.inputStream().use { load(it, PASS) } }
        }.getOrNull()
    }

    /** Expiry of the trusted (Let's Encrypt) certificate, or null if there is none or it has expired. */
    fun domainCertExpiry(ctx: Context): Date? {
        val ks = loadDomainStore(ctx) ?: return null
        val cert = runCatching { ks.getCertificate(ALIAS) as X509Certificate }.getOrNull() ?: return null
        val valid = runCatching { cert.checkValidity(); true }.getOrDefault(false)
        val matching = cert.subjectAlternativeNames?.any {
            it.firstOrNull() == 2 && ServerDomain.matchesName(Provisioner.domain(ctx), it.getOrNull(1)?.toString() ?: "")
        } == true
        return if (valid && matching) cert.notAfter else null
    }

    fun saveDomainCert(ctx: Context, key: PrivateKey, chain: List<X509Certificate>) {
        require(chain.firstOrNull()?.subjectAlternativeNames?.any {
            it.firstOrNull() == 2 && ServerDomain.matchesName(Provisioner.domain(ctx), it.getOrNull(1)?.toString() ?: "")
        } == true) { "Certificate does not match the saved domain" }
        val ks = KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry(ALIAS, key, PASS, chain.toTypedArray<Certificate>())
        }
        domainFile(ctx).outputStream().use { ks.store(it, PASS) }
    }

    /** Uses the trusted domain certificate when available, otherwise a self-signed fallback. */
    fun loadOrCreate(ctx: Context): KeyStore {
        if (domainCertExpiry(ctx) != null) loadDomainStore(ctx)?.let { return it }

        val file = File(ctx.filesDir, "server.p12")
        val ip = localIp()
        if (file.exists()) {
            runCatching {
                val ks = KeyStore.getInstance("PKCS12").apply { file.inputStream().use { load(it, PASS) } }
                val cert = ks.getCertificate(ALIAS) as X509Certificate
                val soon = Date(System.currentTimeMillis() + 7L * 24 * 3600 * 1000)
                val sans = cert.subjectAlternativeNames?.map { it[1].toString() } ?: emptyList()
                if (cert.notAfter.after(soon) && (ip == null || ip in sans)) return ks
            }
        }
        return generate(ip).also { ks -> file.outputStream().use { ks.store(it, PASS) } }
    }

    private fun generate(ip: String?): KeyStore {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val name = X500Name("CN=tv2u server")
        val now = System.currentTimeMillis()

        val sans = mutableListOf(GeneralName(GeneralName.dNSName, "localhost"),
                                 GeneralName(GeneralName.iPAddress, "127.0.0.1"))
        ip?.let { sans += GeneralName(GeneralName.iPAddress, it) }

        val builder = JcaX509v3CertificateBuilder(
            name, BigInteger(64, SecureRandom()),
            Date(now - 60_000), Date(now + 365L * 24 * 3600 * 1000),
            name, kp.public
        ).addExtension(Extension.subjectAlternativeName, false, GeneralNames(sans.toTypedArray()))
         .addExtension(Extension.basicConstraints, true, BasicConstraints(false))

        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))

        return KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry(ALIAS, kp.private, PASS, arrayOf(cert))
        }
    }

    fun keyManagerFactory(ks: KeyStore): javax.net.ssl.KeyManagerFactory =
        javax.net.ssl.KeyManagerFactory.getInstance(javax.net.ssl.KeyManagerFactory.getDefaultAlgorithm())
            .apply { init(ks, PASS) }
}
