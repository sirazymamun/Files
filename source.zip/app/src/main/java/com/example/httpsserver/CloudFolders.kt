package com.example.httpsserver

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest

/** Manual, non-destructive sync through a user-granted Android document provider. */
internal object CloudFolders {
 data class Result(var added:Int=0,var same:Int=0)
 fun sync(context:Context,root:File,local:File,remote:DocumentFile,upload:Boolean,includeHidden:Boolean=false):Result {
  require(remote.uri.authority!=context.packageName+".documents"){"Files is local storage. Choose a separate cloud provider folder."}
  val ops=FileManagerOps(root,includeHidden);ops.checked(local,true);require(local.isDirectory && remote.isDirectory && remote.canRead()){"Choose accessible local and cloud folders"};if(upload)require(remote.canWrite()){"Cloud folder is read-only"}
  if(remote.uri.authority=="com.android.externalstorage.documents"){
   val id=android.provider.DocumentsContract.getTreeDocumentId(remote.uri);val volume=id.substringBefore(':');val relative=id.substringAfter(':',"")
   val base=if(volume=="primary")android.os.Environment.getExternalStorageDirectory() else File("/storage/$volume")
   val actual=File(base,relative).canonicalFile;val here=local.canonicalFile
   require(actual!=here && !actual.path.startsWith(here.path+"/") && !here.path.startsWith(actual.path+"/")){"Local and provider folders overlap. Choose a separate destination."}
  }
  val result=Result();val policy=SharedFiles(root,includeHidden);var entries=0;var bytes=0L;val start=System.nanoTime();val seen=mutableSetOf<String>();val resolver=context.contentResolver
  fun budget(n:Int=0){bytes+=n;check(!Thread.currentThread().isInterrupted && entries<10000 && bytes<=8L*1024*1024*1024 && System.nanoTime()-start<600000000000L){"Sync limit reached; completed files were kept"}}
  fun hash(input:InputStream):ByteArray {val digest=MessageDigest.getInstance("SHA-256");input.use{val b=ByteArray(65536);while(true){val n=it.read(b);if(n<0)break;budget(n);digest.update(b,0,n)}};return digest.digest()}
  fun equal(file:File,document:DocumentFile):Boolean {
   if(!file.isFile || !document.isFile || file.length()!=document.length())return false
   return hash(file.inputStream()).contentEquals(hash(resolver.openInputStream(document.uri) ?: throw IOException("Cloud file cannot be read")))
  }
  fun cloudName(parent:DocumentFile,name:String):String {if(parent.findFile(name)==null)return name;val dot=name.lastIndexOf('.');val base=if(dot>0)name.substring(0,dot)else name;val ext=if(dot>0)name.substring(dot)else "";var i=1;var next:String;do{next="$base (copy $i)$ext";i++}while(parent.findFile(next)!=null);return next}
  fun localName(parent:File,name:String):File {var target=ops.child(parent,name);if(!target.exists())return target;val original=File(name);var i=1;do{target=ops.child(parent,original.nameWithoutExtension+" (copy ${i++})"+original.extension.let{if(it.isEmpty())"" else  ".$it"})}while(target.exists());return target}
  fun up(folder:File,cloud:DocumentFile,depth:Int){
   check(depth<=64){"Folder nesting limit"};ops.checked(folder,true);require(seen.add("local:"+folder.canonicalPath)){"Folder loop"}
   for(f in folder.listFiles() ?: throw IOException("Local folder unreadable")){
    budget();if(!policy.allowedPart(f.name) || f.absolutePath!=f.canonicalPath || policy.resolve(f.path.removePrefix(root.path))==null)continue;entries++
    val found=cloud.findFile(f.name)
    if(f.isDirectory){val child=if(found?.isDirectory==true)found else cloud.createDirectory(cloudName(cloud,f.name)) ?: throw IOException("Cannot create cloud folder");up(f,child,depth+1)}
    else if(f.isFile){if(found!=null && equal(f,found)){result.same++;continue};val name=cloudName(cloud,f.name);val child=cloud.createFile(FileDetails.mime(f),name) ?: throw IOException("Cannot create cloud file");try{f.inputStream().use{input->(resolver.openOutputStream(child.uri,"w") ?: throw IOException("Cloud output unavailable")).use{output->val b=ByteArray(65536);while(true){val n=input.read(b);if(n<0)break;budget(n);output.write(b,0,n)}}};result.added++}catch(e:Exception){child.delete();throw e}}
   }
  }
  fun down(cloud:DocumentFile,folder:File,depth:Int){
   check(depth<=64){"Folder nesting limit"};require(seen.add("cloud:"+cloud.uri)){"Cloud folder loop"}
   for(doc in cloud.listFiles()){
    budget();entries++;val name=doc.name ?: throw IOException("Cloud item has no name");if(!policy.validName(name))continue
    val existing=ops.child(folder,name)
    if(doc.isDirectory){val target=if(existing.isDirectory)existing else localName(folder,name).apply{check(mkdir()){"Cannot create local folder"}};down(doc,target,depth+1)}
    else if(doc.isFile){if(existing.exists() && equal(existing,doc)){result.same++;continue};val target=localName(folder,name);check(target.createNewFile());try{(resolver.openInputStream(doc.uri) ?: throw IOException("Cloud input unavailable")).use{input->target.outputStream().use{output->val b=ByteArray(65536);while(true){val n=input.read(b);if(n<0)break;budget(n);output.write(b,0,n)}}};result.added++}catch(e:Exception){target.delete();throw e}}
   }
  }
  if(upload)up(local,remote,0)else down(remote,local,0)
  return result
 }
}
