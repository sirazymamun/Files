package com.example.httpsserver

internal object ConnectionInfo {
    fun addresses(ipAddress: String, domainAddress: String): String =
        "IP: $ipAddress\nDomain: $domainAddress"
    fun text(address: String, password: String): String = "$address\nPassword: $password"
}
