package com.example.httpsserver

import java.io.*
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CancellationException

internal class DriveTransfers(private val remote:DriveRemote,private val root:File,private val hidden:Boolean=false,private val cancelled:()->Boolean={false},private val progress:(String)->Unit={}){
 data class Result(var copied:Int=0,var same:Int=0,var skipped:Int=0)
 private val ops=FileManagerOps(root,hidden);private val policy=SharedFiles(root,hidden);private var entries=0;private var bytes=0L;private val started=System.nanoTime();private val result=Result();private val seen=mutableSetOf<String>();private val listings=mutableMapOf<String,MutableList<DriveItem>>()
 fun check(n:Int=0){bytes+=n;if(cancelled()||Thread.currentThread().isInterrupted)throw CancellationException("Transfer cancelled; completed files were kept")
  require(entries<=10000 && bytes<=8L*1024*1024*1024 && System.nanoTime()-started<1800000000000L){"Transfer limit reached. Completed files were kept."}}
 private fun md5(file:File):String{val d=MessageDigest.getInstance("MD5");file.inputStream().use{val b=ByteArray(65536);while(true){check();val n=it.read(b);if(n<0)break;d.update(b,0,n)}};return d.digest().joinToString(""){"%02x".format(it.toInt() and 255)}}
 private fun name(base:String,exists:(String)->Boolean):String{if(!exists(base))return base;val dot=base.lastIndexOf('.');val stem=if(dot>0)base.substring(0,dot)else base;val ext=if(dot>0)base.substring(dot)else "";var i=1;while(i<=10000){val value="$stem (copy ${i++})$ext";if(!exists(value))return value};error("Too many duplicate names")}
 fun upload(files:List<File>,parent:String):Result{files.forEach{up(ops.checked(it),parent,0)};return result}
 private fun up(file:File,parent:String,depth:Int){
  check();require(depth<=64){"Folder nesting exceeds 64 levels"};ops.checked(file);require(seen.add("local:"+file.canonicalPath)){"Repeated source folder"};entries++;check();progress("Uploading ${file.name}")
  val siblings=listings.getOrPut(parent){remote.list(parent).toMutableList()};val same=siblings.filter{it.name==file.name}
  if(file.isDirectory){val folder=if(same.size==1 && same[0].folder)same[0] else remote.mkdir(parent,name(file.name){n->siblings.any{it.name==n}}).also{siblings.add(it)}
   for(child in file.listFiles() ?: error("Local folder cannot be read")){if(child.absolutePath!=child.canonicalPath || policy.resolve(child.path.removePrefix(root.path))==null){result.skipped++;continue};up(child,folder.id,depth+1)}
  }else{require(file.isFile && file.canRead()){ "Source file unavailable" };val hash=md5(file);if(same.any{!it.folder && it.size==file.length() && it.md5?.equals(hash,true)==true}){result.same++;return}
   val length=file.length();require(bytes+length<=8L*1024*1024*1024){"Upload exceeds 8 GB operation limit"};val modified=file.lastModified();val made=remote.upload(parent,name(file.name){n->siblings.any{it.name==n}},file,FileDetails.mime(file),{check()},{sent->progress("Uploading ${file.name} · ${FileManagerOps.formatBytes(sent)} / ${FileManagerOps.formatBytes(length)}")})
   bytes+=length;check();require(file.length()==length && file.lastModified()==modified){"Source changed. Check the uploaded copy before retrying."};require(made.size==length && (made.md5==null || made.md5.equals(hash,true))){"Upload integrity check failed"};siblings.add(made);result.copied++
  }
 }
 fun download(items:List<DriveItem>,folder:File):Result{ops.checked(folder,true);require(folder.isDirectory && folder.canWrite()){ "Choose a writable local folder" };items.forEach{down(it,folder,0)};return result}
 private fun exportName(item:DriveItem):String{val ext=when(item.mime){"application/vnd.google-apps.document"->"docx";"application/vnd.google-apps.spreadsheet"->"xlsx";"application/vnd.google-apps.presentation"->"pptx";else->null};return if(ext==null||item.name.endsWith(".$ext",true))item.name else item.name+".$ext"}
 private fun down(item:DriveItem,parent:File,depth:Int){
  check();require(depth<=64){"Folder nesting exceeds 64 levels"};require(seen.add("drive:"+item.id)){"Repeated Drive item"};entries++;check();val base=exportName(item)
  if(!policy.validName(base)){result.skipped++;return};val existing=ops.child(parent,base);progress("Downloading $base")
  if(item.folder){val dest=if(existing.isDirectory)existing else ops.child(parent,name(base){File(parent,it).exists()}).apply{check(mkdir()){ "Cannot create folder" }}
   remote.list(item.id).forEach{down(it,dest,depth+1)}
  }else{if(existing.isFile && item.md5!=null && item.size==existing.length() && item.md5.equals(md5(existing),true)){result.same++;return}
   val dest=ops.child(parent,name(base){File(parent,it).exists()});val stage=File(parent,".FilesDrive-${UUID.randomUUID()}.part");require(stage.createNewFile()){ "Cannot start local download" }
   try{val digest=MessageDigest.getInstance("MD5");stage.outputStream().use{out->val checked=object:OutputStream(){override fun write(b:Int){out.write(b);digest.update(b.toByte())};override fun write(b:ByteArray,off:Int,len:Int){out.write(b,off,len);digest.update(b,off,len)}};remote.download(item,checked){n->check(n)}}
    if(!item.workspace){require(stage.length()==item.size){"Incomplete download"};val hash=digest.digest().joinToString(""){"%02x".format(it.toInt() and 255)};require(item.md5==null || item.md5.equals(hash,true)){"Download integrity check failed"}}
    check();ops.checked(parent,true);require(!dest.exists()){ "Destination changed; retry download" };java.nio.file.Files.move(stage.toPath(),dest.toPath());result.copied++
   }finally{stage.delete()}
  }
 }
}
