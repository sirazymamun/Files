package com.example.httpsserver

import java.io.File
import java.io.IOException

/** Explicit selection only. Never remove a root, follow links, or erase protected contents. */
internal class FileDeletion(base: File, private val maxEntries: Int = 100000, private val timeoutMillis: Long = 20000) {
    private val root = base.canonicalFile
    private val shared = SharedFiles(root)
    data class Result(val path: String, val deleted: Boolean, val message: String)
    private data class Entry(val file: File, val directory: Boolean, val length: Long, val modified: Long, val children: Set<String>)

    fun delete(folder: String, paths: List<String>): List<Result> {
        require(paths.isNotEmpty() && paths.size <= 200) { "Select between 1 and 200 items" }
        require(maxEntries > 0 && timeoutMillis > 0)
        val dir = shared.resolve(folder)
        require(dir != null && dir.isDirectory) { "Shared folder not found" }
        val started = System.nanoTime()
        var inspected = 0
        fun checkBudget() {
            if (Thread.currentThread().isInterrupted || System.nanoTime() - started > timeoutMillis.coerceAtMost(60000) * 1000000)
                throw IOException("Deletion timed out; refresh the folder before trying again")
        }
        fun accessible(file: File): Boolean {
            val canonical = file.canonicalFile
            return canonical == file.absoluteFile && canonical != root && shared.resolve(file.path.removePrefix(root.path)) == canonical
        }
        fun removeSelected(file: File) {
            val plan = mutableListOf<Entry>()
            fun inspect(item: File, depth: Int) {
                checkBudget()
                if (++inspected > maxEntries || depth > 128) throw IOException("Selection is too large or too deeply nested; nothing in this folder was deleted")
                if (!accessible(item)) throw IOException("Folder contains hidden/system items or symbolic links; nothing in this folder was deleted")
                if (!item.canRead()) throw IOException("Cannot read the entire folder; nothing in this folder was deleted")
                val isDir = item.isDirectory
                val children = if (isDir) item.listFiles() ?: throw IOException("Cannot read the entire folder; nothing in this folder was deleted") else emptyArray()
                if (!isDir && !item.isFile) throw IOException("An item is unavailable; nothing in this folder was deleted")
                val entry = Entry(item, isDir, item.length(), item.lastModified(), children.map { it.name }.toSet())
                for (child in children) inspect(child, depth + 1)
                plan.add(entry) // Children before their containing directory.
            }
            inspect(file, 0)
            // Validate the complete plan before the first destructive operation.
            for (entry in plan) {
                checkBudget()
                val item = entry.file
                if (!accessible(item) || item.isDirectory != entry.directory || item.lastModified() != entry.modified ||
                    (!entry.directory && (!item.isFile || item.length() != entry.length)) ||
                    (entry.directory && item.list()?.toSet() != entry.children))
                    throw IOException("Folder changed during preparation; nothing in this folder was deleted")
            }
            var removed = 0
            try {
                for (entry in plan) {
                    checkBudget()
                    val item = entry.file
                    if (!accessible(item) || item.isDirectory != entry.directory ||
                        (!entry.directory && (!item.isFile || item.length() != entry.length || item.lastModified() != entry.modified)) ||
                        (entry.directory && item.list()?.isNotEmpty() != false))
                        throw IOException("Folder changed or an item became unavailable")
                    if (!item.delete()) throw IOException("Android denied deletion; check permission or read-only storage")
                    removed++
                }
            } catch (e: IOException) {
                if (removed > 0) throw IOException("Folder partially deleted; refresh before retrying. ${e.message}")
                throw e
            }
        }
        return paths.distinct().map { path ->
            try {
                checkBudget()
                val parts = shared.segments(path)
                var file = root
                for (part in parts ?: emptyList()) file = File(file, part)
                val resolved = shared.resolve(path)
                when {
                    parts.isNullOrEmpty() || resolved == null || resolved == root -> Result(path, false, "This item is not shared")
                    file.absoluteFile != resolved -> Result(path, false, "Symbolic links cannot be deleted here")
                    file.parentFile != dir -> Result(path, false, "Choose an item in the current folder")
                    !file.exists() -> Result(path, false, "Item no longer exists; refresh the list")
                    else -> { removeSelected(file); Result(path, true, "Deleted") }
                }
            } catch (e: IOException) {
                Result(path, false, e.message ?: "Unable to delete this item; refresh and check permission")
            } catch (_: Exception) {
                Result(path, false, "Unable to delete this item; refresh and check permission")
            }
        }
    }
}
