package com.example.httpsserver

import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.system.Os
import android.webkit.MimeTypeMap
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

internal object FileDetails {
    fun date(millis: Long): String = if (millis <= 0) "Unavailable" else SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(millis))
    fun mime(file: File): String = when(file.extension.lowercase(Locale.ROOT)) {
        "apk" -> ApkInstallerActivity.APK_MIME
        "doc" -> "application/msword"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xls" -> "application/vnd.ms-excel"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "ppt" -> "application/vnd.ms-powerpoint"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "odt" -> "application/vnd.oasis.opendocument.text"
        "ods" -> "application/vnd.oasis.opendocument.spreadsheet"
        "odp" -> "application/vnd.oasis.opendocument.presentation"
        "pdf" -> "application/pdf"
        "txt" -> "text/plain"
        "csv" -> "text/csv"
        "rtf" -> "application/rtf"
        else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase(Locale.ROOT)) ?: "application/octet-stream"
    }
    fun describe(root: File, file: File,includeHidden:Boolean=false): LinkedHashMap<String,String> {
        FileManagerOps(root,includeHidden).checked(file,true)
        require(file.exists()) { "Item no longer exists" }
        val result=linkedMapOf("Name" to file.name,"Type" to if(file.isDirectory) "Folder" else mime(file),"Path" to file.canonicalPath,
            "Modified" to date(file.lastModified()),"Time zone" to TimeZone.getDefault().id,
            "Readable" to file.canRead().toString(),"Writable" to file.canWrite().toString(),"Hidden" to file.isHidden.toString())
        runCatching { Os.stat(file.path) }.getOrNull()?.let {
            result["Accessed"]=date(it.st_atime*1000);result["Metadata changed"]=date(it.st_ctime*1000)
            result["Permissions (octal)"]=Integer.toOctalString(it.st_mode and 511)
        }
        result["Created"]="Not reliably available from Android shared storage"
        if(file.isDirectory){
            result["Visible immediate items"]=file.listFiles()?.count { SharedFiles(root,includeHidden).allowedPart(it.name) && runCatching { FileManagerOps(root,includeHidden).checked(it);true }.getOrDefault(false) }?.toString() ?: "Unavailable"
            runCatching { FolderSize.measure(root,file,includeHidden=includeHidden) }.onSuccess { result["Visible content size"]="${FileManagerOps.formatBytes(it.bytes)} (${it.bytes} bytes)";result["Visible files (recursive)"]=it.files.toString() }.onFailure { result["Visible content size"]="Unavailable: ${it.message}" }
        } else {
            result["Size"]="${FileManagerOps.formatBytes(file.length())} (${file.length()} bytes)";result["Extension"]=file.extension.ifEmpty { "None" }
            val category=FileManagerOps.category(file)
            if(category=="Images"){
                val options=BitmapFactory.Options().apply { inJustDecodeBounds=true };BitmapFactory.decodeFile(file.path,options)
                if(options.outWidth>0 && options.outHeight>0){result["Resolution (width × height)"]="${options.outWidth} × ${options.outHeight} px";result["Image MIME"]=options.outMimeType ?: mime(file)}
                runCatching { ExifInterface(file.path) }.getOrNull()?.let { exif ->
                    val rotation=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,1)
                    result["EXIF orientation"]=rotation.toString()
                    if(rotation in setOf(5,6,7,8) && options.outWidth>0)result["Display resolution"]="${options.outHeight} × ${options.outWidth} px"
                    for((tag,label) in listOf(ExifInterface.TAG_DATETIME to "Capture date (EXIF)",ExifInterface.TAG_MAKE to "Camera make",ExifInterface.TAG_MODEL to "Camera model",ExifInterface.TAG_F_NUMBER to "Aperture",ExifInterface.TAG_EXPOSURE_TIME to "Exposure seconds",ExifInterface.TAG_FOCAL_LENGTH to "Focal length"))exif.getAttribute(tag)?.let { result[label]=it }
                }
                if(options.outWidth<=0)result["Resolution"]="Unavailable for this format or damaged file"
            }
            if(category in setOf("Videos","Audio")){
                val media=MediaMetadataRetriever()
                try {
                    media.setDataSource(file.path)
                    for((key,label) in listOf(MediaMetadataRetriever.METADATA_KEY_DURATION to "Duration (ms)",MediaMetadataRetriever.METADATA_KEY_BITRATE to "Bit rate (bits/s)",MediaMetadataRetriever.METADATA_KEY_MIMETYPE to "Media MIME",MediaMetadataRetriever.METADATA_KEY_TITLE to "Title",MediaMetadataRetriever.METADATA_KEY_ARTIST to "Artist",MediaMetadataRetriever.METADATA_KEY_ALBUM to "Album",MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION to "Rotation (degrees)"))media.extractMetadata(key)?.let { result[label]=it }
                    val w=media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);val h=media.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    if(w!=null && h!=null)result["Resolution (width × height)"]="$w × $h px"
                }catch(_: Exception){result["Media metadata"]="Unavailable for this format or damaged file"}finally{runCatching { media.release() }}
            }
        }
        return result
    }
    fun sha256(file: File): String {
        val digest=MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val b=ByteArray(65536);while(true){if(Thread.currentThread().isInterrupted)throw InterruptedException();val n=input.read(b);if(n<0)break;digest.update(b,0,n)} }
        return digest.digest().joinToString(""){"%02x".format(it.toInt() and 255)}
    }
}
