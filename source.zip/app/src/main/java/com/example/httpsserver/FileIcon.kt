package com.example.httpsserver
import android.graphics.*
import android.graphics.drawable.Drawable
internal class FileIcon(private val folder:Boolean,private val category:String):Drawable(){
 private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
 override fun draw(canvas:Canvas){val checkpoint=canvas.save();canvas.translate(bounds.left.toFloat(),bounds.top.toFloat());canvas.scale(bounds.width()/48f,bounds.height()/48f)
 if(folder){paint.color=Color.rgb(213,153,62);canvas.drawRoundRect(4f,8f,25f,22f,3f,3f,paint);paint.color=Color.rgb(236,182,86);canvas.drawRoundRect(3f,15f,45f,41f,4f,4f,paint)}else{paint.color=Color.rgb(222,238,240);canvas.drawRoundRect(9f,3f,39f,45f,4f,4f,paint);paint.color=Color.rgb(22,123,132);paint.textAlign=Paint.Align.CENTER;paint.textSize=when(category){"Apps","Archives"->10f;else->18f};paint.typeface=Typeface.DEFAULT_BOLD;canvas.drawText(when(category){"Images"->"▧";"Videos"->"▶";"Audio"->"♫";"Apps"->"APK";"Archives"->"ZIP";else->"≡"},24f,30f,paint)};canvas.restoreToCount(checkpoint)}
 override fun setAlpha(alpha:Int){paint.alpha=alpha};override fun setColorFilter(filter:ColorFilter?){paint.colorFilter=filter};@Deprecated("Platform") override fun getOpacity()=PixelFormat.TRANSLUCENT
}
