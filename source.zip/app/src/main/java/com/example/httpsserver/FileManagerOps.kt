package com.example.httpsserver

import java.io.File
import java.io.IOException
import java.util.Locale

/** All local writes use the same shared-storage boundary as the HTTP server. */
internal class FileManagerOps(val root: File,private val includeHidden:Boolean=false) {
    private val policy = SharedFiles(root,includeHidden)
    fun checked(file: File, allowRoot: Boolean = false): File {
        val f = file.canonicalFile
        require(file.absolutePath == f.path) { "Links are not supported" }
        require((allowRoot || f != root.canonicalFile) && policy.resolve(f.path.removePrefix(root.canonicalPath)) == f) { "This location is protected" }
        return f
    }
    fun child(parent: File, name: String): File {
        checked(parent, true)
        require(parent.isDirectory && policy.validName(name)) { "Invalid name or destination" }
        return checked(File(parent, name))
    }
    fun rename(file: File, name: String) {
        val source = checked(file); val dest = child(source.parentFile!!, name)
        require(!dest.exists()) { "A file or folder already has that name" }
        check(source.renameTo(dest)) { "Rename failed. Check storage permissions." }
    }
    fun transfer(source: File, destination: File, move: Boolean, destinationRoot: File = root) {
        val src = checked(source); val destinationOps = FileManagerOps(destinationRoot,includeHidden); destinationOps.checked(destination, true)
        require(destination.isDirectory) { "Choose a destination folder" }
        val dest = destinationOps.child(destination, src.name)
        require(!dest.exists()) { "${src.name}: destination already exists" }
        require(dest != src && !dest.path.startsWith(src.path + File.separator)) { "Cannot place a folder inside itself" }
        // Preflight the whole subtree before a move/copy; never copy hidden/system children or links.
        val plan = mutableListOf<File>(); val start = System.nanoTime()
        fun visit(f: File, depth: Int) {
            check(depth <= 128 && plan.size < 100000 && System.nanoTime()-start < 20000000000L) { "Folder is too large for this operation" }
            checked(f); check(f.canRead()) { "Cannot read ${f.name}" }; plan.add(f)
            if (f.isDirectory) (f.listFiles() ?: throw IOException("Cannot read folder")).forEach { visit(it,depth+1) }
            else check(f.isFile) { "Unsupported item" }
        }
        visit(src,0)
        // A same-volume rename avoids a partial copy/delete operation.
        if (move && src.renameTo(dest)) return
        val snapshot = plan.associateWith { Triple(it.length(), it.lastModified(), if(it.isDirectory) it.list()?.toSet() else null) }
        val made = mutableListOf<File>()
        try {
            for (item in plan) {
                checked(item)
                val target = if (item == src) dest else File(dest, item.path.removePrefix(src.path + File.separator))
                destinationOps.checked(target)
                if (item.isDirectory) { check(target.mkdir()) { "Cannot create destination folder" }; made.add(target) }
                else {
                    check(target.createNewFile()) { "Destination already exists" }; made.add(target)
                    item.inputStream().use { input -> target.outputStream().use { output -> input.copyTo(output, 65536) } }
                    check(target.length() == snapshot.getValue(item).first && item.length() == snapshot.getValue(item).first && item.lastModified() == snapshot.getValue(item).second) { "Source changed during copy" }
                    target.setLastModified(item.lastModified())
                }
            }
            made.filter { it.isDirectory }.asReversed().forEach { it.setLastModified(File(src, it.path.removePrefix(dest.path).trimStart('/')).lastModified()) }
        } catch (e: Exception) {
            // Only remove files created by this operation, never overwrite or delete pre-existing data.
            made.asReversed().forEach { runCatching { it.delete() } }; throw e
        }
        if (move) {
            fun unchanged(item: File): Boolean {
                val before = snapshot.getValue(item)
                return item.lastModified() == before.second &&
                    (if (item.isDirectory) item.list()?.toSet() == before.third else item.length() == before.first)
            }
            check(plan.all(::unchanged)) { "Copy complete, but the source changed. Original was kept." }
            // Remove only the entries we copied. A newly added child makes rmdir fail;
            // it must never get swept up by a new recursive deletion scan.
            for (item in plan.asReversed()) {
                checked(item)
                if (item.isFile) check(unchanged(item)) { "Source changed; remaining original files were kept" }
                check(item.delete()) { "Copy complete, but not all originals could be removed. Check both locations." }
            }
        }
    }
    companion object {
        fun category(file: File): String = when(file.extension.lowercase(Locale.ROOT)) {
            "jpg","jpeg","png","webp","gif","bmp","heic","heif","avif" -> "Images"
            "mp4","mkv","webm","avi","mov","m4v","3gp","ts" -> "Videos"
            "mp3","wav","ogg","m4a","aac","flac","opus" -> "Audio"
            "txt","pdf","doc","docx","xls","xlsx","ppt","pptx","csv","md","json","xml","log" -> "Documents"
            "apk","apks","xapk" -> "Apps"
            "zip","rar","7z","tar","gz" -> "Archives"
            else -> "Other"
        }
        fun formatBytes(n: Long): String {
            if(n<1024)return "$n B"
            var x=n.toDouble();val u=arrayOf("B","KB","MB","GB","TB");var i=0
            while(x>=1024 && i<u.lastIndex){x/=1024;i++}
            return String.format(Locale.US,"%.1f %s",x,u[i])
        }
    }
}
