package com.example.httpsserver

import android.content.Context
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.FileInputStream
import java.net.URLConnection
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HttpsServer(port: Int, private val ctx: Context, folder: File, private val requiresFullAccess: Boolean) : NanoHTTPD(port) {
    private val primaryRoot: File = folder.canonicalFile
    private val volumes = StorageAccess.volumes(ctx).also { check(it.first().folder == primaryRoot) }
    private val volumeScope = VolumeScope(volumes)
    private val root: File get() = volumeScope.current.folder
    private val storageId: String get() = volumeScope.current.id
    private val storageName: String get() = volumeScope.current.name
    // Each request has its own root; simultaneous browser users cannot change each other's storage.
    private fun scopedHtml(html: String): String = Regex("href=\"(/[^\"]*)\"").replace(html) {
        val url = it.groupValues[1]
        if (Regex("[?&](?:amp;)?storage=").containsMatchIn(url)) it.value else "href=\"$url${if ('?' in url) "&amp;" else "?"}storage=${enc(storageId)}\""
    }
    private val shared get() = SharedFiles(root)
    private fun allowedPart(name: String) = shared.allowedPart(name)
    private fun asset(name: String) = ctx.assets.open(name).bufferedReader().use { it.readText() }

    // ---------- helpers ----------
    private fun text(status: Response.IStatus, msg: String): Response =
        newFixedLengthResponse(status, "text/plain; charset=utf-8", msg)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")
    private fun IHTTPSession.p(k: String): String = parameters[k]?.firstOrNull() ?: ""

    private fun size(n: Long): String {
        if (n < 1024) return "$n B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = n.toDouble() / 1024
        var i = 0
        while (v >= 1024 && i < units.size - 1) { v /= 1024; i++ }
        return String.format(Locale.US, "%.1f %s", v, units[i])
    }

    private fun segments(rel: String) = shared.segments(rel)
    private fun resolve(rel: String) = shared.resolve(rel)
    private fun validName(name: String) = shared.validName(name)

    // ---------- password-only authentication ----------
    private val sessions = PasswordSessions()
    private fun cookie(s: IHTTPSession): String? = s.headers["cookie"]?.split(';')
        ?.map { it.trim().split('=', limit = 2) }
        ?.firstOrNull { it.size == 2 && it[0] == "tv2u_session" }?.get(1)
    private fun authorized(s: IHTTPSession) = sessions.valid(cookie(s), Auth.password(ctx))
    private fun redirect(cookieValue: String? = null): Response = newFixedLengthResponse(Status.REDIRECT_SEE_OTHER, "text/plain", "").apply {
        addHeader("Location", "/")
        addHeader("Cache-Control", "no-store")
        if (cookieValue != null) addHeader("Set-Cookie", cookieValue)
    }
    private fun loginPage(message: String = "", status: Response.IStatus = Status.OK): Response {
        val page = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unlock · Files</title><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="icon" type="image/png" href="/favicon.png"><style>body{font:16px system-ui,sans-serif;background:#f4f7fb;color:#172940;margin:0;min-height:100vh;display:grid;place-items:center}main{width:min(360px,85vw);background:white;border:1px solid #e6ebf2;border-radius:16px;padding:28px}h1{font-size:24px;margin:18px 0 12px}.brand{display:flex;align-items:center;gap:12px;font-weight:700}.brand img{width:82px;height:auto}p{color:#718096}label{display:block;margin-bottom:8px}input,button{box-sizing:border-box;font:inherit;width:100%;padding:12px;border-radius:8px;border:1px solid #c7d7df}button{margin-top:16px;background:#176e77;color:white;cursor:pointer}.error{color:#a12632}</style></head><body><main><div class="brand"><img src="/_logo.png" alt="tv2u"><span>Files</span></div><h1>Unlock files</h1><p>Enter the 6-digit password shown in the app.</p><form action="/login" method="post"><label for="password">Password</label><input id="password" name="password" type="password" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" autocomplete="current-password" required autofocus><p class="error" role="alert">${esc(message)}</p><button type="submit">Unlock</button></form></main></body></html>"""
        return newFixedLengthResponse(status, "text/html; charset=utf-8", page).apply {
            addHeader("Cache-Control", "no-store")
            addHeader("X-Content-Type-Options", "nosniff")
            addHeader("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        }
    }
    private fun login(s: IHTTPSession): Response {
        if (s.method != Method.POST) return loginPage()
        val client=s.remoteIpAddress ?: "unknown"
        if (sessions.blocked(client)) return loginPage("Too many attempts. Wait one minute and try again.", Status.FORBIDDEN)
        s.parseBody(HashMap())
        val token=sessions.login(client,s.p("password"),Auth.password(ctx))
            ?: return loginPage("Incorrect password. Enter the six digits shown in the app.", Status.UNAUTHORIZED)
        return redirect("tv2u_session=$token; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=43200")
    }

    // ---------- routing ----------
    override fun serve(session: IHTTPSession): Response = try {
        serveInStorage(session)
    } finally { volumeScope.clear() }

    private fun serveInStorage(session: IHTTPSession): Response {
        val response = route(session)
        // Error paths may return before consuming a POST body; do not reuse that socket.
        if (session.method != Method.GET && session.method != Method.HEAD && response.status.requestStatus >= 400) response.addHeader("Connection", "close")
        if (session.method != Method.HEAD) return response
        // NanoHTTPD 2.3.1 can send a body/negative length for HEAD on a chunked response.
        // A header-only wrapper omits the unknown length and never starts a ZIP download.
        return object : Response(response.status, response.mimeType, java.io.ByteArrayInputStream(ByteArray(0)), 0) {
            init {
                for (name in listOf("Content-Disposition", "Content-Range", "Accept-Ranges", "Cache-Control", "X-Content-Type-Options", "Content-Security-Policy")) {
                    response.getHeader(name)?.let { addHeader(name, it) }
                }
                response.close()
            }
            override fun setGzipEncoding(encodeAsGzip: Boolean) { /* No body for HEAD. */ }
            override fun sendContentLengthHeaderIfNotAlreadyPresent(writer: java.io.PrintWriter, defaultSize: Long): Long = 0
        }
    }

    private fun route(session: IHTTPSession): Response {
        if (session.uri == "/_logo.png" && (session.method == Method.GET || session.method == Method.HEAD))
            return newChunkedResponse(Status.OK, "image/png", ctx.resources.openRawResource(R.drawable.logo))
        if (session.method == Method.GET || session.method == Method.HEAD) when (session.uri) {
            "/favicon.svg" -> return newFixedLengthResponse(Status.OK, "image/svg+xml; charset=utf-8", asset("favicon.svg"))
            "/favicon.png", "/favicon.ico" -> return newChunkedResponse(Status.OK, "image/png", ctx.assets.open("favicon.png"))
        }
        if (session.uri == "/login") return try { login(session) }
            catch (_: Exception) { text(Status.BAD_REQUEST, "Unable to process login") }
        if (!authorized(session)) return if (session.method == Method.GET || session.method == Method.HEAD) loginPage()
            else text(Status.UNAUTHORIZED, "Session expired. Refresh the page and enter your password.")
        if (session.uri == "/logout" && session.method == Method.POST) {
            sessions.logout(cookie(session))
            return redirect("tv2u_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0")
        }
        if (requiresFullAccess && !StorageAccess.hasFullAccess(ctx)) {
            return text(Status.FORBIDDEN, "Device file permission was removed. Stop the server and allow access again.")
        }
        val selected = session.parameters["storage"]?.firstOrNull() ?: "primary"
        val volume = volumeScope.select(selected)
            ?: return text(Status.NOT_FOUND, "Storage not found. Stop and start the server after connecting SD / USB storage.")
        if (!volume.folder.isDirectory || !volume.folder.canRead())
            return text(Status.FORBIDDEN, "This storage is unavailable, unmounted, or permission was denied.")
        return try {
            when (session.method) {
                Method.GET, Method.HEAD -> when (session.uri) {
                    "/" -> listing(session)
                    "/dl" -> download(session)
                    "/zip" -> downloadFolder(session)
                    "/multi-zip" -> downloadSelection(session)
                    "/size" -> folderSize(session)
                    "/properties" -> fileProperties(session)
                    "/trash" -> trashList()
                    "/_recycle.js" -> newFixedLengthResponse(Status.OK, "application/javascript; charset=utf-8", asset("recycle.js"))
                    "/_properties.js" -> newFixedLengthResponse(Status.OK, "application/javascript; charset=utf-8", asset("properties.js"))
                    "/open" -> preview(session)
                    "/_app.css" -> newFixedLengthResponse(Status.OK, "text/css; charset=utf-8", asset("app.css"))
                    "/_preview.js" -> newFixedLengthResponse(Status.OK, "application/javascript; charset=utf-8", asset("preview.js"))
                    "/_app.js" -> newFixedLengthResponse(Status.OK, "application/javascript; charset=utf-8", asset("app.js"))
                    "/_folder.svg" -> newFixedLengthResponse(Status.OK, "image/svg+xml; charset=utf-8", asset("folder.svg"))
                    "/_file.svg" -> newFixedLengthResponse(Status.OK, "image/svg+xml; charset=utf-8", asset("file.svg"))
                    "/favicon.svg" -> newFixedLengthResponse(Status.OK, "image/svg+xml; charset=utf-8", asset("favicon.svg"))
                    "/favicon.png", "/favicon.ico" -> newChunkedResponse(Status.OK, "image/png", ctx.assets.open("favicon.png"))
                    "/_logo.png" -> newChunkedResponse(Status.OK, "image/png", ctx.resources.openRawResource(R.drawable.logo))
                    else -> text(Status.NOT_FOUND, "Not found")
                }
                Method.POST -> {
                    if (session.headers["x-requested-with"] != "tv2u") return text(Status.FORBIDDEN, "Forbidden")
                    when (session.uri) {
                        "/delete" -> deleteFiles(session)
                        "/trash" -> trashChange(session)
                        "/rename" -> rename(session)
                        "/mkdir" -> mkdir(session)
                        "/mkfile" -> mkfile(session)
                        "/upload" -> upload(session)
                        else -> text(Status.NOT_FOUND, "Not found")
                    }
                }
                else -> text(Status.METHOD_NOT_ALLOWED, "Method not allowed")
            }
        } catch (e: Exception) {
            text(Status.INTERNAL_ERROR, "Unable to complete the request. Check file permissions and try again.")
        }
    }

    // ---------- pages ----------
    private fun listing(s: IHTTPSession): Response {
        val dir = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "Forbidden")
        if (!dir.isDirectory) return text(Status.NOT_FOUND, "Folder not found")
        val cur = dir.path.removePrefix(root.path)

        val crumbs = StringBuilder("<a href=\"/\">${esc(storageName)}</a>")
        var acc = ""
        for (p in segments(cur) ?: emptyList()) {
            acc += "/$p"
            crumbs.append(" / <a href=\"/?path=${enc(acc)}\">${esc(p)}</a>")
        }

        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val all = dir.listFiles()
        // List all permitted entries, including empty folders. Browser display preferences
        // may hide rows, but they never grant access to protected content.
        val items = all?.filter { file ->
            shared.allowedPart(file.name) && (file.isFile || file.isDirectory) &&
                shared.resolve(file.path.removePrefix(root.path)) != null
        }
            ?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) })) ?: emptyList()
        val rows = StringBuilder()
        if (all == null) {
            rows.append("<tr><td class=\"empty\" colspan=\"4\">Can't read this folder. Check the file access permission.</td></tr>")
        } else {
            if (items.isEmpty()) rows.append("<tr><td class=\"empty\" colspan=\"4\">This folder is empty.</td></tr>")
            for (f in items) {
                val path = "$cur/${f.name}"
                val q = enc(path)
                val date = fmt.format(Date(f.lastModified()))
                val href = if (f.isDirectory) "/?path=$q" else "/open?path=$q"
                val icon = "<img class=\"entry-icon\" src=\"${if (f.isDirectory) "/_folder.svg" else "/_file.svg"}\" width=\"48\" height=\"48\" alt=\"\" aria-hidden=\"true\" decoding=\"async\">"
                val open = if (f.isDirectory) "<a class=\"button open\" href=\"$href\">Open</a>" else "<a class=\"button open\" href=\"$href\" target=\"_blank\" rel=\"noopener\">Open</a>"
                val download = if (f.isDirectory) "<a class=\"button\" href=\"/zip?path=$q\" title=\"Download folder as ZIP\">Download</a>" else "<a class=\"button\" href=\"/dl?path=$q\">Download</a>"
                val rename = "<button type=\"button\" data-rename=\"${esc(path)}\" data-name=\"${esc(f.name)}\">Rename</button>"
                val delete = "<button type=\"button\" class=\"danger\" data-delete=\"${esc(path)}\" data-name=\"${esc(f.name)}\">Delete</button>"
                val select = "<input type=\"checkbox\" class=\"file-select\" data-kind=\"${if (f.isDirectory) "folder" else "file"}\" data-path=\"${esc(path)}\" aria-label=\"Select ${esc(f.name)}\">"
                val target = if (f.isDirectory) "" else " target=\"_blank\" rel=\"noopener\""
                rows.append("<tr data-file=\"${esc(f.name)}\" data-kind=\"${if (f.isDirectory) "folder" else "file"}\" data-empty-folder=\"${if (f.isDirectory && !shared.visibleInListing(f)) "true" else "false"}\"><td class=\"name\"><div class=\"file-entry\">$select<a class=\"file-label\" href=\"$href\"$target>$icon<span>${esc(f.name)}</span></a></div></td><td class=\"size\"${if (f.isDirectory) " data-folder-size=\"${esc(path)}\"" else ""}>${if (f.isDirectory) "Calculating…" else if (f.canRead()) size(f.length()) else "Unavailable"}</td><td class=\"date\">$date</td><td class=\"action\">$open$rename$download$delete<button type=\"button\" data-properties=\"${esc(path)}\" data-storage=\"${esc(storageId)}\">Properties</button></td></tr>")
            }
        }
        // JSON is embedded in a script element: escape < to prevent a filename closing it.
        val safeCur = JSONObject.quote(cur).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
        val count = items.size
        val storageOptions = volumes.joinToString("") { volume ->
            "<option value=\"${esc(volume.id)}\"${if (volume.id == storageId) " selected" else ""}>${esc(volume.name)}</option>"
        }
        val values = mapOf("VOLUMES" to storageOptions, "STORAGE_ID" to JSONObject.quote(storageId), "CUR" to safeCur, "CRUMBS" to crumbs.toString(), "ROWS" to rows.toString(), "COUNT" to count.toString(), "STORAGE" to "${esc(storageName)} — shared files and media; protected system / private app data excluded")
        val html = Regex("%%(CUR|CRUMBS|ROWS|COUNT|STORAGE|VOLUMES|STORAGE_ID)%%").replace(asset("index.html")) { values[it.groupValues[1]] ?: "" }
        return newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", scopedHtml(html)).apply {
            addHeader("Cache-Control", "no-store")
        }
    }

    private fun mime(file: File): String {
        val ext = file.extension.lowercase(Locale.ROOT)
        return when (ext) {
            "txt", "log", "md", "csv", "kt", "java", "py", "yml", "yaml", "ini", "conf" -> "text/plain"
            "json" -> "application/json"
            "pdf" -> "application/pdf"
            "mp4", "m4v" -> "video/mp4"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "ogg", "oga" -> "audio/ogg"
            "wav" -> "audio/wav"
            "svg" -> "image/svg+xml"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: URLConnection.guessContentTypeFromName(file.name) ?: "application/octet-stream"
        }
    }

    private fun folderSize(s: IHTTPSession): Response {
        val item = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "This folder is not shared")
        if (!item.isDirectory) return text(Status.BAD_REQUEST, "Not a folder")
        if (!FolderSize.slots.tryAcquire()) return text(Status.SERVICE_UNAVAILABLE, "Folder size is busy")
        return try {
            val measured = FolderSize.measure(root, item)
            newFixedLengthResponse(Status.OK, "application/json; charset=utf-8", JSONObject().put("bytes", measured.bytes).put("files", measured.files).toString())
                .apply { addHeader("Cache-Control", "no-store") }
        } catch (_: Exception) {
            text(Status.BAD_REQUEST, "Folder size unavailable")
        } finally { FolderSize.slots.release() }
    }

    private fun trashList(): Response {
        val entries=JSONArray()
        for(item in TrashStore(root).entries())entries.put(JSONObject().put("id",item.id).put("path",item.original).put("deletedAt",FileDetails.date(item.deletedAt)).put("folder",item.folder))
        return newFixedLengthResponse(Status.OK,"application/json; charset=utf-8",JSONObject().put("entries",entries).toString()).apply {addHeader("Cache-Control","no-store")}
    }
    @Synchronized private fun trashChange(s:IHTTPSession):Response {
        s.parseBody(HashMap());val ids=s.parameters["id"] ?: emptyList()
        if(ids.isEmpty() || ids.size>200 || s.p("action") !in setOf("restore","purge"))return text(Status.BAD_REQUEST,"Choose 1 to 200 Bin items and an action")
        val store=TrashStore(root);val entries=store.entries().associateBy{it.id};val results=JSONArray()
        for(id in ids){val item=entries[id];try {require(item!=null){"Bin item no longer exists"};if(s.p("action")=="restore")store.restore(item)else store.purge(item);results.put(JSONObject().put("id",id).put("ok",true))}catch(e:Exception){results.put(JSONObject().put("id",id).put("ok",false).put("message",e.message ?: "Bin action failed"))}}
        return newFixedLengthResponse(Status.OK,"application/json; charset=utf-8",JSONObject().put("results",results).toString()).apply{addHeader("Cache-Control","no-store")}
    }

    private fun fileProperties(s: IHTTPSession): Response {
        val file = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "This item is not shared")
        if (!file.exists()) return text(Status.NOT_FOUND, "Item not found")
        return newFixedLengthResponse(Status.OK, "application/json; charset=utf-8", JSONObject(FileDetails.describe(root,file) as Map<*, *>).toString()).apply { addHeader("Cache-Control", "no-store") }
    }

    private fun preview(s: IHTTPSession): Response {
        val f = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "This item is not shared")
        if (!f.isFile || !f.canRead()) return text(Status.NOT_FOUND, "File not found")
        val type = mime(f)
        val src = "/dl?path=${enc(s.p("path"))}&amp;inline=1&amp;storage=${enc(storageId)}"
        val body = when {
            type.startsWith("image/") -> "<img src=\"$src\" alt=\"${esc(f.name)}\">"
            type.startsWith("video/") -> "<video controls playsinline preload=\"metadata\" src=\"$src\">Your browser cannot play this video.</video><p>Playback depends on your browser's codec support.</p>"
            type.startsWith("audio/") -> "<audio controls preload=\"metadata\" src=\"$src\">Your browser cannot play this audio.</audio>"
            type == "application/pdf" -> "<iframe title=\"PDF preview\" src=\"$src\"></iframe><p>If no preview appears, <a href=\"$src\" target=\"_blank\" rel=\"noopener\">open PDF directly</a>.</p>"
            type.startsWith("text/") || type == "application/json" || f.extension.lowercase(Locale.ROOT) in setOf("xml", "html", "htm", "js", "css") -> {
                val limit = 512 * 1024
                val content = f.inputStream().use { input ->
                    val bytes = ByteArray(minOf(f.length(), limit.toLong()).toInt())
                    var offset = 0
                    while (offset < bytes.size) {
                        val n = input.read(bytes, offset, bytes.size - offset)
                        if (n < 0) break
                        offset += n
                    }
                    String(bytes, 0, offset, Charsets.UTF_8)
                }
                "<pre>${esc(content)}</pre>" + if (f.length() > limit) "<p>Showing the first 512 KB.</p>" else ""
            }
            else -> "<p>This file type has no built-in browser preview. Use Download to open it in a compatible app.</p>"
        }
        val folder = f.parentFile!!.path.removePrefix(root.path)
        val current = f.path.removePrefix(root.path)
        val siblings = f.parentFile!!.listFiles()?.filter {
            it.isFile && it.canRead() && shared.visibleInListing(it)
        }?.sortedBy { it.name.lowercase(Locale.ROOT) } ?: emptyList()
        val index = siblings.indexOfFirst { it == f }
        fun neighbor(offset: Int): String = if (index >= 0) siblings.getOrNull(index + offset)?.let {
            "/open?path=${enc(it.path.removePrefix(root.path))}&storage=${enc(storageId)}"
        } ?: "" else ""
        val previous = neighbor(-1)
        val next = neighbor(1)
        fun nav(id: String, label: String, url: String) = if (url.isEmpty())
            "<span class=\"button disabled\" aria-disabled=\"true\">$label</span>" else
            "<a id=\"$id\" class=\"button\" href=\"${esc(url)}\">$label</a>"
        val navigation = nav("previousFile", "← Previous", previous) +
            "<span class=\"preview-count\">${if (index >= 0) index + 1 else 1} / ${siblings.size.coerceAtLeast(1)}</span>" + nav("nextFile", "Next →", next)
        // For images, place previous/next at the mid-height edges of the preview panel.
        // Keep the existing navigation for video, PDF and other file previews.
        val previewBody = if (type.startsWith("image/")) {
            val count = "${if (index >= 0) index + 1 else 1} / ${siblings.size.coerceAtLeast(1)}"
            "<div class=\"preview-count preview-image-count\">$count</div>" +
                "<div class=\"preview-frame\"><section id=\"previewContent\" class=\"panel preview\">$body</section>" +
                "<nav class=\"preview-nav preview-nav-sides\" aria-label=\"Images in this folder\">" +
                nav("previousFile", "← Previous", previous) + nav("nextFile", "Next →", next) +
                "</nav></div>"
        } else {
            "<nav class=\"preview-nav\" aria-label=\"Files in this folder\">$navigation</nav>" +
                "<section id=\"previewContent\" class=\"panel preview\">$body</section>"
        }
        val parent = enc(folder)
        val html = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(f.name)} · Files</title><link rel="icon" type="image/png" sizes="192x192" href="/favicon.png?v=7.0.2"><link rel="icon" type="image/svg+xml" sizes="any" href="/favicon.svg?v=7.0.2"><link rel="stylesheet" href="/_app.css"></head><body><header class="top"><div class="top-inner"><a class="brand" href="/"><img src="/_logo.png" alt="tv2u"><span>Files</span></a><span class="badge">File preview</span></div></header><main><a class="button" href="/?path=$parent">← Back to folder</a><h1>${esc(f.name)}</h1><p>${size(f.length())}</p>$previewBody<div class="preview-actions"><a class="button" href="/dl?path=${enc(s.p("path"))}">Download</a><button type="button" data-properties="${esc(current)}" data-storage="${esc(storageId)}">Properties</button><button id="previewDelete" class="danger" type="button">Delete</button></div><p id="previewStatus" role="status" aria-live="polite"></p><div id="previewData" hidden data-path="${esc(current)}" data-folder="${esc(folder)}" data-storage="${esc(storageId)}" data-name="${esc(f.name)}" data-after="${esc(next.ifEmpty { previous }.ifEmpty { "/?path=$parent&storage=${enc(storageId)}" })}"></div><script src="/_properties.js" defer></script><script src="/_preview.js" defer></script></main></body></html>"""
        return newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", scopedHtml(html)).apply {
            addHeader("Cache-Control", "no-store")
            addHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; media-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'")
        }
    }

    private fun download(s: IHTTPSession): Response {
        val f = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "This item is not shared")
        if (!f.isFile || !f.canRead()) return text(Status.NOT_FOUND, "File not found")
        val total = f.length()
        val inline = s.p("inline") == "1"
        val type = if (inline) mime(f) else "application/octet-stream"
        var start = 0L
        var end = total - 1
        val range = s.headers["range"]
        // A single byte range supports browser media seeking without loading the whole file.
        if (range != null) {
            val requested = ByteRange.parse(range, total)
                ?: return text(Status.RANGE_NOT_SATISFIABLE, "Invalid byte range").apply {
                    addHeader("Content-Range", "bytes */$total")
                    addHeader("Accept-Ranges", "bytes")
                }
            start = requested.start
            end = requested.end
        }
        val length = if (total == 0L) 0L else end - start + 1
        val input = FileInputStream(f)
        try { input.channel.position(start) } catch (e: Exception) { input.close(); throw e }
        return newFixedLengthResponse(if (range == null) Status.OK else Status.PARTIAL_CONTENT, type, input, length).apply {
            addHeader("Content-Disposition", (if (inline) "inline" else "attachment") + "; filename*=UTF-8''" + enc(f.name).replace("+", "%20"))
            addHeader("Accept-Ranges", "bytes")
            if (range != null) addHeader("Content-Range", "bytes $start-$end/$total")
            addHeader("X-Content-Type-Options", "nosniff")
            addHeader("Content-Security-Policy", if (type == "application/pdf") "default-src 'none'; frame-ancestors 'self'" else "sandbox")
            addHeader("Cache-Control", "no-store")
        }
    }

    private fun downloadSelection(s: IHTTPSession): Response {
        val parent = resolve(s.p("folder"))?.takeIf { it.isDirectory }
            ?: return text(Status.BAD_REQUEST, "Invalid parent folder")
        val paths = s.parameters["path"] ?: emptyList()
        if (paths.isEmpty() || paths.size > 200 || paths.distinct().size != paths.size)
            return text(Status.BAD_REQUEST, "Select 1 to 200 distinct items")
        val files = paths.map { path ->
            val item = resolve(path) ?: return text(Status.FORBIDDEN, "Item is not shared")
            if (item == root || item.parentFile?.canonicalFile != parent.canonicalFile || !item.exists() || !item.canRead())
                return text(Status.BAD_REQUEST, "Selection must be readable items in this folder")
            item
        }
        if (s.headers["range"] != null) return text(Status.RANGE_NOT_SATISFIABLE, "ZIP download cannot resume")
        val stream = if (s.method == Method.HEAD) java.io.ByteArrayInputStream(ByteArray(0)) else
            MultiArchive.stream(root, files) ?: return text(Status.SERVICE_UNAVAILABLE, "Too many downloads")
        val archiveName = (parent.takeIf { it != root }?.name ?: "Selected files") + ".zip"
        return newChunkedResponse(Status.OK, "application/zip", stream).apply {
            addHeader("Content-Disposition", "attachment; filename*=UTF-8''" + enc(archiveName).replace("+", "%20"))
            addHeader("Accept-Ranges", "none")
            addHeader("Cache-Control", "no-store")
            addHeader("X-Content-Type-Options", "nosniff")
        }
    }

    private fun downloadFolder(s: IHTTPSession): Response {
        val dir = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "This folder is not shared")
        if (dir == root) return text(Status.FORBIDDEN, "Choose a folder from the file list")
        if (!dir.isDirectory || !dir.canRead()) return text(Status.NOT_FOUND, "Folder not found or not readable")
        if (s.headers["range"] != null) return text(Status.RANGE_NOT_SATISFIABLE, "Folder ZIP downloads cannot be resumed. Start a new download.")
        val stream = if (s.method == Method.HEAD) java.io.ByteArrayInputStream(ByteArray(0)) else
            FolderArchive.stream(root, dir) ?: return text(Status.SERVICE_UNAVAILABLE, "Two folder downloads are already running. Please try again shortly.")
        return newChunkedResponse(Status.OK, "application/zip", stream).apply {
            addHeader("Content-Disposition", "attachment; filename*=UTF-8''" + enc(dir.name + ".zip").replace("+", "%20"))
            addHeader("Accept-Ranges", "none")
            addHeader("Cache-Control", "no-store")
            addHeader("X-Content-Type-Options", "nosniff")
        }
    }

    // ---------- changes ----------
    @Synchronized
    private fun deleteFiles(s: IHTTPSession): Response {
        s.parseBody(HashMap())
        val paths = s.parameters["path"] ?: emptyList()
        if (paths.isEmpty() || paths.size > 200 || s.p("confirm") != "delete")
            return text(Status.BAD_REQUEST, "Confirm deletion of between 1 and 200 items")
        val results = try {
            val parent = resolve(s.p("folder")) ?: throw IllegalArgumentException("Folder not shared")
            paths.map { path ->
                val file = resolve(path)
                if(file == null || file.parentFile != parent || file == root) FileDeletion.Result(path,false,"Item is not in this folder")
                else try { TrashStore(root).put(file); FileDeletion.Result(path,true,"Moved to Recycle Bin") }
                catch(e:Exception) { FileDeletion.Result(path,false,e.message ?: "Cannot move to Bin") }
            }
        }
            catch (e: IllegalArgumentException) { return text(Status.BAD_REQUEST, e.message ?: "Invalid selection") }
        val entries = JSONArray()
        for (result in results) entries.put(JSONObject().put("path", result.path)
            .put("deleted", result.deleted).put("message", result.message))
        return newFixedLengthResponse(Status.OK, "application/json; charset=utf-8",
            JSONObject().put("results", entries).toString()).apply { addHeader("Cache-Control", "no-store") }
    }

    @Synchronized
    private fun rename(s: IHTTPSession): Response {
        s.parseBody(HashMap())
        val source = resolve(s.p("path")) ?: return text(Status.FORBIDDEN, "This item is not shared")
        if (source == root || !source.exists()) return text(Status.FORBIDDEN, "Cannot rename this item")
        val name = s.p("name").trim()
        if (!validName(name)) return text(Status.BAD_REQUEST, "Invalid or reserved name")
        if (name == source.name) return text(Status.OK, "OK")
        val parent = source.parentFile ?: return text(Status.FORBIDDEN, "Bad folder")
        val target = resolve(parent.path.removePrefix(root.path) + "/" + name)
            ?: return text(Status.FORBIDDEN, "This name is not allowed")
        if (target.exists()) return text(Status.CONFLICT, "A file or folder with this name already exists")
        return if (source.renameTo(target)) text(Status.OK, "OK")
            else text(Status.FORBIDDEN, "Cannot rename. Check Android file permissions.")
    }

    private fun mkdir(s: IHTTPSession): Response {
        s.parseBody(HashMap())
        val dir = resolve(s.p("path"))?.takeIf { it.isDirectory } ?: return text(Status.FORBIDDEN, "Bad folder")
        val name = s.p("name").trim()
        if (!validName(name)) return text(Status.BAD_REQUEST, "Invalid name")
        val t = resolve(dir.path.removePrefix(root.path) + "/" + name) ?: return text(Status.FORBIDDEN, "Bad path")
        if (t.exists()) return text(Status.CONFLICT, "Already exists")
        return if (t.mkdirs()) text(Status.OK, "OK") else text(Status.INTERNAL_ERROR, "Couldn't create the folder")
    }

    private fun mkfile(s: IHTTPSession): Response {
        s.parseBody(HashMap())
        val dir = resolve(s.p("path"))?.takeIf { it.isDirectory } ?: return text(Status.FORBIDDEN, "Bad folder")
        val name = s.p("name").trim()
        if (!validName(name)) return text(Status.BAD_REQUEST, "Invalid name")
        val t = resolve(dir.path.removePrefix(root.path) + "/" + name) ?: return text(Status.FORBIDDEN, "Bad path")
        if (t.exists()) return text(Status.CONFLICT, "Already exists")
        t.writeText(s.p("content"))
        return text(Status.OK, "OK")
    }

    private fun upload(s: IHTTPSession): Response {
        val files = HashMap<String, String>()
        s.parseBody(files)
        val tmp = files["file"] ?: return text(Status.BAD_REQUEST, "No file received")
        try {
            val dir = resolve(dec(s.p("path")))?.takeIf { it.isDirectory } ?: return text(Status.FORBIDDEN, "Bad folder")
            val parts = segments(dec(s.p("rel")))?.takeIf { it.isNotEmpty() } ?: return text(Status.BAD_REQUEST, "Bad file name")
            var target = dir
            for (p in parts) target = File(target, p)
            val c = resolve(target.path.removePrefix(root.path)) ?: return text(Status.FORBIDDEN, "This item is not shared")
            if (!c.path.startsWith(dir.path + File.separator)) return text(Status.FORBIDDEN, "Bad path")
            if (c.exists()) return text(Status.CONFLICT, "Already exists")
            c.parentFile?.mkdirs()
            File(tmp).inputStream().use { i -> c.outputStream().use { o -> i.copyTo(o) } }
            return text(Status.OK, "OK")
        } finally {
            File(tmp).delete()
        }
    }
}
