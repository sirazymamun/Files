package com.example.httpsserver
import java.io.File
import java.util.Locale
internal object FileTypeIcons {
 fun kind(file:File):String {
  if(file.isDirectory)return "Folder"
  return when(file.extension.lowercase(Locale.ROOT)){
   "pdf"->"PDF"
   "doc","docx","odt"->"Word"
   "xls","xlsx","ods"->"Excel"
   "ppt","pptx","odp"->"Presentation"
   "csv"->"CSV"
   "rtf"->"RTF"
   "epub","mobi"->"Ebook"
   "html","htm","css","js","kt","java","py","yml","yaml","json","xml"->"Code"
   else->FileManagerOps.category(file)
  }
 }
}
