package com.example.httpsserver

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/** Native local file manager. The original HTTPS server remains available from Server. */
class FilesActivity : Activity() {
    private val ink=Color.rgb(28,48,58);private val teal=Color.rgb(0,121,112);private val soft=Color.WHITE
    private lateinit var shell: LinearLayout; private lateinit var content: LinearLayout
    private lateinit var pathLabel: TextView;private lateinit var status: TextView;private lateinit var actions: LinearLayout
    private lateinit var search: EditText
    private lateinit var drawer: androidx.drawerlayout.widget.DrawerLayout
    private lateinit var side: LinearLayout
    private lateinit var navigation: LinearLayout
    private lateinit var actionScroll: HorizontalScrollView
    private lateinit var productFooter:TextView
    private lateinit var headerTitle: TextView
    private lateinit var searchButton: ImageButton
    private lateinit var overflowButton: ImageButton
    private lateinit var selectAllTop: ImageButton
    private lateinit var gridTop: ImageButton
    private var drawerTab="Folders"
    private val homeDetails=linkedMapOf<String,TextView>()
    private val mediaThumbnails=MediaThumbnails();private val work=Executors.newSingleThreadExecutor();private val thumbs=java.util.concurrent.ThreadPoolExecutor(2,2,30,java.util.concurrent.TimeUnit.SECONDS,java.util.concurrent.ArrayBlockingQueue<Runnable>(32),java.util.concurrent.ThreadPoolExecutor.DiscardPolicy())
    private var roots=listOf<StorageVolumeRoot>();private var volume=0;private var current: File?=null
    private var category: String?=null;private var home=true;private var grid=false;private var sort="Name";private var descending=false
    private var showHidden=false;private var hideEmpty=false;@Volatile private var requestId=0;private var busy=false
    private var folderCounts=mapOf<String,Int>();private var entries=listOf<File>();private val selected=linkedSetOf<File>();private var forward=mutableListOf<File>()
    private var clipboard=listOf<File>();private var clipboardRoot:File?=null;private var cut=false
    private val prefs by lazy {getSharedPreferences("files-manager",MODE_PRIVATE)}
    private val adapter by lazy { EntriesAdapter() }
    private val albumsAdapter by lazy { AlbumsAdapter() }
    private var photoAlbums=listOf<ImageAlbums.Album>()
    private var photoDates=mapOf<String,Long>()
    private var photoSortChanged=false
    private var galleryCancellation=android.os.CancellationSignal()
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun text(value:String,size:Float=15f,bold:Boolean=false)=TextView(this).apply {text=value;textSize=size;setTextColor(ink);if(bold)setTypeface(null,Typeface.BOLD)}
    private fun panel()=GradientDrawable().apply {setColor(Color.WHITE);cornerRadius=dp(14).toFloat();setStroke(dp(1),Color.rgb(219,232,229))}
    private fun touchBackground(dark:Boolean=false):android.graphics.drawable.Drawable {
        val states=android.graphics.drawable.StateListDrawable()
        fun shape(color:Int)=GradientDrawable().apply{setColor(color)}
        states.addState(intArrayOf(android.R.attr.state_focused),shape(if(dark)Color.rgb(76,90,88) else Color.rgb(217,237,233)))
        states.addState(intArrayOf(android.R.attr.state_pressed),shape(if(dark)Color.rgb(80,80,80) else Color.rgb(226,241,238)))
        states.addState(intArrayOf(),shape(Color.TRANSPARENT));return states
    }
    private fun button(label:String,action:()->Unit)=Button(this).apply {
        text=label;isAllCaps=false;textSize=14f;minHeight=dp(44);minimumHeight=dp(44);minWidth=0;minimumWidth=0
        setPadding(dp(12),0,dp(12),0);setTextColor(teal);background=touchBackground();stateListAnimator=null;elevation=0f
        setOnClickListener{if(!busy)action()}
    }
    private fun iconButton(kind:String,description:String,dark:Boolean=false,action:()->Unit)=ImageButton(this).apply {
        contentDescription=description;setImageDrawable(ManagerIcon(kind));scaleType=ImageView.ScaleType.FIT_CENTER;setPadding(dp(6),dp(6),dp(6),dp(6));background=touchBackground(dark)
        isFocusable=true;setOnClickListener{if(!busy)action()}
    }
    private fun row()=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
    private fun toast(message:String)=Toast.makeText(this,message,Toast.LENGTH_LONG).show()
    override fun onCreate(state:Bundle?){
        super.onCreate(state)
        window.statusBarColor=Color.rgb(32,32,32);window.navigationBarColor=if(Build.VERSION.SDK_INT>=26)Color.rgb(250,250,250)else Color.BLACK
        window.decorView.systemUiVisibility=if(Build.VERSION.SDK_INT>=26)View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
        // Upgrade existing installs once: the previous default hid ordinary empty folders.
        // Users can still opt back into hiding empty folders in Display settings.
        if(!prefs.getBoolean("mainStorageFullListingV1",false)) {
            prefs.edit().putBoolean("hideEmpty",false).putBoolean("mainStorageFullListingV1",true).apply()
        }
        showHidden=prefs.getBoolean("showHidden",false);grid=prefs.getBoolean("grid",false);hideEmpty=prefs.getBoolean("hideEmpty",false);sort=prefs.getString("sort","Name") ?: "Name";descending=prefs.getBoolean("descending",false)
        drawer=androidx.drawerlayout.widget.DrawerLayout(this).apply {setScrimColor(Color.argb(145,0,0,0))}
        shell=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
        val header=row().apply{setBackgroundColor(Color.rgb(32,32,32));setPadding(0,0,dp(3),0)}
        header.addView(iconButton("Menu","Open menu",true){renderDrawer();drawer.openDrawer(Gravity.LEFT)},LinearLayout.LayoutParams(dp(48),dp(56)))
        val logo=ImageView(this).apply{setImageResource(R.drawable.logo);adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER;contentDescription="tv2u"}
        header.addView(logo,LinearLayout.LayoutParams(dp(48),dp(24)).apply{rightMargin=dp(10)})
        headerTitle=text("Files",20f,true).apply{setTextColor(Color.WHITE);isSingleLine=true;ellipsize=android.text.TextUtils.TruncateAt.END;gravity=Gravity.CENTER_VERTICAL}
        header.addView(headerTitle,LinearLayout.LayoutParams(0,-1,1f))
        searchButton=iconButton("Search","Search files",true){search.visibility=if(search.visibility==View.VISIBLE)View.GONE else View.VISIBLE;if(search.visibility==View.VISIBLE)search.requestFocus()}
        header.addView(searchButton,LinearLayout.LayoutParams(dp(48),dp(56)))
        selectAllTop=iconButton("SelectAll","Select all or deselect all",true){
            if(selected.size==shown().size)selected.clear() else selected.addAll(shown())
            adapter.notifyDataSetChanged();updateActions()
        };header.addView(selectAllTop,LinearLayout.LayoutParams(dp(48),dp(56)))
        gridTop=iconButton("Grid","List or grid",true){grid=!grid;prefs.edit().putBoolean("grid",grid).apply();bindList()}
        header.addView(gridTop,LinearLayout.LayoutParams(dp(48),dp(56)))
        overflowButton=HeaderMenus.more(this,"More options"){menu()};header.addView(overflowButton,LinearLayout.LayoutParams(dp(48),dp(56)))
        shell.addView(header,LinearLayout.LayoutParams(-1,dp(56)))
        navigation=row().apply{setPadding(dp(10),0,dp(10),0);setBackgroundColor(Color.rgb(250,250,250))}
        val homeIcon=iconButton("Home","Home"){showHome()};homeIcon.setPadding(dp(4),dp(4),dp(4),dp(4));navigation.addView(homeIcon,LinearLayout.LayoutParams(dp(48),dp(48)))
        navigation.addView(text("›",23f).apply{setPadding(dp(2),0,dp(8),0)})
        pathLabel=text("Home",13f).apply{isSingleLine=true;ellipsize=android.text.TextUtils.TruncateAt.MIDDLE;gravity=Gravity.CENTER_VERTICAL}
        navigation.addView(pathLabel,LinearLayout.LayoutParams(0,dp(48),1f))
        navigation.addView(iconButton("Parent","Up one folder"){up()},LinearLayout.LayoutParams(dp(48),dp(48)));shell.addView(navigation,LinearLayout.LayoutParams(-1,dp(48)))
        search=EditText(this).apply{hint="Search this view";textSize=15f;isSingleLine=true;setPadding(dp(16),0,dp(16),0);setBackgroundColor(Color.rgb(247,247,247));visibility=View.GONE}
        shell.addView(search,LinearLayout.LayoutParams(-1,dp(44)))
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){adapter.notifyDataSetChanged();albumsAdapter.notifyDataSetChanged()};override fun afterTextChanged(s:Editable?){} })
        status=text("",12f).apply{setTextColor(Color.rgb(117,117,117));setPadding(dp(14),dp(4),dp(14),dp(4))};shell.addView(status)
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};shell.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        actions=row().apply{setPadding(0,0,0,0);setBackgroundColor(Color.rgb(247,249,248))}
        actionScroll=HorizontalScrollView(this).apply{isHorizontalScrollBarEnabled=false;addView(actions)};shell.addView(actionScroll,LinearLayout.LayoutParams(-1,dp(54)))
        productFooter=text("A netcolink product",12f).apply{gravity=Gravity.CENTER;setTextColor(Color.rgb(110,110,110))};shell.addView(productFooter,LinearLayout.LayoutParams(-1,dp(32)))
        drawer.addView(shell,androidx.drawerlayout.widget.DrawerLayout.LayoutParams(-1,-1))
        side=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
        val sideWidth=dp(minOf(320,(resources.configuration.screenWidthDp*.76f).toInt()))
        drawer.addView(side,androidx.drawerlayout.widget.DrawerLayout.LayoutParams(sideWidth,-1).apply{gravity=Gravity.LEFT})
        setContentView(drawer)
        current=state?.getString("folder")?.let(::File);home=state?.getBoolean("home") ?: true;category=state?.getString("category")
    }
    override fun onResume(){super.onResume();runCatching{FilesDocumentsProvider.notifyRoots(this)};if(StorageAccess.hasFullAccess(this)){
        runCatching {StorageAccess.volumes(this)}.onSuccess {roots=it;volume=roots.indexOfFirst {v->current?.canonicalPath?.let {p->p==v.folder.path || p.startsWith(v.folder.path+"/")}==true}.coerceAtLeast(0);if(intent.getBooleanExtra("apps_pending_saved",false)){intent.removeExtra("apps_pending_saved");openCategory("Apps")}else if(intent.hasExtra("apps_pending_folder")){val folder=intent.getStringExtra("apps_pending_folder");intent.removeExtra("apps_pending_folder");if(folder!=null)openPlace(File(folder))}else if(home)showHome()else refresh()}.onFailure{permissionScreen(it.message ?: "Storage unavailable")}
    }else permissionScreen("Allow device storage access to browse your files.")}
    override fun onSaveInstanceState(out:Bundle){out.putString("folder",current?.path);out.putBoolean("home",home);out.putString("category",category);super.onSaveInstanceState(out)}
    override fun onDestroy(){requestId++;galleryCancellation.cancel();work.shutdownNow();thumbs.shutdownNow();mediaThumbnails.close();super.onDestroy()}
    private fun permissionScreen(message:String){roots=emptyList();navigation.visibility=View.GONE;searchButton.visibility=View.GONE;search.visibility=View.GONE;actionScroll.visibility=View.GONE;status.visibility=View.VISIBLE;content.removeAllViews();status.text=message;content.addView(button("Allow device storage access"){grantStorage()});content.addView(button("Open server settings"){startActivity(Intent(this,MainActivity::class.java))})}
    private fun grantStorage(){
        if(Build.VERSION.SDK_INT>=30){val intent=Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:$packageName"));runCatching{startActivity(intent)}.onFailure{runCatching{startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))}.onFailure{toast("Open Android Settings → Apps → Files → Permissions")}}}
        else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE),91)
    }
    private fun base()=roots[volume].folder
    private fun ops()=FileManagerOps(base(),showHidden)
    private fun menu(){
        if(roots.isEmpty()){AlertDialog.Builder(this).setItems(arrayOf("Allow storage access","Apps","Server")){_,i->when(i){0->grantStorage();1->openInstalledApps();2->startActivity(Intent(this,MainActivity::class.java))}}.show();return}
        val popup=PopupMenu(this,overflowButton,Gravity.END)
        val items=(if(ArchiveActions.canExtract(selected))listOf("Extract")else emptyList())+(if(home || category=="Images")listOf("Refresh","Display settings","Recycle Bin","Cloud / providers","Server") else listOf("New","Sort","Bookmark this folder","Refresh","Display settings","Recycle Bin","Cloud / providers","Server"))
        items.forEachIndexed{i,label->popup.menu.add(0,i,0,label)}
        popup.setOnMenuItemClickListener{item->when(item.title.toString()){
            "Extract"->extractionChoices(selected.toList())
            "New"->newItem()
            "Sort"->sortDialog()
            "Bookmark this folder"->{if(category==null && current!=null){savePlace("favorites",current!!);toast("Folder bookmarked")}else toast("Open a folder first")}
            "Refresh"->if(home)showHome()else refresh()
            "Display settings"->settings()
            "Recycle Bin"->trashMenu()
            "Cloud / providers"->cloudMenu()
            "Server"->startActivity(Intent(this,MainActivity::class.java))
        };true};popup.show()
    }
    private fun places(key:String):List<File> = runCatching{val a=org.json.JSONArray(prefs.getString(key,"[]"));(0 until a.length()).map{File(a.getString(it))}}.getOrDefault(emptyList())
    private fun savePlace(key:String,file:File){val files=(listOf(file)+places(key).filter{it!=file}).take(30);prefs.edit().putString(key,org.json.JSONArray(files.map{it.path}).toString()).apply()}
    private fun openPlace(file:File){val index=roots.indexOfFirst{file.path==it.folder.path || file.path.startsWith(it.folder.path+"/")};if(index<0){toast("Storage is not connected");return};volume=index;openFolder(file)}
    private fun renderDrawer(){
        side.removeAllViews();val tabs=row()
        for((kind,label) in listOf("Folder" to "Folders","Favorites" to "Favorites","Recent" to "Recent")){
            val tab=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=touchBackground();isFocusable=true;contentDescription=label;setOnClickListener{drawerTab=label;renderDrawer()}}
            val image=ImageView(this).apply{setImageDrawable(ManagerIcon(kind));alpha=if(drawerTab==label)1f else .5f};tab.addView(image,LinearLayout.LayoutParams(dp(32),dp(32)).apply{topMargin=dp(9);bottomMargin=dp(8)})
            tab.addView(View(this).apply{setBackgroundColor(if(drawerTab==label)teal else Color.TRANSPARENT)},LinearLayout.LayoutParams(-1,dp(3)))
            tabs.addView(tab,LinearLayout.LayoutParams(0,dp(52),1f))
        };side.addView(tabs);side.addView(View(this).apply{setBackgroundColor(Color.rgb(215,215,215))},LinearLayout.LayoutParams(-1,dp(1)))
        val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(list);side.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        fun entry(kind:String,title:String,subtitle:String="",badge:String="",action:()->Unit){
            val item=row().apply{setPadding(dp(10),dp(8),dp(10),dp(8));minimumHeight=dp(56);background=touchBackground();isFocusable=true;setOnClickListener{drawer.closeDrawer(Gravity.LEFT);if(!busy)action()}}
            item.addView(ImageView(this).apply{setImageDrawable(ManagerIcon(kind))},LinearLayout.LayoutParams(dp(38),dp(38)).apply{rightMargin=dp(12)})
            val labels=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};labels.addView(text(title,16f));if(subtitle.isNotEmpty())labels.addView(text(subtitle,12f).apply{setTextColor(Color.GRAY);maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.MIDDLE})
            item.addView(labels,LinearLayout.LayoutParams(0,-2,1f));if(badge.isNotEmpty())item.addView(text(badge,12f).apply{setTextColor(Color.GRAY)})
            list.addView(item);list.addView(View(this).apply{setBackgroundColor(Color.rgb(224,224,224))},LinearLayout.LayoutParams(-1,dp(1)))
        }
        if(drawerTab!="Folders"){
            val files=places(if(drawerTab=="Favorites")"favorites" else "recent")
            if(files.isEmpty())list.addView(text(if(drawerTab=="Favorites")"No bookmarks yet. Open a folder and choose Bookmark this folder." else "No recent folders yet.",14f).apply{setPadding(dp(18),dp(20),dp(18),dp(20))})
            files.forEach{file->entry("Folder",file.name.ifEmpty{"Storage"},file.path){openPlace(file)}}
            return
        }
        entry("Home","Home"){showHome()}
        if(roots.isEmpty()){entry("Storage","Allow storage access"){grantStorage()};entry("Apps","Apps"){openInstalledApps()};entry("Server","Server"){startActivity(Intent(this,MainActivity::class.java))};entry("Notes","Notes"){startActivity(Intent(this,NotesActivity::class.java))};return}
        roots.forEachIndexed{i,v->val total=v.folder.totalSpace;val used=(total-v.folder.usableSpace).coerceAtLeast(0);val percent=if(total>0)(used*100/total).toInt()else 0;entry("Storage",if(i==0)"Main storage" else v.name,FileManagerOps.formatBytes(used)+" / "+FileManagerOps.formatBytes(total),"$percent%"){volume=i;openFolder(v.folder)}}
        entry("Bin","Recycle Bin"){trashMenu()}
        for(kind in listOf("Images","Downloads","Videos","Audio","Documents","Apps","Archives","New files"))entry(kind,if(kind=="Apps")"Apps" else kind){if(kind=="Downloads"){val dir=File(base(),"Download");if(dir.isDirectory)openFolder(dir)else toast("Downloads folder not found")}else if(kind=="Apps")openInstalledApps()else openCategory(kind)}
        entry("Cloud","Cloud"){cloudMenu()};entry("Server","Server"){startActivity(Intent(this,MainActivity::class.java))};entry("Notes","Notes"){startActivity(Intent(this,NotesActivity::class.java))}
    }
    private fun settings(){val checks=booleanArrayOf(hideEmpty,showHidden);AlertDialog.Builder(this).setTitle("Display settings").setMultiChoiceItems(arrayOf("Hide empty folders","Show hidden files"),checks){_,index,value->checks[index]=value}.setPositiveButton("Save"){_,_->hideEmpty=checks[0];showHidden=checks[1];prefs.edit().putBoolean("hideEmpty",hideEmpty).putBoolean("showHidden",showHidden).apply();selected.clear();if(home)showHome()else{while(current!=null && current!=base() && runCatching{ops().checked(current!!,true)}.isFailure)current=current!!.parentFile;refresh()}}.setNegativeButton("Cancel",null).show()}

    private fun sortDialog(){if(category=="Image album")photoSortChanged=true;val items=arrayOf("Name","Modified","Size","Type");AlertDialog.Builder(this).setTitle("Sort by").setSingleChoiceItems(items,items.indexOf(sort)){d,i->sort=items[i];prefs.edit().putString("sort",sort).apply();d.dismiss();AlertDialog.Builder(this).setTitle("Order").setItems(arrayOf("Ascending","Descending")){_,n->descending=n==1;prefs.edit().putBoolean("descending",descending).apply();sortEntries();adapter.notifyDataSetChanged()}.show()}.show()}
    private fun storageDialog(){if(roots.isEmpty()){grantStorage();return};AlertDialog.Builder(this).setTitle("Storage").setItems(roots.map{it.name}.toTypedArray()){_,i->volume=i;forward.clear();openFolder(base())}.show()}
    private fun showHome(){galleryCancellation.cancel();
        if(roots.isEmpty())return
        val token=++requestId;home=true;category=null;selected.clear();search.setText("");search.visibility=View.GONE;navigation.visibility=View.GONE;status.visibility=View.GONE;searchButton.visibility=View.GONE;headerTitle.text="Files";content.removeAllViews();homeDetails.clear()
        val root=base();val total=root.totalSpace;val used=(total-root.usableSpace).coerceAtLeast(0);val percent=if(total>0)(used*100/total).toInt()else 0
        val scroll=ScrollView(this).apply{isFillViewport=false};val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(14),dp(8),dp(16))};scroll.addView(body);content.addView(scroll,LinearLayout.LayoutParams(-1,-1))
        val labels=listOf("Main storage","Downloads","Storage analysis","Images","Audio","Videos","Documents","Apps","New files","Cloud","Archives","Server","Notes")
        for(group in labels.chunked(3)){
            val line=row()
            for(label in group){
                val kind=when(label){"Main storage"->"Storage";"Storage analysis"->"Analysis";else->label}
                val tile=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.TOP or Gravity.CENTER_HORIZONTAL;setPadding(dp(2),dp(5),dp(2),dp(5));background=touchBackground();isFocusable=true;contentDescription=label}
                tile.addView(ImageView(this).apply{setImageDrawable(ManagerIcon(kind,percent));contentDescription=null},LinearLayout.LayoutParams(dp(60),dp(60)))
                tile.addView(text(label,if(label=="Storage analysis")13f else 14f).apply{gravity=Gravity.CENTER;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END},LinearLayout.LayoutParams(-1,dp(23)))
                val detail=text("",11.5f).apply{setTextColor(Color.rgb(125,125,125));gravity=Gravity.CENTER;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END};homeDetails[kind]=detail;tile.addView(detail,LinearLayout.LayoutParams(-1,dp(17)))
                detail.text=when(kind){"Storage"->FileManagerOps.formatBytes(used)+" / "+FileManagerOps.formatBytes(total);"Analysis"->"$percent% used";"Cloud"->if(getSharedPreferences("google-drive",MODE_PRIVATE).contains("account"))"Google Drive" else if(prefs.getString("cloudUri",null)==null)"Connect folder" else "1 folder";"Archives"->"ZIP / RAR";"Server"->"HTTP / HTTPS";"Notes"->"";else->"Scanning…"}
                tile.setOnClickListener{if(!busy)when(kind){"Storage"->openFolder(root);"Downloads"->{val dir=File(root,"Download");if(dir.isDirectory)openFolder(dir)else toast("Downloads folder not found")};"Analysis"->AlertDialog.Builder(this).setTitle("Storage analysis").setMessage("${roots[volume].name}\n\nUsed: ${FileManagerOps.formatBytes(used)} ($percent%)\nFree: ${FileManagerOps.formatBytes(root.usableSpace)}\nTotal: ${FileManagerOps.formatBytes(total)}").setPositiveButton("Close",null).show();"Apps"->openInstalledApps();"Notes"->startActivity(Intent(this,NotesActivity::class.java));"Cloud"->cloudMenu();"Server"->startActivity(Intent(this,MainActivity::class.java));else->openCategory(kind)}}
                line.addView(tile,LinearLayout.LayoutParams(0,dp(112),1f))
            };repeat(3-group.size){line.addView(View(this),LinearLayout.LayoutParams(0,dp(112),1f))};body.addView(line)
        }
        roots.drop(1).forEachIndexed{i,v->body.addView(button(v.name+" · "+FileManagerOps.formatBytes(v.folder.usableSpace)+" free"){volume=i+1;openFolder(v.folder)})}
        updateActions();scanHome(root,token)
    }
    private fun scanHome(root:File,token:Int){
        work.execute{
            data class Count(var bytes:Long=0,var files:Int=0)
            val counts=listOf("Images","Videos","Audio","Documents","New files","Downloads").associateWith{Count()};val policy=SharedFiles(root,showHidden);var entries=0;var partial=false;val start=System.nanoTime();val download=File(root,"Download").path+"/";val recent=System.currentTimeMillis()-7L*86400000
            fun visit(dir:File,depth:Int){
                if(token!=requestId || Thread.currentThread().isInterrupted)return
                if(depth>128 || entries>100000 || System.nanoTime()-start>12000000000L){partial=true;return}
                val files=runCatching{dir.listFiles()}.getOrNull();if(files==null){partial=true;return}
                for(file in files){if(token!=requestId || Thread.currentThread().isInterrupted)return;if(++entries>100000 || System.nanoTime()-start>12000000000L){partial=true;return}
                    if(!policy.allowedPart(file.name) || runCatching{file.absolutePath!=file.canonicalPath || policy.resolve(file.path.removePrefix(root.path))==null}.getOrDefault(true))continue
                    if(file.isDirectory)visit(file,depth+1)else if(file.isFile){val size=file.length();fun add(kind:String){counts[kind]?.let{it.bytes+=size;it.files++}};add(FileManagerOps.category(file));if(file.path.startsWith(download))add("Downloads");if(file.lastModified()>recent)add("New files")}
                }
            }
            runCatching{visit(root,0);val shared=File(root,"Android/media");if(shared.isDirectory)visit(shared,0)}.onFailure{partial=true}
            val installedSummary=runCatching{val apps=InstalledApps.list(this).filter{it.downloaded};if(apps.all{it.apkBytes!=null})FileManagerOps.formatBytes(apps.sumOf{it.apkBytes ?: 0})+" (${apps.size})" else "${apps.size} apps · size unavailable"}.getOrDefault("Unavailable")
            runOnUiThread{if(home && token==requestId && !isFinishing){for((kind,count) in counts)homeDetails[kind]?.text=(if(partial)"≥ " else "")+FileManagerOps.formatBytes(count.bytes)+" (${count.files})";homeDetails["Apps"]?.text=installedSummary}}
        }
    }
    private fun openFolder(folder:File){if(busy)return;try{if(!MainStorageListing.isAndroidDirectory(base(),folder))ops().checked(folder,true);require(folder.isDirectory);savePlace("recent",folder);home=false;category=null;current=folder;selected.clear();search.setText("");refresh()}catch(e:Exception){toast(e.message ?: "Cannot open folder")}}
    private fun openInstalledApps(){startActivityForResult(Intent(this,InstalledAppsActivity::class.java),94)}
    private fun openCategory(name:String){photoSortChanged=false;home=false;category=name;current=base();selected.clear();search.setText("");refresh()}
    private fun refresh(){
        if(roots.isEmpty() || busy)return
        galleryCancellation.cancel();galleryCancellation=android.os.CancellationSignal();val token=++requestId;val root=base();val folder=current ?: root;val kind=category;val hidden=showHidden;val cancelSignal=galleryCancellation
        navigation.visibility=View.VISIBLE;status.visibility=View.VISIBLE;searchButton.visibility=View.VISIBLE;search.visibility=if(search.text.isNotEmpty())View.VISIBLE else View.GONE;headerTitle.text=(if(kind=="Image album")folder.name else kind) ?: if(folder==root)"Main storage" else folder.name;pathLabel.text=(if(kind=="Image album")"Images · "+roots[volume].name+folder.path.removePrefix(root.path)else kind) ?: (roots[volume].name+folder.path.removePrefix(root.path).ifEmpty{" /"});status.text="Loading…";content.removeAllViews();content.addView(ProgressBar(this));selected.clear();updateActions()
        if(kind=="Images"){
            val storage=roots.map{it.folder};status.text="Loading photo albums…";pathLabel.text="Images · all storage"
            work.execute{val result=runCatching{ImageAlbums.scan(this,storage,hidden,cancelled={token!=requestId || Thread.currentThread().isInterrupted},indexed={found->runOnUiThread{if(token==requestId && !isFinishing){photoAlbums=found.albums;status.text="${found.albums.size} albums · ${found.photos} photos · Checking shared folders…";bindAlbums()}}},signal=cancelSignal)}
                runOnUiThread{if(token==requestId && !isFinishing){result.onSuccess{found->photoAlbums=found.albums;status.text="${found.albums.size} albums · ${found.photos} photos · All storage"+(if(found.partial)" · Scan limit reached; refresh or browse storage" else "")+(if(found.unreadable>0)" · Some folders unavailable" else "");bindAlbums()}.onFailure{status.text=it.message ?: "Cannot read photo albums";content.removeAllViews()}}}}
            return
        }
        if(kind=="Image album"){
            work.execute{val result=runCatching{ImageAlbums.albumPhotos(root,folder,hidden,photoAlbums.firstOrNull{it.folder==folder}?.photos ?: emptyList())};runOnUiThread{if(token==requestId && !isFinishing){result.onSuccess{photos->photoDates=photos.associate{it.file.path to it.recent};entries=photos.map{it.file};sortEntries();status.text="${entries.size} photos · "+if(photoSortChanged)"Custom sort" else "Newest first";bindList()}.onFailure{entries=emptyList();status.text=it.message ?: "Cannot read photo folder";content.removeAllViews()}}}}
            return
        }
        work.execute{try{
            val policy=SharedFiles(root,showHidden);val result=mutableListOf<File>();var scanned=0;var limited=false;val started=System.nanoTime()
            fun scan(dir:File,depth:Int){
                if(depth>128 || scanned>=100000 || System.nanoTime()-started>12000000000L){limited=true;return}
                if(Thread.currentThread().isInterrupted || token!=requestId)return
                val children=dir.listFiles() ?: throw java.io.IOException("Cannot read ${dir.name}")
                for(f in children){if(++scanned>100000){limited=true;return};if(f.absolutePath!=f.canonicalPath || !policy.allowedPart(f.name) || policy.resolve(f.path.removePrefix(root.path))==null)continue
                    if(f.isDirectory)scan(f,depth+1)else if(f.isFile && (kind=="New files" && f.lastModified()>System.currentTimeMillis()-7L*86400000 || FileManagerOps.category(f)==kind))result.add(f)
                    if(System.nanoTime()-started>12000000000L){limited=true;return}
                }
            }
            if(kind==null){if(!MainStorageListing.isAndroidDirectory(root,folder))FileManagerOps(root,showHidden).checked(folder,true);result.addAll(MainStorageListing.children(root,folder,policy,hideEmpty))}else{scan(root,0);val shared=File(root,"Android/media");if(shared.isDirectory)scan(shared,0)}
            val counts=result.filter{it.isDirectory}.associate{it.path to (it.listFiles()?.count { child -> policy.allowedPart(child.name) && child.absolutePath==child.canonicalPath } ?: -1)}
            runOnUiThread{if(token==requestId && !isFinishing){folderCounts=counts;entries=result;sortEntries();status.text="${entries.size} ${if(entries.size==1)"item" else "items"}${if(limited)" • Scan limit reached; browse storage for more" else ""}";bindList()}}
        }catch(e:Exception){runOnUiThread{if(token==requestId){entries=emptyList();content.removeAllViews();status.text=e.message ?: "Cannot read files";updateActions()}}}}
    }
    private fun sortEntries(){if(category=="Image album" && !photoSortChanged){entries=entries.sortedWith(compareByDescending<File>{photoDates[it.path] ?: it.lastModified()}.thenBy{it.name});return};val comp=when(sort){"Modified"->compareBy<File>{it.lastModified()};"Size"->compareBy<File>{if(it.isFile)it.length()else -1};"Type"->compareBy<File>{it.extension.lowercase(Locale.ROOT)};else->compareBy<File>{it.name.lowercase(Locale.ROOT)}};entries=entries.sortedWith(compareBy<File>{!it.isDirectory}.then(if(descending)comp.reversed()else comp))}
    private fun shown()=entries.filter{it.name.contains(search.text.toString(),true)}
    private fun bindList(){content.removeAllViews();val list:AbsListView=if(grid)GridView(this).apply{numColumns=if(resources.configuration.screenWidthDp>600)4 else 2;horizontalSpacing=dp(8);verticalSpacing=dp(8)}else ListView(this).apply{divider=android.graphics.drawable.ColorDrawable(Color.rgb(225,235,233));dividerHeight=dp(1)}
        list.isDrawSelectorOnTop=true;list.selector=entrySelector();list.adapter=adapter;list.choiceMode=AbsListView.CHOICE_MODE_NONE
        list.setOnItemClickListener{_,_,position,_->shown().getOrNull(position)?.let{if(selected.isNotEmpty())toggle(it)else if(it.isDirectory){forward.clear();openFolder(it)}else openFile(it)}}
        list.setOnItemLongClickListener{_,_,position,_->shown().getOrNull(position)?.let{toggle(it)};true}
        val detector=GestureDetector(this,object:GestureDetector.SimpleOnGestureListener(){override fun onDown(e:MotionEvent)=false;override fun onFling(e1:MotionEvent?,e2:MotionEvent,vx:Float,vy:Float):Boolean{if(e1==null||selected.isNotEmpty())return false;val dx=e2.x-e1.x;val dy=e2.y-e1.y;if(kotlin.math.abs(dx)>dp(110)&&kotlin.math.abs(dx)>kotlin.math.abs(dy)*2&&kotlin.math.abs(vx)>600){if(dx>0)up()else if(forward.isNotEmpty())openFolder(forward.removeAt(forward.lastIndex));return true};return false}})
        list.setOnTouchListener{_,event->detector.onTouchEvent(event)};content.addView(list,LinearLayout.LayoutParams(-1,-1));updateActions()}
    // The selector tracks the last touched/focused position, not checkbox selection.
    // Keep its idle state transparent; TV/keyboard focus is an outline only.
    private fun entrySelector()=android.graphics.drawable.StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed),android.graphics.drawable.ColorDrawable(Color.argb(22,0,0,0)))
        addState(intArrayOf(android.R.attr.state_focused),GradientDrawable().apply{setColor(Color.TRANSPARENT);setStroke(dp(2),teal)})
        addState(intArrayOf(),android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
    }
    private fun toggle(file:File){if(busy)return;if(MainStorageListing.isAndroidDirectory(base(),file)){toast("Android is a protected system folder. Open it to browse accessible media.");return};if(!selected.add(file))selected.remove(file);adapter.notifyDataSetChanged();updateActions()}
    private fun selectionAction(symbol:String,label:String,enabled:Boolean=true,run:()->Unit):View{
        val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(2),0,dp(2),0);alpha=if(enabled)1f else .45f;contentDescription=label;isFocusable=true;setOnClickListener{if(enabled && !busy)run()}}
        cell.addView(TextView(this).apply{text=symbol;textSize=25f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD},LinearLayout.LayoutParams(-1,dp(30)))
        cell.addView(TextView(this).apply{text=label;textSize=11f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);maxLines=1},LinearLayout.LayoutParams(-1,dp(18)))
        return cell
    }
    private fun moreSelection(anchor:View){
        if(selected.isEmpty())return
        val operations=mutableListOf<Pair<String,()->Unit>>()
        operations.add("Share" to {shareSelected()})
        operations.add("ZIP" to {zipSelection()})
        if(ArchiveActions.canExtract(selected))operations.add("Extract" to {extractionChoices(selected.toList())})
        if(selected.size==1){val file=selected.first();operations.add("Properties" to {properties(file)});if(file.isFile){operations.add("Open with" to {share(file,true)});if(FileManagerOps.category(file)=="Documents" && file.extension.lowercase() in setOf("txt","md","csv","json","xml","log"))operations.add("Edit text" to {editText(file)})}}
        HeaderMenus.show(this,anchor,operations)
    }
    private fun updateActions(){
        if(::selectAllTop.isInitialized){
            val selecting=!home && selected.isNotEmpty()
            selectAllTop.visibility=if(selecting)View.VISIBLE else View.GONE
            gridTop.visibility=if(selecting)View.VISIBLE else View.GONE
            searchButton.visibility=if(selecting)View.GONE else if(home)View.GONE else View.VISIBLE
            headerTitle.text=if(selecting)"${selected.size}/${shown().size}" else if(home)"Files" else (if(category==null)(if(current==null || current?.canonicalFile==base().canonicalFile) "Main storage" else current!!.name) else category ?: "Files")
            selectAllTop.contentDescription=if(selecting && selected.size==shown().size)"Deselect all" else "Select all"
            gridTop.contentDescription=if(grid)"Show list" else "Show grid"
        }
        productFooter.visibility=if(home)View.VISIBLE else View.GONE;actions.removeAllViews();if(category=="Images"){actionScroll.visibility=View.GONE;return};actionScroll.visibility=if(!home && (selected.isNotEmpty() || clipboard.isNotEmpty()))View.VISIBLE else View.GONE;if(home)return
        if(selected.isEmpty()){
            actions.setBackgroundColor(Color.rgb(247,249,248))
            actions.addView(button("+ New"){newItem()});actions.addView(button(if(grid)"List" else "Grid"){grid=!grid;prefs.edit().putBoolean("grid",grid).apply();bindList()});actions.addView(button("Sort"){sortDialog()});if(clipboard.isNotEmpty())actions.addView(button("Paste (${clipboard.size})"){paste()})
        }else{
            actions.setBackgroundColor(Color.rgb(0,49,65))
            val actionsToShow=listOf(Triple("▢","Copy",{capture(false)}),Triple("➜","Move",{capture(true)}),Triple("Ⅰ","Rename",{if(selected.size==1)rename(selected.first())}),Triple("▣","Delete",{deleteSelected()}))
            for((symbol,label,run) in actionsToShow){val cell=selectionAction(symbol,label,label!="Rename" || selected.size==1,run);actions.addView(cell,LinearLayout.LayoutParams(resources.displayMetrics.widthPixels/5,dp(52)))}
            val more=selectionAction("⋮","More"){moreSelection(actions.getChildAt(actions.childCount-1))};actions.addView(more,LinearLayout.LayoutParams(resources.displayMetrics.widthPixels/5,dp(52)))
        }
    }
    private fun capture(move:Boolean){if(category!=null){toast("Choose a destination in Main storage after copying")} ;clipboard=selected.toList();clipboardRoot=base();cut=move;selected.clear();adapter.notifyDataSetChanged();updateActions();toast("${clipboard.size} item(s) ready. Open destination folder, then Paste.")}
    private fun paste(){if(category!=null){toast("Open a destination folder in Main storage");return};val destination=current ?: return;val srcRoot=clipboardRoot ?: return;val dstRoot=base();val items=clipboard.toList();busy=true;status.text=if(cut)"Moving…" else "Copying…";work.execute{val errors=mutableListOf<String>();for(f in items)runCatching{FileManagerOps(srcRoot,showHidden).checked(f);FileManagerOps(dstRoot,showHidden).checked(destination,true);FileManagerOps(srcRoot,showHidden).transfer(f,destination,cut,dstRoot)}.onFailure{errors.add("${f.name}: ${it.message}")};runOnUiThread{busy=false;clipboard=emptyList();if(errors.isNotEmpty())message("Transfer result",errors.joinToString("\n"));refresh()}}}
    private fun deleteSelected(){val items=selected.toList();val root=base();busy=true;status.text="Moving to Recycle Bin…";work.execute{val failures=mutableListOf<String>();for(f in items){runCatching{TrashStore(root,true).put(f)}.onFailure{failures.add("${f.name}: ${it.message}")}};runOnUiThread{busy=false;selected.clear();if(failures.isNotEmpty())message("Delete result",failures.joinToString("\n"));refresh()}}}
    private fun newItem(){if(category!=null){toast("Open a folder in Main storage first");return};AlertDialog.Builder(this).setTitle("Create").setItems(arrayOf("Folder","Text file")){_,i->nameDialog(if(i==0)"New folder" else "New text file",""){name->val parent=current ?: return@nameDialog;val target=ops().child(parent,name);require(!target.exists()){ "Name already exists" };check(if(i==0)target.mkdir()else target.createNewFile()){ "Cannot create item" };if(i==0)openFolder(target)else refresh()}}.show()}
    private fun rename(file:File){nameDialog("Rename",file.name){name->ops().rename(file,name);selected.clear();refresh()}}
    private fun nameDialog(title:String,value:String,save:(String)->Unit){val input=EditText(this).apply{setText(value);isSingleLine=true;selectAll()};val d=AlertDialog.Builder(this).setTitle(title).setView(input).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create();d.setOnShowListener{d.getButton(-1).setOnClickListener{runCatching{save(input.text.toString().trim());d.dismiss()}.onFailure{input.error=it.message}}};d.show()}
    private fun editText(file:File){if(file.length()>1024*1024){toast("Text editor limit is 1 MB");return};val modified=file.lastModified();val length=file.length();val input=EditText(this).apply{setText(file.readText());minLines=8;gravity=Gravity.TOP;textSize=14f};val scroll=ScrollView(this).apply{addView(input)};val d=AlertDialog.Builder(this).setTitle(file.name).setView(scroll).setPositiveButton("Save",null).setNegativeButton("Cancel",null).create();d.setOnShowListener{d.getButton(-1).setOnClickListener{runCatching{ops().checked(file);check(file.lastModified()==modified && file.length()==length){"File changed. Reopen before editing."};val tmp=ops().child(file.parentFile!!,"Files-edit-${java.util.UUID.randomUUID()}.tmp");try{check(tmp.createNewFile());tmp.writeText(input.text.toString());check(tmp.renameTo(file)){"Could not save file"}}finally{tmp.delete()};d.dismiss();refresh()}.onFailure{toast(it.message ?: "Cannot save")}}};d.show()}
    private fun properties(file:File){PropertiesDialog.show(this,base(),file,work,showHidden)}
    private fun share(file:File,open:Boolean){if(open && file.extension.equals("apk",true)){ApkInstallerActivity.open(this,base(),file,showHidden);return};runCatching{ops().checked(file);val uri=FileProvider.getUriForFile(this,"$packageName.files",file);val intent=if(open)Intent(Intent.ACTION_VIEW).setDataAndType(uri,FileDetails.mime(file))else Intent(Intent.ACTION_SEND).setType(FileDetails.mime(file)).putExtra(Intent.EXTRA_STREAM,uri);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.clipData=ClipData.newRawUri(file.name,uri);startActivity(Intent.createChooser(intent,if(open)"Open with" else "Share"))}.onFailure{toast("No compatible app: ${it.message}")}}
    private fun message(title:String,value:String){AlertDialog.Builder(this).setTitle(title).setMessage(value).setPositiveButton("Close",null).show()}
    private fun openFile(file:File){if(file.extension.equals("apk",true)){ApkInstallerActivity.open(this,base(),file,showHidden);return};if(FileManagerOps.category(file)=="Archives"){archiveMenu(file);return};val shown=shown().filter{it.isFile};val preferences=getSharedPreferences("files-preview",MODE_PRIVATE);preferences.edit().putBoolean("showHidden",showHidden).putString("root",base().path).putString("file",file.path).putString("siblings",org.json.JSONArray(shown.take(5000).map{it.path}.let { if(file.path in it)it else listOf(file.path) }).toString()).apply();startActivity(Intent(this,FilesPreviewActivity::class.java))}
    private fun zipSelection(){
        val items=selected.toList();if(items.isEmpty())return
        val root=base();val folder=if(category==null)current ?: root else root
        val suggested=ZipNaming.suggest(folder.name)
        val options=arrayOf("Add to \"$suggested\"", "Add to ZIP…")
        AlertDialog.Builder(this).setTitle("ZIP").setItems(options){_,index->
            if(index==0)createZip(items,root,folder,suggested)
            else nameDialog("ZIP name",suggested){name->createZip(items,root,folder,ZipNaming.ensureExtension(name))}
        }.show()
    }
    private fun createZip(items:List<File>,root:File,folder:File,zipName:String){
        try{
            val name=ZipNaming.ensureExtension(zipName)
            val target=FileManagerOps(root,showHidden).child(folder,name)
            if(target.exists()){
                AlertDialog.Builder(this).setTitle("ZIP already exists")
                    .setMessage("${target.name} already exists. Keep the existing ZIP and create a different name?")
                    .setPositiveButton("Rename ZIP"){_,_->nameDialog("ZIP name",ZipNaming.alternative(name)){custom->createZip(items,root,folder,custom)}}
                    .setNegativeButton("Cancel",null).show()
                return
            }
            busy=true;status.text="Creating ZIP…"
            work.execute{val result=runCatching{LocalArchives.compress(root,items,target,showHidden)}
                runOnUiThread{busy=false;result.onSuccess{toast("ZIP created: ${target.name}")}.onFailure{message("ZIP failed",it.message ?: "Failed")};refresh()}}
        }catch(e:Exception){message("ZIP failed",e.message ?: "Invalid ZIP name")}
    }
    private fun archiveMenu(file:File){
        val labels=(if(ArchiveActions.supported(file))listOf("View contents")+ArchiveActions.choices(listOf(file))else emptyList())+listOf("Open with","Share","Properties")
        AlertDialog.Builder(this).setTitle(file.name).setItems(labels.toTypedArray()){_,i->when(labels[i]){
            "View contents"->archiveContents(file)
            "Open with"->share(file,true)
            "Share"->share(file,false)
            "Properties"->properties(file)
            else->extractionChoice(listOf(file),ArchiveActions.choices(listOf(file)).indexOf(labels[i]))
        }}.show()
    }
    private fun extractionChoices(files:List<File>){if(busy || !ArchiveActions.canExtract(files))return;AlertDialog.Builder(this).setTitle(if(files.size==1)files.single().name else "Extract ${files.size} archives").setItems(ArchiveActions.choices(files).toTypedArray()){_,i->extractionChoice(files,i)}.show()}
    private fun extractionChoice(files:List<File>,mode:Int){if(busy)return;val sourceRoot=base();if(mode==2)chooseExtractionFolder(sourceRoot,files.first().parentFile ?: sourceRoot){destinationRoot,folder->extractionDialog(files,sourceRoot,mode,destinationRoot,folder)}else extractionDialog(files,sourceRoot,mode,sourceRoot,null)}
    private fun chooseExtractionFolder(startRoot:File,startFolder:File,chosen:(File,File)->Unit){
        fun browse(root:File,folder:File){val ops=FileManagerOps(root,showHidden);val dirs=(folder.listFiles() ?: emptyArray()).filter{it.isDirectory && runCatching{ops.checked(it);true}.getOrDefault(false)}.sortedBy{it.name.lowercase()};val hasParent=folder!=root
            val items=(if(hasParent)listOf("↑ Up")else emptyList())+dirs.map{it.name}
            AlertDialog.Builder(this).setTitle("Extract destination\n"+folder.path).setItems(items.toTypedArray()){_,index->if(hasParent && index==0){var parent=folder.parentFile ?: root;while(parent!=root && runCatching{ops.checked(parent,true)}.isFailure)parent=parent.parentFile ?: root;browse(root,parent)}else browse(root,dirs[index-(if(hasParent)1 else 0)])}.setPositiveButton("Use this folder"){_,_->chosen(root,folder)}.setNeutralButton("Storage"){_,_->AlertDialog.Builder(this).setTitle("Storage").setItems(roots.map{it.name}.toTypedArray()){_,i->browse(roots[i].folder,roots[i].folder)}.show()}.setNegativeButton("Cancel",null).show()
        };browse(startRoot,startFolder)
    }
    private fun extractionDialog(files:List<File>,sourceRoot:File,mode:Int,destinationRoot:File,chosenFolder:File?){
        val name=EditText(this).apply{hint="Folder name";isSingleLine=true;setText(ArchiveActions.folderName(files.first()))}
        val subfolders=CheckBox(this).apply{text=if(files.size==1)"Create archive-name folder" else "Create a folder for each archive";isChecked=true}
        val password=EditText(this).apply{hint="Password (if encrypted)";isSingleLine=true;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD}
        val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),0,dp(16),0);if(mode==1 && files.size==1)addView(name);if(mode==2)addView(subfolders);addView(password)}
        val dialog=AlertDialog.Builder(this).setTitle("Extract archive"+(if(files.size>1)"s (${files.size})" else "")).setView(panel).setPositiveButton("Extract",null).setNegativeButton("Cancel",null).create()
        dialog.setOnShowListener{dialog.getButton(-1).setOnClickListener{
            val folderName=name.text.toString().trim();if(mode==1 && files.size==1 && !SharedFiles(destinationRoot,showHidden).validName(folderName)){name.error="Enter a valid folder name";return@setOnClickListener}
            val pass=password.text.toString();val createFolders=mode==1 || mode==2 && subfolders.isChecked;dialog.dismiss();performExtraction(files,sourceRoot,mode,destinationRoot,chosenFolder,createFolders,folderName,pass)
        }};dialog.show()
    }
    private fun performExtraction(files:List<File>,sourceRoot:File,mode:Int,destinationRoot:File,chosenFolder:File?,createFolders:Boolean,name:String,password:String){
        busy=true;status.text="Extracting…";val hidden=showHidden;work.execute{val messages=mutableListOf<String>();var firstDestination:File?=null
            for(file in files){if(Thread.currentThread().isInterrupted){messages.add("Extraction cancelled");break};runCatching{
                val parent=if(mode==2)chosenFolder ?: error("Choose a destination")else file.parentFile ?: error("Archive folder unavailable")
                val target=if(createFolders)LocalArchives.availableFolder(destinationRoot,parent,if(files.size==1 && mode==1)name else ArchiveActions.folderName(file),hidden)else parent
                if(createFolders){val count=LocalArchives.extract(sourceRoot,file,target,password,hidden,destinationRoot);messages.add("${file.name}: $count files → ${target.path}")}else{val result=LocalArchives.extractInto(sourceRoot,file,target,password,hidden,destinationRoot);messages.add("${file.name}: ${result.files} files, ${result.renamed} name conflicts kept → ${target.path}")}
                if(firstDestination==null)firstDestination=target
            }.onFailure{messages.add("${file.name}: ${it.message}")}}
            runOnUiThread{if(isDestroyed)return@runOnUiThread;busy=false;selected.clear();firstDestination?.let{openPlace(it)} ?: refresh();message("Extraction result",messages.joinToString("\n\n"))}
        }
    }
    private fun archiveContents(file:File){
        val password=EditText(this).apply{hint="Password (if encrypted)";isSingleLine=true;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD}
        AlertDialog.Builder(this).setTitle("Archive contents").setView(password).setPositiveButton("View"){_,_->val pass=password.text.toString();busy=true;status.text="Reading archive…";work.execute{val result=runCatching{LocalArchives.entries(file,pass).joinToString("\n"){it.name+if(it.directory)" /" else " · "+FileManagerOps.formatBytes(it.bytes.coerceAtLeast(0))}};runOnUiThread{if(isDestroyed)return@runOnUiThread;busy=false;result.onSuccess{message("Archive contents",it)}.onFailure{message("Archive could not be opened",it.message ?: "Use Open with for unsupported formats")}}}}.setNegativeButton("Cancel",null).show()
    }
    private fun shareSelected(){
        val files=selected.filter{it.isFile};if(files.size!=selected.size){toast("For folders, create a ZIP first, then share the ZIP.");return}
        runCatching{val uris=ArrayList(files.map{ops().checked(it);FileProvider.getUriForFile(this,"$packageName.files",it)});val intent=if(uris.size==1)Intent(Intent.ACTION_SEND).setType(FileDetails.mime(files.first())).putExtra(Intent.EXTRA_STREAM,uris.first())else Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);if(uris.isNotEmpty()){intent.clipData=ClipData.newRawUri("Files",uris.first()).apply{uris.drop(1).forEach{addItem(ClipData.Item(it))}}};startActivity(Intent.createChooser(intent,"Share files"))}.onFailure{toast(it.message ?: "No compatible app")}
    }
    private fun cloudMenu(){
        AlertDialog.Builder(this).setTitle("Cloud").setItems(arrayOf("Google Drive · upload / download","Other document providers")){_,which->if(which==0)startActivity(Intent(this,GoogleDriveActivity::class.java).apply{current?.let{putExtra("local",it.path)}})else{
            val linked=prefs.getString("cloudUri",null)!=null
            AlertDialog.Builder(this).setTitle("Document provider folder").setPositiveButton(if(linked)"Sync connected folder" else "Connect folder"){_,_->if(linked)cloudDirection()else connectCloud()}.setNeutralButton("Choose / change folder"){_,_->connectCloud()}.setNegativeButton("Close",null).show()
        }}.show()
    }
    private fun connectCloud(){runCatching{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION),82)}.onFailure{toast("No document provider available on this device")}}
    @Deprecated("Android platform result") override fun onActivityResult(request:Int,result:Int,data:Intent?){super.onActivityResult(request,result,data);if(request==94 && result==RESULT_OK){if(data?.getBooleanExtra("saved_apks",false)==true)intent.putExtra("apps_pending_saved",true)else data?.getStringExtra("folder")?.let{intent.putExtra("apps_pending_folder",it)};return};if(request==82 && result==RESULT_OK){val uri=data?.data ?: return;runCatching{val flags=data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION);contentResolver.takePersistableUriPermission(uri,flags);val folder=androidx.documentfile.provider.DocumentFile.fromTreeUri(this,uri);require(folder?.isDirectory==true && folder.canRead()){"Provider did not grant folder access"};prefs.edit().putString("cloudUri",uri.toString()).apply();toast("Folder connected. Open a local folder, then choose Cloud → Sync.")}.onFailure{toast(it.message ?: "Cannot connect provider")}}}
    private fun cloudDirection(){if(home || category!=null){toast("First open the local folder you want to sync in Main storage.");return};val uri=prefs.getString("cloudUri",null) ?: return;val local=current ?: return;val root=base();AlertDialog.Builder(this).setTitle("Manual sync · keep both").setItems(arrayOf("Local → provider folder","Provider folder → local")){_,direction->busy=true;status.text="Syncing…";work.execute{val result=runCatching{val folder=androidx.documentfile.provider.DocumentFile.fromTreeUri(this,Uri.parse(uri)) ?: error("Provider unavailable");CloudFolders.sync(this,root,local,folder,direction==0,showHidden)};runOnUiThread{busy=false;result.onSuccess{message("Sync complete","${it.added} files copied; ${it.same} identical files skipped. No files deleted.")}.onFailure{message("Sync stopped",(it.message ?: "Provider unavailable")+"\nCompleted copies remain. Check both folders before retrying.")};refresh()}}}.show()}
    private fun trashMenu(){
        if(roots.isEmpty())return;val root=base();busy=true;status.text="Reading Recycle Bin…";work.execute{val result=runCatching{TrashStore(root,true).entries()};runOnUiThread{busy=false;result.onSuccess{items->if(items.isEmpty()){message("Recycle Bin","Empty on ${roots[volume].name}");return@onSuccess};AlertDialog.Builder(this).setTitle("Recycle Bin · ${items.size} items").setItems(items.map{File(it.original).name+"\nDeleted "+FileDetails.date(it.deletedAt)}.toTypedArray()){_,index->val entry=items[index];AlertDialog.Builder(this).setTitle(File(entry.original).name).setMessage("Original: ${entry.original}\nDeleted: ${FileDetails.date(entry.deletedAt)}").setPositiveButton("Restore"){_,_->binAction(root,entry,false)}.setNegativeButton("Delete forever"){_,_->binAction(root,entry,true)}.setNeutralButton("Close",null).show()}.setPositiveButton("Close",null).setNegativeButton("Empty Bin"){_,_->busy=true;work.execute{val errors=items.mapNotNull{runCatching{TrashStore(root,true).purge(it)}.exceptionOrNull()?.message};runOnUiThread{busy=false;message("Recycle Bin",if(errors.isEmpty())"Bin emptied" else errors.joinToString("\n"));if(!home)refresh()}}}.show()}.onFailure{message("Recycle Bin unavailable",it.message ?: "Cannot read Bin")}}}
    }
    private fun binAction(root:File,entry:TrashStore.Entry,purge:Boolean){busy=true;work.execute{val result=runCatching{if(purge){TrashStore(root,true).purge(entry);"Permanently deleted"}else "Restored: "+TrashStore(root,true).restore(entry).name};runOnUiThread{busy=false;result.onSuccess{toast(it)}.onFailure{message("Bin action failed",it.message ?: "Failed")};if(!home)refresh()}}}
    private fun up(){if(busy)return;if(selected.isNotEmpty()){selected.clear();adapter.notifyDataSetChanged();updateActions();return};if(home)return;if(category=="Image album"){openCategory("Images");return};if(category!=null){showHome();return};val here=current ?: return;if(here==base()){showHome();return};forward.add(here);var parent=here.parentFile ?: base();while(parent!=base() && !MainStorageListing.isAndroidDirectory(base(),parent) && runCatching{ops().checked(parent,true)}.isFailure)parent=parent.parentFile ?: base();openFolder(parent)}
    @Deprecated("Android platform back") override fun onBackPressed(){if(drawer.isDrawerVisible(Gravity.LEFT)){drawer.closeDrawer(Gravity.LEFT);return};if(home || roots.isEmpty())super.onBackPressed()else up()}
    private fun openPhotoAlbum(album:ImageAlbums.Album){
        val index=roots.indexOfFirst{it.folder==album.root};if(index<0){toast("Album storage is disconnected");return};volume=index;home=false;category="Image album";current=album.folder;photoSortChanged=false;selected.clear();search.setText("");refresh()
    }
    private fun visibleAlbums()=photoAlbums.filter{it.name.contains(search.text.toString(),true)||it.folder.path.contains(search.text.toString(),true)}
    private fun bindAlbums(){
        content.removeAllViews();val columns=if(resources.configuration.screenWidthDp>600)5 else 3
        val list=GridView(this).apply{numColumns=columns;horizontalSpacing=dp(6);verticalSpacing=dp(8);setPadding(dp(6),dp(4),dp(6),dp(4));adapter=albumsAdapter;selector=android.graphics.drawable.ColorDrawable(Color.argb(65,0,121,112));isDrawSelectorOnTop=true;setOnItemClickListener{_,_,position,_->visibleAlbums().getOrNull(position)?.let{openPhotoAlbum(it)}}}
        content.addView(list,LinearLayout.LayoutParams(-1,-1));updateActions()
    }
    private inner class AlbumsAdapter:BaseAdapter(){
        override fun getCount()=visibleAlbums().size;override fun getItem(position:Int)=visibleAlbums()[position];override fun getItemId(position:Int)=position.toLong()
        override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
            val album=getItem(position);val columns=if(resources.configuration.screenWidthDp>600)5 else 3;val height=dp((resources.configuration.screenWidthDp-24)/columns)
            val tile=LinearLayout(this@FilesActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(2),0,dp(2),dp(3));contentDescription="${album.name}, ${album.photos.size} photos, ${album.folder.path}"}
            val cover=ImageView(this@FilesActivity).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageDrawable(ManagerIcon("Images"));tag=album.cover.file.path;contentDescription="Album cover ${album.name}"};tile.addView(cover,LinearLayout.LayoutParams(-1,height))
            tile.addView(text("${album.name} (${album.photos.size})",13f).apply{gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END})
            val storage=roots.firstOrNull{it.folder==album.root}?.name ?: "Storage";tile.addView(text(storage+album.folder.path.removePrefix(album.root.path),10f).apply{setTextColor(Color.GRAY);maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.MIDDLE})
            thumbs.execute{mediaThumbnails.load(album.root,album.cover.file,showHidden)?.let{bitmap->runOnUiThread{if(cover.tag==album.cover.file.path && !isDestroyed){cover.scaleType=ImageView.ScaleType.CENTER_CROP;cover.setImageBitmap(bitmap)}}}}
            return tile
        }
    }
    private inner class EntriesAdapter:BaseAdapter(){override fun getCount()=shown().size;override fun getItem(position:Int)=shown()[position];override fun getItemId(position:Int)=position.toLong()
        override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val file=getItem(position);val tile=LinearLayout(this@FilesActivity).apply{orientation=if(grid)LinearLayout.VERTICAL else LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(6),dp(2),dp(6),dp(2));setBackgroundColor(if(file in selected)Color.rgb(215,239,234)else Color.WHITE)}
            val check=CheckBox(this@FilesActivity).apply{isChecked=file in selected;contentDescription="Select ${file.name}";isFocusable=false;isFocusableInTouchMode=false;setOnClickListener{toggle(file)}};if(!grid)tile.addView(check,LinearLayout.LayoutParams(dp(40),dp(40)))
            val icon=ImageView(this@FilesActivity).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageDrawable(ManagerIcon(FileTypeIcons.kind(file),contentScale=if(file.isDirectory)1.08f else 1.18f));background=GradientDrawable().apply{setColor(Color.rgb(250,250,250));cornerRadius=dp(3).toFloat()};clipToOutline=true;contentDescription=if(file.isDirectory)"Folder" else  FileManagerOps.category(file)};if(grid){val imageArea=FrameLayout(this@FilesActivity);imageArea.addView(icon,FrameLayout.LayoutParams(-1,dp(96)));imageArea.addView(check,FrameLayout.LayoutParams(dp(40),dp(40),Gravity.TOP or Gravity.RIGHT));tile.addView(imageArea,LinearLayout.LayoutParams(-1,dp(96)))}else tile.addView(icon,LinearLayout.LayoutParams(dp(56),dp(56)))
            if(!file.isDirectory && FileManagerOps.category(file) in setOf("Images","Videos")){val root=base();icon.tag=file.path;thumbs.execute{mediaThumbnails.load(root,file,showHidden)?.let{bitmap->runOnUiThread{if(icon.tag==file.path && !isFinishing && !isDestroyed){icon.scaleType=ImageView.ScaleType.CENTER_CROP;icon.setImageBitmap(bitmap)}}}}}

            val labels=LinearLayout(this@FilesActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(6),0,0,0)};labels.addView(text(file.name,15f).apply{maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END})
            labels.addView(text(if(file.isDirectory)"Folder" else  FileManagerOps.formatBytes(file.length()),12f));labels.addView(text(FileDetails.date(file.lastModified()),11f));tile.addView(labels,LinearLayout.LayoutParams(if(grid)-1 else 0,-2,if(grid)0f else 1f));return tile}
    }
}
