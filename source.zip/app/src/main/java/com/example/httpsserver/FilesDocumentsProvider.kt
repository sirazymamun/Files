package com.example.httpsserver

import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.os.FileObserver
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.DocumentsProvider
import java.io.File
import java.io.FileNotFoundException
import android.util.Base64

/** Read-only SAF integration. Only documents selected in Android's picker receive URI grants. */
class FilesDocumentsProvider:DocumentsProvider(){
 companion object{
  private val ROOT_COLUMNS=arrayOf(DocumentsContract.Root.COLUMN_ROOT_ID,DocumentsContract.Root.COLUMN_DOCUMENT_ID,DocumentsContract.Root.COLUMN_TITLE,DocumentsContract.Root.COLUMN_SUMMARY,DocumentsContract.Root.COLUMN_FLAGS,DocumentsContract.Root.COLUMN_ICON,DocumentsContract.Root.COLUMN_MIME_TYPES,DocumentsContract.Root.COLUMN_AVAILABLE_BYTES)
  private val DOCUMENT_COLUMNS=arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED,DocumentsContract.Document.COLUMN_FLAGS)
  private const val UNAVAILABLE="storage-unavailable"
  internal fun id(volume:String,relative:String)=volume+":"+Base64.encodeToString(relative.toByteArray(Charsets.UTF_8),Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
  fun notifyRoots(context:Context){context.contentResolver.notifyChange(DocumentsContract.buildRootsUri(context.packageName+".documents"),null)}
 }
 private val watches=linkedMapOf<String,FileObserver>()
 private val ctx get()=context ?: throw FileNotFoundException("Provider unavailable")
 private fun volumes()=runCatching{StorageAccess.volumes(ctx)}.getOrDefault(emptyList())
 private fun hidden()=ctx.getSharedPreferences("files-manager",Context.MODE_PRIVATE).getBoolean("showHidden",false)
 override fun onCreate()=true
 override fun shutdown(){synchronized(watches){watches.values.forEach{it.stopWatching()};watches.clear()};super.shutdown()}
 private fun watch(folder:File,uri:android.net.Uri){synchronized(watches){if(folder.path in watches)return;if(watches.size>=16){val first=watches.entries.first();first.value.stopWatching();watches.remove(first.key)};val observer=object:FileObserver(folder.path,FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_TO or FileObserver.MOVED_FROM or FileObserver.CLOSE_WRITE or FileObserver.DELETE_SELF){override fun onEvent(event:Int,path:String?){context?.contentResolver?.notifyChange(uri,null)}};watches[folder.path]=observer;runCatching{observer.startWatching()}}}

 private fun add(cursor:MatrixCursor,values:Map<String,Any?>){val row=cursor.newRow();cursor.columnNames.forEach{row.add(it,values[it])}}
 override fun queryRoots(projection:Array<out String>?):Cursor{
  val cursor=MatrixCursor(projection ?: ROOT_COLUMNS);val roots=volumes()
  if(roots.isEmpty()){add(cursor,mapOf(DocumentsContract.Root.COLUMN_ROOT_ID to UNAVAILABLE,DocumentsContract.Root.COLUMN_DOCUMENT_ID to UNAVAILABLE,DocumentsContract.Root.COLUMN_TITLE to "Files",DocumentsContract.Root.COLUMN_SUMMARY to "Open Files and allow storage access",DocumentsContract.Root.COLUMN_FLAGS to DocumentsContract.Root.FLAG_LOCAL_ONLY,DocumentsContract.Root.COLUMN_ICON to R.mipmap.ic_launcher,DocumentsContract.Root.COLUMN_MIME_TYPES to "*/*"));return cursor}
  roots.forEachIndexed{i,root->add(cursor,mapOf(DocumentsContract.Root.COLUMN_ROOT_ID to root.id,DocumentsContract.Root.COLUMN_DOCUMENT_ID to id(root.id,""),DocumentsContract.Root.COLUMN_TITLE to if(i==0)"Files" else "Files · ${root.name}",DocumentsContract.Root.COLUMN_SUMMARY to root.name,DocumentsContract.Root.COLUMN_FLAGS to (DocumentsContract.Root.FLAG_LOCAL_ONLY or DocumentsContract.Root.FLAG_SUPPORTS_IS_CHILD or DocumentsContract.Root.FLAG_SUPPORTS_SEARCH),DocumentsContract.Root.COLUMN_ICON to R.mipmap.ic_launcher,DocumentsContract.Root.COLUMN_MIME_TYPES to "*/*",DocumentsContract.Root.COLUMN_AVAILABLE_BYTES to root.folder.usableSpace))};return cursor
 }
 private data class Resolved(val volume:StorageVolumeRoot,val file:File,val ops:FileManagerOps)
 private fun resolve(documentId:String):Resolved{
  try{val split=documentId.indexOf(':');require(split>0);val volumeId=documentId.substring(0,split);val encoded=documentId.substring(split+1);val bytes=Base64.decode(encoded,Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING);val relative=String(bytes,Charsets.UTF_8);require(id(volumeId,relative)==documentId);require(!relative.startsWith('/') && !relative.contains('\\') && !relative.contains('\u0000') && (relative.isEmpty() || relative.split('/').none{it.isEmpty()||it=="."||it==".."}));val root=volumes().firstOrNull{it.id==volumeId} ?: throw FileNotFoundException("Storage permission is missing or this volume was removed");val ops=FileManagerOps(root.folder,hidden());val file=if(relative.isEmpty())root.folder else File(root.folder,relative);ops.checked(file,true);require(file.exists() && file.canRead());return Resolved(root,file,ops)
  }catch(e:Exception){throw FileNotFoundException("Document is unavailable or protected")}
 }
 private fun documentId(item:Resolved,file:File)=id(item.volume.id,file.path.removePrefix(item.volume.folder.path).trimStart('/'))
 private fun document(cursor:MatrixCursor,item:Resolved,file:File){item.ops.checked(file,true);add(cursor,mapOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID to documentId(item,file),DocumentsContract.Document.COLUMN_DISPLAY_NAME to if(file==item.volume.folder)item.volume.name else file.name,DocumentsContract.Document.COLUMN_MIME_TYPE to if(file.isDirectory)DocumentsContract.Document.MIME_TYPE_DIR else FileDetails.mime(file),DocumentsContract.Document.COLUMN_SIZE to if(file.isFile)file.length() else null,DocumentsContract.Document.COLUMN_LAST_MODIFIED to file.lastModified(),DocumentsContract.Document.COLUMN_FLAGS to 0))}
 override fun queryDocument(documentId:String,projection:Array<out String>?):Cursor{
  val cursor=MatrixCursor(projection ?: DOCUMENT_COLUMNS)
  if(documentId==UNAVAILABLE){add(cursor,mapOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID to UNAVAILABLE,DocumentsContract.Document.COLUMN_DISPLAY_NAME to "Allow storage access in Files",DocumentsContract.Document.COLUMN_MIME_TYPE to DocumentsContract.Document.MIME_TYPE_DIR,DocumentsContract.Document.COLUMN_FLAGS to 0));return cursor}
  val item=resolve(documentId);document(cursor,item,item.file);return cursor
 }
 override fun queryChildDocuments(parentDocumentId:String,projection:Array<out String>?,sortOrder:String?):Cursor{
  val cursor=MatrixCursor(projection ?: DOCUMENT_COLUMNS);if(parentDocumentId==UNAVAILABLE)return cursor
  val item=resolve(parentDocumentId);if(!item.file.isDirectory)throw FileNotFoundException("Not a folder")
  val children=item.file.listFiles() ?: throw FileNotFoundException("Folder cannot be read")
  children.filter{runCatching{item.ops.checked(it);it.canRead() && (it.isDirectory||it.isFile)}.getOrDefault(false)}.sortedWith(compareBy<File>{!it.isDirectory}.thenBy{it.name.lowercase()}).forEach{document(cursor,item,it)}
  val uri=DocumentsContract.buildChildDocumentsUri(ctx.packageName+".documents",parentDocumentId);cursor.setNotificationUri(ctx.contentResolver,uri);watch(item.file,uri);return cursor
 }
 override fun openDocument(documentId:String,mode:String,signal:CancellationSignal?):ParcelFileDescriptor{
  if(mode!="r")throw FileNotFoundException("Files provides read-only access to external apps")
  signal?.throwIfCanceled();val item=resolve(documentId);if(!item.file.isFile)throw FileNotFoundException("Choose a file")
  val descriptor=ParcelFileDescriptor.open(item.file,ParcelFileDescriptor.MODE_READ_ONLY)
  try{signal?.throwIfCanceled();item.ops.checked(item.file);return descriptor}catch(e:Exception){descriptor.close();throw e}
 }
 override fun getDocumentType(documentId:String):String{if(documentId==UNAVAILABLE)return DocumentsContract.Document.MIME_TYPE_DIR;val item=resolve(documentId);return if(item.file.isDirectory)DocumentsContract.Document.MIME_TYPE_DIR else FileDetails.mime(item.file)}
 override fun isChildDocument(parentDocumentId:String,documentId:String):Boolean=runCatching{val parent=resolve(parentDocumentId);val child=resolve(documentId);parent.volume.id==child.volume.id && parent.file.isDirectory && (parent.file==child.file || child.file.path.startsWith(parent.file.path+"/"))}.getOrDefault(false)
 override fun querySearchDocuments(rootId:String,query:String,projection:Array<out String>?):Cursor{
  val cursor=MatrixCursor(projection ?: DOCUMENT_COLUMNS);val root=volumes().firstOrNull{it.id==rootId} ?: return cursor;val item=resolve(id(root.id,""));var count=0;val start=System.nanoTime();val todo=java.util.ArrayDeque<Pair<File,Int>>();todo.add(root.folder to 0)
  while(todo.isNotEmpty() && count<20000 && cursor.count<100 && System.nanoTime()-start<2000000000L){val (folder,depth)=todo.removeFirst();if(depth>64)continue;for(file in folder.listFiles() ?: emptyArray()){
   count++;if(count>20000||cursor.count>=100||System.nanoTime()-start>=2000000000L)break
   if(runCatching{item.ops.checked(file);file.canRead() && (file.isDirectory||file.isFile)}.getOrDefault(false)){if(file.name.contains(query,true))document(cursor,item,file);if(file.isDirectory)todo.add(file to depth+1)}
  }};return cursor
 }
}
