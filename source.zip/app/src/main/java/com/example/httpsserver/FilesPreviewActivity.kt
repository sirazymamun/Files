package com.example.httpsserver

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import org.json.JSONArray
import java.io.File
import java.util.concurrent.Executors

class FilesPreviewActivity:Activity(){
 private var showHidden=false;private lateinit var root:File;private lateinit var file:File;private var siblings=listOf<File>()
 private lateinit var box:LinearLayout;private lateinit var heading:TextView;private lateinit var status:TextView;private lateinit var previous:Button;private lateinit var next:Button
 private val worker=Executors.newSingleThreadExecutor();private var generation=0;private var media:VideoView?=null;private var busy=false;private var pdfPage=0
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun button(label:String,action:()->Unit)=Button(this).apply{text=label;isAllCaps=false;textSize=13f;stateListAnimator=null;elevation=0f;minWidth=0;minimumWidth=0;setTextColor(Color.rgb(0,121,112));setPadding(dp(10),0,dp(10),0);background=android.graphics.drawable.StateListDrawable().apply{addState(intArrayOf(android.R.attr.state_focused),android.graphics.drawable.ColorDrawable(Color.rgb(217,237,233)));addState(intArrayOf(android.R.attr.state_pressed),android.graphics.drawable.ColorDrawable(Color.rgb(226,241,238)));addState(intArrayOf(),android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))};setOnClickListener{if(!busy)action()}}
 override fun onCreate(state:Bundle?){super.onCreate(state)
  val prefs=getSharedPreferences("files-preview",MODE_PRIVATE);showHidden=prefs.getBoolean("showHidden",false);root=File(prefs.getString("root","") ?: "");file=File(state?.getString("file") ?: prefs.getString("file","") ?: "")
  try{FileManagerOps(root,showHidden).checked(file);check(file.isFile);val a=JSONArray(prefs.getString("siblings","[]"));siblings=(0 until a.length()).map{File(a.getString(it))}.filter{runCatching{FileManagerOps(root,showHidden).checked(it);it.isFile}.getOrDefault(false)}}catch(_:Exception){finish();return}
  if(state==null && file.extension.lowercase() in setOf("doc","docx","xls","xlsx","ppt","pptx","odt","ods","odp") && external(false)){finish();return}
  window.statusBarColor=Color.rgb(32,32,32);window.navigationBarColor=Color.WHITE
  val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(Color.rgb(32,32,32))}
  fun headerIcon(kind:String,label:String,action:()->Unit)=ImageButton(this).apply{setImageDrawable(ManagerIcon(kind));contentDescription=label;setPadding(dp(10),dp(10),dp(10),dp(10));setBackgroundColor(Color.TRANSPARENT);setOnClickListener{if(!busy)action()}}
  top.addView(headerIcon("Up","Back"){finish()},LinearLayout.LayoutParams(dp(48),dp(60)))
  heading=TextView(this).apply{textSize=16f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD);maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(dp(2),0,dp(4),0)};top.addView(heading,LinearLayout.LayoutParams(0,-2,1f));top.addView(HeaderMenus.more(this){options(it)},LinearLayout.LayoutParams(dp(48),dp(60)));shell.addView(top)
  status=TextView(this).apply{textSize=11f;setTextColor(Color.rgb(110,110,110));setPadding(dp(12),dp(5),dp(12),dp(5))};shell.addView(status)
  box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setBackgroundColor(Color.rgb(245,246,246))};shell.addView(box,LinearLayout.LayoutParams(-1,0,1f))
  fun tool(label:String,kind:String,action:()->Unit)=button(label,action).apply{textSize=12f;setTextColor(Color.WHITE);maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(dp(2),dp(4),dp(2),dp(3));val icon=ManagerIcon(kind).apply{setBounds(0,0,dp(24),dp(24))};setCompoundDrawables(null,icon,null,null);compoundDrawablePadding=dp(2);background=android.graphics.drawable.StateListDrawable().apply{addState(intArrayOf(android.R.attr.state_focused),android.graphics.drawable.ColorDrawable(Color.rgb(43,100,110)));addState(intArrayOf(android.R.attr.state_pressed),android.graphics.drawable.ColorDrawable(Color.rgb(43,100,110)));addState(intArrayOf(),android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))}}
  val tools=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setBackgroundColor(Color.rgb(0,48,62))}
  previous=tool("Previous","Previous"){go(-1)};next=tool("Next","Next"){go(1)}
  for(view in listOf(previous,tool("Properties","Info"){PropertiesDialog.show(this,root,file,worker,showHidden)},tool("Open with","Open with"){external(false)},tool("Delete","Delete"){delete()},next))tools.addView(view,LinearLayout.LayoutParams(0,dp(56),1f))
  shell.addView(tools);setContentView(shell);render()
 }
 override fun onResume(){super.onResume();if(!StorageAccess.hasFullAccess(this))finish()}
 override fun onSaveInstanceState(out:Bundle){out.putString("file",file.path);super.onSaveInstanceState(out)}
 override fun onPause(){media?.pause();super.onPause()}
 override fun onDestroy(){generation++;media?.stopPlayback();worker.shutdownNow();super.onDestroy()}
 private fun validSiblings(){siblings=siblings.filter{it.isFile && it.canRead() && runCatching{FileManagerOps(root,showHidden).checked(it);true}.getOrDefault(false)}}
 private fun go(delta:Int){if(busy)return;validSiblings();val index=siblings.indexOf(file);siblings.getOrNull(index+delta)?.let{file=it;pdfPage=0;render()}}
 private fun render(){
  val token=++generation;media?.stopPlayback();media=null;box.removeAllViews();validSiblings();val index=siblings.indexOf(file);previous.isEnabled=index>0;next.isEnabled=index>=0 && index<siblings.lastIndex;previous.alpha=if(previous.isEnabled)1f else .4f;next.alpha=if(next.isEnabled)1f else .4f;heading.text=file.name;status.text="${index+1} / ${siblings.size}  ·  ${FileManagerOps.formatBytes(file.length())}\n${FileDetails.date(file.lastModified())}"
  if(!file.exists()){status.text="File no longer exists";return}
  when(FileManagerOps.category(file)){
   "Images"->{val image=ZoomImage(this,{go(it)});box.addView(image,LinearLayout.LayoutParams(-1,-1));val target=file;worker.execute{val bitmap=runCatching{decode(target)}.getOrNull();runOnUiThread{if(token==generation){if(bitmap!=null)image.setImageBitmap(bitmap)else status.text="Preview unavailable. Use Open with."}}}}
   "Videos","Audio"->{val player=VideoView(this);media=player;box.addView(player,LinearLayout.LayoutParams(-1,if(FileManagerOps.category(file)=="Audio")dp(180)else -1));val controller=MediaController(this);controller.setAnchorView(player);player.setMediaController(controller);player.setVideoPath(file.path);player.setOnPreparedListener{player.start();controller.show(0)};player.setOnErrorListener{_,_,_->status.text="Playback unavailable. Use Open with.";true}}
   else->{if(file.extension.equals("pdf",true)){renderPdf(token)}else if(file.extension.lowercase() in setOf("txt","md","csv","json","xml","log","ini","conf","html","htm","kt","java","js","css","py","yml","yaml")){val text=TextView(this).apply{textSize=14f;setTextColor(Color.rgb(30,45,50));setTextIsSelectable(true);setPadding(dp(10),dp(10),dp(10),dp(10))};box.addView(ScrollView(this).apply{addView(text)},LinearLayout.LayoutParams(-1,-1));val target=file;worker.execute{val value=runCatching{target.inputStream().use{input->val data=ByteArray(minOf(target.length(),512*1024L).toInt());var offset=0;while(offset<data.size){val n=input.read(data,offset,data.size-offset);if(n<0)break;offset+=n};String(data,0,offset,Charsets.UTF_8)}+if(target.length()>512*1024)"\n\nShowing first 512 KB." else ""}.getOrElse{it.message ?: "Cannot read file"};runOnUiThread{if(token==generation)text.text=value}}}else if(file.extension.equals("apk",true)){box.addView(TextView(this).apply{text="Android app package\nOpen with Android’s package installer.";gravity=Gravity.CENTER;textSize=16f});box.addView(button("Install"){ApkInstallerActivity.open(this,root,file,showHidden)})}else{val kind=FileTypeIcons.kind(file);box.addView(ImageView(this).apply{setImageDrawable(ManagerIcon(kind));contentDescription=kind},LinearLayout.LayoutParams(dp(76),dp(76)));box.addView(TextView(this).apply{text=when(kind){"Word"->"Word document";"Excel"->"Excel spreadsheet";"Presentation"->"Presentation";else->file.extension.uppercase()+" file"};gravity=Gravity.CENTER;textSize=18f;setPadding(dp(12),dp(8),dp(12),dp(8))});box.addView(TextView(this).apply{text="A compatible viewer app is required.\nChoose Open with after installing one.";gravity=Gravity.CENTER;textSize=14f;setPadding(dp(12),dp(6),dp(12),dp(6))})}}
  }
 }
 private fun renderPdf(token:Int){
  val image=ZoomImage(this,{go(it)}).apply{contentDescription="PDF preview. Pinch or double tap to zoom."};box.addView(image,LinearLayout.LayoutParams(-1,0,1f))
  val controls=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setBackgroundColor(Color.WHITE)}
  val pageBack=button("‹ Page"){if(pdfPage>0){pdfPage--;render()}};val pageNext=button("Page ›"){pdfPage++;render()};val count=TextView(this).apply{gravity=Gravity.CENTER;textSize=13f;setTextColor(Color.rgb(70,85,90))}
  controls.addView(pageBack,LinearLayout.LayoutParams(dp(88),dp(38)));controls.addView(count,LinearLayout.LayoutParams(0,dp(38),1f));controls.addView(pageNext,LinearLayout.LayoutParams(dp(88),dp(38)));box.addView(controls);val target=file
  worker.execute{if(token!=generation)return@execute;runCatching{ParcelFileDescriptor.open(target,ParcelFileDescriptor.MODE_READ_ONLY).use{descriptor->PdfRenderer(descriptor).use{pdf->val total=pdf.pageCount;require(total>0);val page=pdfPage.coerceIn(0,total-1);pdf.openPage(page).use{p->val width=resources.displayMetrics.widthPixels.coerceAtMost(1800);val height=(width.toFloat()*p.height/p.width).toInt().coerceAtLeast(1).coerceAtMost(4000);val bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);bitmap.eraseColor(Color.WHITE);p.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);runOnUiThread{if(token==generation){pdfPage=page;image.setImageBitmap(bitmap);count.text="${page+1} / $total";pageBack.isEnabled=page>0;pageNext.isEnabled=page<total-1}else bitmap.recycle()}}}}}.onFailure{runOnUiThread{if(token==generation)status.text="PDF preview unavailable. Use Open with."}}}
 }
 private fun decode(target:File):Bitmap?{
  val opts=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(target.path,opts);opts.inSampleSize=1;while(maxOf(opts.outWidth,opts.outHeight)/opts.inSampleSize>2048)opts.inSampleSize*=2;opts.inJustDecodeBounds=false
  val original=BitmapFactory.decodeFile(target.path,opts) ?: return null
  val orientation=runCatching{ExifInterface(target.path).getAttributeInt(ExifInterface.TAG_ORIENTATION,1)}.getOrDefault(1)
  val matrix=Matrix();when(orientation){2->matrix.setScale(-1f,1f);3->matrix.setRotate(180f);4->matrix.setScale(1f,-1f);5->{matrix.setRotate(90f);matrix.postScale(-1f,1f)};6->matrix.setRotate(90f);7->{matrix.setRotate(270f);matrix.postScale(-1f,1f)};8->matrix.setRotate(270f)}
  return if(matrix.isIdentity)original else Bitmap.createBitmap(original,0,0,original.width,original.height,matrix,true).also{if(it!==original)original.recycle()}
 }
 private fun delete(){if(busy)return;busy=true;media?.stopPlayback();val target=file;val index=siblings.indexOf(file);status.text="Moving to Recycle Bin…";worker.execute{val result=runCatching{TrashStore(root,true).put(target)};runOnUiThread{busy=false;result.onSuccess{siblings=siblings.filter{f->f!=target};validSiblings();if(siblings.isEmpty())finish()else{file=siblings[index.coerceIn(0,siblings.lastIndex)];pdfPage=0;render()}}.onFailure{status.text=it.message ?: "Cannot delete file"}}}}
 private fun options(anchor:View){if(busy)return;HeaderMenus.show(this,anchor,listOf("Properties" to {PropertiesDialog.show(this,root,file,worker,showHidden)},"Share" to {external(true);Unit},"Open with" to {external(false);Unit},"Delete" to {delete()}))}
 private fun external(share:Boolean):Boolean{if(!share && file.extension.equals("apk",true)){ApkInstallerActivity.open(this,root,file,showHidden);return true};return runCatching{FileManagerOps(root,showHidden).checked(file);val uri=FileProvider.getUriForFile(this,"$packageName.files",file);val intent=if(share)Intent(Intent.ACTION_SEND).setType(FileDetails.mime(file)).putExtra(Intent.EXTRA_STREAM,uri)else Intent(Intent.ACTION_VIEW).setDataAndType(uri,FileDetails.mime(file));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.clipData=ClipData.newRawUri(file.name,uri);check(intent.resolveActivity(packageManager)!=null){"Install a compatible viewer app first"};startActivity(Intent.createChooser(intent,if(share)"Share" else "Open with"));true}.getOrElse{Toast.makeText(this,it.message ?: "No compatible app available",Toast.LENGTH_LONG).show();false}}
 override fun onKeyDown(code:Int,event:KeyEvent):Boolean{if(currentFocus !is Button && media==null){if(code==KeyEvent.KEYCODE_DPAD_LEFT){go(-1);return true};if(code==KeyEvent.KEYCODE_DPAD_RIGHT){go(1);return true}};return super.onKeyDown(code,event)}
 private class ZoomImage(context:android.content.Context,val navigate:(Int)->Unit):android.widget.ImageView(context){
  private var zoom=1f;private var panX=0f;private var panY=0f;private var downX=0f;private var downY=0f;private var lastX=0f;private var lastY=0f;private var multi=false
  private val pinch=ScaleGestureDetector(context,object:ScaleGestureDetector.SimpleOnScaleGestureListener(){override fun onScale(detector:ScaleGestureDetector):Boolean{zoom=(zoom*detector.scaleFactor).coerceIn(1f,5f);if(zoom==1f){panX=0f;panY=0f};invalidate();return true}})
  private val taps=GestureDetector(context,object:GestureDetector.SimpleOnGestureListener(){override fun onDoubleTap(e:MotionEvent):Boolean{zoom=if(zoom>1f)1f else 2f;panX=0f;panY=0f;invalidate();return true}})
  init{scaleType=ScaleType.FIT_CENTER;contentDescription="Image preview. Pinch to zoom, swipe to change file.";isFocusable=true;isFocusableInTouchMode=false}
  override fun onDraw(canvas:Canvas){val save=canvas.save();canvas.translate(panX,panY);canvas.scale(zoom,zoom,width/2f,height/2f);super.onDraw(canvas);canvas.restoreToCount(save)}
  override fun onTouchEvent(e:MotionEvent):Boolean{pinch.onTouchEvent(e);taps.onTouchEvent(e);if(e.pointerCount>1)multi=true;when(e.actionMasked){MotionEvent.ACTION_DOWN->{downX=e.x;lastX=e.x;downY=e.y;lastY=e.y;multi=false};MotionEvent.ACTION_MOVE->{if(zoom>1f && e.pointerCount==1){val maxX=width*(zoom-1)/2;val maxY=height*(zoom-1)/2;panX=(panX+e.x-lastX).coerceIn(-maxX,maxX);panY=(panY+e.y-lastY).coerceIn(-maxY,maxY);invalidate()};lastX=e.x;lastY=e.y};MotionEvent.ACTION_UP->{val dx=e.x-downX;val dy=e.y-downY;if(!multi&&zoom==1f&&kotlin.math.abs(dx)>80*resources.displayMetrics.density&&kotlin.math.abs(dx)>kotlin.math.abs(dy)*1.8)navigate(if(dx<0)1 else -1);performClick()};MotionEvent.ACTION_CANCEL->{multi=true}};return true}
  override fun performClick():Boolean{super.performClick();return true}
 }
}
