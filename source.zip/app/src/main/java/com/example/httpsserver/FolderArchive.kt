package com.example.httpsserver

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Produces a ZIP without creating a temporary archive or loading whole files into memory. */
internal object FolderArchive {
    private val slots = Semaphore(2)

    fun write(base: File, directory: File, output: OutputStream) {
        val root = base.canonicalFile
        val policy = SharedFiles(root)
        val selected = directory.canonicalFile
        val relative = selected.path.removePrefix(root.path)
        require(selected != root && policy.resolve(relative) == selected && selected.isDirectory && selected.canRead()) {
            "Choose a readable shared folder"
        }
        val buffer = ByteArray(64 * 1024)
        ZipOutputStream(output, Charsets.UTF_8).use { zip ->
            fun visit(file: File, name: String, depth: Int) {
                if (Thread.currentThread().isInterrupted) throw IOException("Download cancelled")
                if (depth > 128) throw IOException("Folder nesting is too deep")
                val canonical = file.canonicalFile
                // Never follow symbolic links: avoids loops, aliases and leaving the selected folder.
                if (canonical.path != file.absolutePath) return
                if (canonical != selected && !canonical.path.startsWith(selected.path + File.separator)) return
                if (policy.resolve(canonical.path.removePrefix(root.path)) != canonical || !file.canRead()) return
                if (file.isDirectory) {
                    zip.putNextEntry(ZipEntry("$name/").apply { time = file.lastModified() })
                    zip.closeEntry()
                    val children = file.listFiles() ?: throw IOException("A folder could not be read")
                    for (child in children.sortedBy { it.name }) {
                        if (policy.allowedPart(child.name)) visit(child, "$name/${child.name}", depth + 1)
                    }
                } else if (file.isFile) {
                    zip.putNextEntry(ZipEntry(name).apply { time = file.lastModified() })
                    file.inputStream().use { input ->
                        while (true) {
                            if (Thread.currentThread().isInterrupted) throw IOException("Download cancelled")
                            val n = input.read(buffer)
                            if (n < 0) break
                            zip.write(buffer, 0, n)
                        }
                    }
                    zip.closeEntry()
                }
            }
            visit(selected, selected.name, 0)
        }
    }

    /** Returns null when two archives are already streaming. Caller owns and closes the stream. */
    fun stream(base: File, directory: File): InputStream? {
        if (!slots.tryAcquire()) return null
        val pipe = PipedInputStream(128 * 1024)
        val output = PipedOutputStream(pipe)
        val failure = AtomicReference<Exception?>()
        val worker = Thread({
            try {
                write(base, directory, output)
            } catch (e: Exception) {
                failure.set(e)
            } finally {
                try { output.close() } finally { slots.release() }
            }
        }, "tv2u-folder-zip").apply { isDaemon = true }
        val result = object : InputStream() {
            private fun check(n: Int): Int {
                if (n < 0) failure.get()?.let { throw IOException("Folder ZIP was interrupted", it) }
                return n
            }
            override fun read(): Int = check(pipe.read())
            override fun read(bytes: ByteArray, offset: Int, length: Int): Int = check(pipe.read(bytes, offset, length))
            override fun close() { worker.interrupt(); pipe.close() }
        }
        try { worker.start() } catch (e: Exception) { output.close(); pipe.close(); slots.release(); throw e }
        return result
    }
}
