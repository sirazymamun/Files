package com.example.httpsserver

import java.io.File
import java.io.IOException
import java.util.concurrent.Semaphore

/** Counts only content that the same browser policy exposes. No symlink traversal. */
internal object FolderSize {
    val slots = Semaphore(2)
    data class Result(val bytes: Long, val files: Long)

    fun measure(base: File, directory: File, maxEntries: Int = 100000, timeoutMillis: Long = 8000, includeHidden:Boolean=false): Result {
        require(maxEntries > 0 && timeoutMillis > 0)
        val root = base.canonicalFile
        val policy = SharedFiles(root,includeHidden)
        val selected = directory.canonicalFile
        require(policy.resolve(selected.path.removePrefix(root.path)) == selected && selected.isDirectory) { "Folder is not shared" }
        val started = System.nanoTime()
        val budget = timeoutMillis.coerceAtMost(60000) * 1000000
        var entries = 0
        var bytes = 0L
        var files = 0L
        fun check() {
            if (Thread.currentThread().isInterrupted || System.nanoTime() - started > budget) throw IOException("Folder size timed out")
        }
        fun visit(file: File, depth: Int) {
            check()
            if (++entries > maxEntries || depth > 128) throw IOException("Folder size limit exceeded")
            val canonical = file.canonicalFile
            if (canonical.path != file.absolutePath) return
            if (policy.resolve(canonical.path.removePrefix(root.path)) != canonical) return
            if (!file.canRead()) throw IOException("Folder size cannot read an item")
            if (file.isDirectory) {
                val children = file.listFiles() ?: throw IOException("Folder size cannot read a folder")
                for (child in children) {
                    check()
                    if (policy.allowedPart(child.name)) visit(child, depth + 1)
                }
            } else if (file.isFile) {
                val length = file.length()
                if (length > Long.MAX_VALUE - bytes) throw IOException("Folder size overflow")
                bytes += length
                files++
            } else throw IOException("Folder contents changed or an item is unavailable")
        }
        visit(selected, 0)
        return Result(bytes, files)
    }
}
