package com.example.httpsserver

import android.accounts.Account
import android.accounts.AccountManager
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ClipData
import androidx.core.content.FileProvider
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Typeface
import android.net.Uri
import android.widget.*
import com.google.android.gms.auth.api.identity.*
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.Scope
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Direct Drive browsing and user-initiated transfers; no account password or refresh token storage. */
class GoogleDriveActivity:Activity(){
 private val work=Executors.newSingleThreadExecutor();private val stop=AtomicBoolean(false);private val prefs by lazy{getSharedPreferences("google-drive",MODE_PRIVATE)}
 private lateinit var status:TextView;private lateinit var path:TextView;private lateinit var list:AbsListView;private lateinit var actions:LinearLayout;private lateinit var header:LinearLayout;private lateinit var headerLabel:TextView;private lateinit var headerMore:View;private lateinit var driveSelectTop:View;private lateinit var driveGridTop:View;private lateinit var listHost:FrameLayout;private var driveGrid=false
 private var items=listOf<DriveItem>();private val chosen=linkedSetOf<DriveItem>();private val trail=mutableListOf(DriveItem("root","My Drive","application/vnd.google-apps.folder"))
 internal var authorizationResultParser:((Intent)->AuthorizationResult)?=null
 private var activeToken:String?=null;private val notesSetup get()=intent.getBooleanExtra("notesSync",false)
 private val requestedScope get()=if(notesSetup)DriveNotesRemote.SCOPE else GoogleDriveApi.SCOPE
 private var busy=false;private var pending:((GoogleDriveApi)->Unit)?=null;private var authorizing=false;private var destroyed=false;private var uploadParent="root"
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun row()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
 private fun text(value:String,size:Float=14f)=TextView(this).apply{text=value;textSize=size;setTextColor(Color.rgb(30,45,50))}
 private fun button(label:String,run:()->Unit)=Button(this).apply{text=label;isAllCaps=false;textSize=13f;minWidth=0;minimumWidth=0;setTextColor(Color.rgb(0,132,121));setOnClickListener{run()}}
 override fun onCreate(state:Bundle?){super.onCreate(state);window.statusBarColor=Color.rgb(32,32,32);window.navigationBarColor=Color.WHITE
  val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)};header=row().apply{setBackgroundColor(Color.rgb(0,49,65))}
  header.addView(button("←"){back()}.apply{setTextColor(Color.WHITE);textSize=24f;setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null;elevation=0f},LinearLayout.LayoutParams(dp(48),dp(56)));headerLabel=text("Google Drive",20f).apply{setTextColor(Color.WHITE)};header.addView(headerLabel,LinearLayout.LayoutParams(0,-2,1f));driveSelectTop=topAction("☑","Select all or deselect all"){
   if(chosen.size==items.size)chosen.clear() else chosen.addAll(items)
   bind();controls()
  };header.addView(driveSelectTop,LinearLayout.LayoutParams(dp(48),dp(56)))
  driveGridTop=topAction("▦","List or grid"){driveGrid=!driveGrid;replaceDriveList();bind();controls()}
  header.addView(driveGridTop,LinearLayout.LayoutParams(dp(48),dp(56)))
  headerMore=HeaderMenus.more(this){menu(it)};header.addView(headerMore,LinearLayout.LayoutParams(dp(48),dp(56)));shell.addView(header)
  path=text("My Drive",14f).apply{setPadding(dp(12),dp(10),dp(12),dp(10))};shell.addView(path)
  status=text("Connect your Google account",12f).apply{setPadding(dp(12),dp(5),dp(12),dp(5))};shell.addView(status)
  listHost=FrameLayout(this);shell.addView(listHost,LinearLayout.LayoutParams(-1,0,1f));replaceDriveList();actions=row();shell.addView(actions);setContentView(shell)
  if(state!=null){val ids=state.getStringArrayList("ids");val names=state.getStringArrayList("names");if(ids!=null && names!=null && ids.size==names.size && ids.isNotEmpty()){trail.clear();ids.forEachIndexed{i,id->trail.add(DriveItem(id,names[i],"application/vnd.google-apps.folder"))}}}
  controls();if(prefs.contains("account"))load()
 }
 override fun onSaveInstanceState(out:Bundle){out.putStringArrayList("ids",ArrayList(trail.map{it.id}));out.putStringArrayList("names",ArrayList(trail.map{it.name}));super.onSaveInstanceState(out)}
 override fun onDestroy(){destroyed=true;stop.set(true);pending=null;work.shutdownNow();super.onDestroy()}
 private fun topAction(symbol:String,label:String,run:()->Unit)=ImageButton(this).apply{
  setImageDrawable(ManagerIcon(if(symbol=="☑")"SelectAll" else "Grid"))
  scaleType=ImageView.ScaleType.FIT_CENTER
  setPadding(dp(8),dp(8),dp(8),dp(8))
  setBackgroundColor(Color.TRANSPARENT)
  contentDescription=label;isClickable=true;isFocusable=true;setOnClickListener{if(!busy)run()}
 }
 private fun replaceDriveList(){
  listHost.removeAllViews()
  list=if(driveGrid)GridView(this).apply{numColumns=2;horizontalSpacing=dp(3);verticalSpacing=dp(3)} else ListView(this)
  listHost.addView(list,FrameLayout.LayoutParams(-1,-1))
 }
 private fun bottomButton(symbol:String,label:String,enabled:Boolean=true,run:()->Unit):View{
  val container=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(2),0,dp(2),0);isEnabled=enabled;alpha=if(enabled)1f else .4f;contentDescription=label;setOnClickListener{if(enabled && !busy)run()}}
  container.addView(TextView(this).apply{text=symbol;textSize=26f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD},LinearLayout.LayoutParams(-1,dp(30)))
  container.addView(TextView(this).apply{text=label;textSize=11f;maxLines=1;gravity=Gravity.CENTER;setTextColor(Color.WHITE)},LinearLayout.LayoutParams(-1,dp(18)))
  return container
 }
 private fun selectionChanged(){if(!::actions.isInitialized)return;controls()}
 private fun controls(){
  if(::driveSelectTop.isInitialized){
   val visible=!notesSetup && chosen.isNotEmpty()
   driveSelectTop.visibility=if(visible)View.VISIBLE else View.GONE
   driveGridTop.visibility=if(visible)View.VISIBLE else View.GONE
   driveSelectTop.contentDescription=if(chosen.size==items.size)"Deselect all" else "Select all"
   driveGridTop.contentDescription=if(driveGrid)"Show list" else "Show grid"
  }
  if(busy)window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
  actions.removeAllViews()
  if(!notesSetup && chosen.isNotEmpty() && ::headerLabel.isInitialized){headerLabel.text="${chosen.size}/${items.size}";headerMore.contentDescription="Selection options"}else if(::headerLabel.isInitialized){headerLabel.text="Google Drive";headerMore.contentDescription="More options"}
  if(busy){actions.addView(button("Cancel transfer"){stop.set(true);status.text="Cancelling…"},LinearLayout.LayoutParams(-1,dp(50)));return}
  if(notesSetup||!prefs.contains("account")){actions.addView(button(if(notesSetup)"Connect Notes sync" else "Connect Google Drive"){chooseAccount()},LinearLayout.LayoutParams(-1,dp(52)));return}
  if(chosen.isNotEmpty()){
   actions.setBackgroundColor(Color.rgb(0,49,65))
   val selected=chosen.size
   for((symbol,label,enabled,run) in listOf(
    Quad("▢","Copy",selected>0,{copySelected()}), Quad("➜","Move",selected>0,{moveSelected()}),
    Quad("Ⅰ","Rename",selected==1,{renameSelected()}), Quad("▣","Delete",selected>0,{deleteSelected()}),
    Quad("⋮","More",true,{selectionMenu()})
   ))actions.addView(bottomButton(symbol,label,enabled,run),LinearLayout.LayoutParams(0,dp(52),1f))
  }else{
   // Upload is available from the header menu. No redundant idle action buttons.
   actions.setBackgroundColor(Color.WHITE)
  }
 }
 private data class Quad(val symbol:String,val label:String,val enabled:Boolean,val run:()->Unit)
 /** Compact, icon-labelled actions with normal touch targets, anchored above the bottom toolbar. */
 private fun selectionMenu(){
  if(chosen.isEmpty())return
  val entries=mutableListOf<Triple<String,String,()->Unit>>()
  entries.add(Triple("↗","Share",{shareSelected()}))
  entries.add(Triple("★","Add bookmark",{bookmarkSelected()}))
  entries.add(Triple("▣","Open with",{openSelected()}))
  entries.add(Triple("ⓘ","Properties",{propertiesSelected()}))
  entries.add(Triple("↓","Download to phone",{downloadSelected()}))
  if(driveClipboard.isNotEmpty())entries.add(Triple("▤","Paste into Drive",{drivePaste()}))
  entries.add(Triple("↻","Refresh",{chosen.clear();load()}))
  entries.add(Triple("+","New Drive folder",{chosen.clear();newDriveFolder()}))
  compactDriveMenu(entries)
 }
 private fun compactDriveMenu(entries:List<Triple<String,String,()->Unit>>){
  val popup=PopupWindow(this)
  val border=GradientDrawable().apply{
   setColor(Color.WHITE)
   cornerRadius=dp(9).toFloat()
   setStroke(dp(1),Color.rgb(225,233,236))
  }
  val content=LinearLayout(this).apply{
   orientation=LinearLayout.VERTICAL
   background=border
   setPadding(0,dp(2),0,dp(2))
  }
  val heading=TextView(this).apply{
   text="FILE ACTIONS";textSize=11f;letterSpacing=.07f
   setTextColor(Color.rgb(81,105,112));typeface=Typeface.DEFAULT_BOLD
   setPadding(dp(12),dp(3),dp(10),dp(3))
  }
  content.addView(heading)
  entries.forEachIndexed { i, (symbol,label,action)->
   if(i==4){
    content.addView(View(this).apply{setBackgroundColor(Color.rgb(234,239,241))},LinearLayout.LayoutParams(-1,dp(1)).apply{setMargins(dp(12),dp(2),dp(12),dp(2))})
   }
   val line=LinearLayout(this).apply{
    orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL
    setPadding(dp(12),0,dp(12),0)
    minimumHeight=dp(42)
    isClickable=true;isFocusable=true;contentDescription=label
    val bg=android.util.TypedValue()
    if(theme.resolveAttribute(android.R.attr.selectableItemBackground,bg,true))setBackgroundResource(bg.resourceId)
    setOnClickListener{popup.dismiss();action()}
   }
   line.addView(TextView(this).apply{
    text=symbol;textSize=21f;gravity=Gravity.CENTER
    setTextColor(Color.rgb(0,120,120))
   },LinearLayout.LayoutParams(dp(32),dp(42)))
   line.addView(TextView(this).apply{
    text=label;textSize=14f;setTextColor(Color.rgb(35,52,58));gravity=Gravity.CENTER_VERTICAL
    setPadding(dp(8),0,0,0);maxLines=1
   },LinearLayout.LayoutParams(0,dp(42),1f))
   content.addView(line,LinearLayout.LayoutParams(-1,dp(42)))
  }
  val scroll=ScrollView(this).apply{isFillViewport=false;isVerticalScrollBarEnabled=true;addView(content)}
  popup.contentView=scroll
  popup.width=dp(276)
  popup.height=kotlin.math.min(dp(36+entries.size*42+10),resources.displayMetrics.heightPixels-dp(125))
  popup.isFocusable=true;popup.isOutsideTouchable=true
  popup.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
  popup.elevation=dp(10).toFloat()
  popup.showAtLocation(actions,Gravity.END or Gravity.BOTTOM,dp(9),dp(74))
 }
 private fun showOperation(title:String,operation:(GoogleDriveApi,List<DriveItem>)->Unit){
  val selected=chosen.toList();if(selected.isEmpty())return
  authorize{api->busy=true;stop.set(false);controls();status.text=title;work.execute{
   var completed=0;val result=runCatching{for(item in selected){check(!stop.get()){"Operation cancelled"};operation(api,listOf(item));completed++}}
   runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;chosen.clear();controls();result.onFailure{tokenFailed(it);showError("$title: ${it.message ?: "Request failed"}. Completed: $completed of ${selected.size}.")};load()}
  }}
 }
 private fun driveDestination(title:String,onPicked:(DriveItem)->Unit){
  fun showFolder(folder:DriveItem){authorize{api->busy=true;controls();work.execute{val found=runCatching{api.list(folder.id).filter{it.folder}};runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();found.onFailure{tokenFailed(it);showError(it.message?:"Cannot read folders")}.onSuccess{children->
   val labels=children.map{"📁 ${it.name}"}.toTypedArray()
   AlertDialog.Builder(this).setTitle("$title\n${folder.name}").setItems(labels){_,which->showFolder(children[which])}.setPositiveButton("Use this folder"){_,_->onPicked(folder)}.setNeutralButton("My Drive"){_,_->showFolder(DriveItem("root","My Drive","application/vnd.google-apps.folder"))}.setNegativeButton("Cancel",null).show()
  }}}}}
  showFolder(trail.last())
 }
 private fun copyTree(api:GoogleDriveApi,item:DriveItem,dest:String,depth:Int,seen:MutableSet<String>,counter:IntArray){
  check(!stop.get() && depth<=64 && counter[0]++<10000){"Copy cancelled or operation limit reached"}
  require(seen.add(item.id)){"Repeated source folder"}
  if(item.folder){val newFolder=api.mkdir(dest,item.name);api.list(item.id).forEach{copyTree(api,it,newFolder.id,depth+1,seen,counter)}}
  else api.copy(item,dest)
 }
 private var driveClipboard:List<DriveItem> = emptyList()
 private var driveClipboardCut=false
 private fun destinationMenu(move:Boolean){
  val snapshot=chosen.toList();if(snapshot.isEmpty())return
  AlertDialog.Builder(this).setTitle(if(move)"Move / Cut" else "Copy").setItems(arrayOf("Google Drive folder", "Phone / Internal Storage folder")){_,choice->
   if(choice==0){driveClipboard=snapshot;driveClipboardCut=move;chosen.clear();bind();controls();status.text="${snapshot.size} item(s) ready · Open a Drive folder and choose More → Paste into Drive folder";showError("Drive clipboard ready. Navigate to a destination folder, then choose ⋮ → Paste into Drive folder. Or use Copy/Move again to select a destination immediately.")}
   else localDestination(move,snapshot)
  }.setNegativeButton("Cancel",null).show()
 }
 private fun drivePaste(){
  val snapshot=driveClipboard.toList();if(snapshot.isEmpty()){showError("Nothing to paste. Select a Drive item, then Copy or Move first.");return}
  val destination=trail.last()
  authorize{api->busy=true;stop.set(false);controls();status.text="Pasting into ${destination.name}…";work.execute{
   var finished=0;val result=runCatching{
    for(item in snapshot){check(!stop.get()){ "Paste cancelled" }
     if(item.folder){var current=destination.id;val seen=mutableSetOf<String>();while(current!="root" && seen.add(current)){require(current!=item.id){"Cannot paste a folder into itself or one of its children"};current=api.parents(DriveItem(current,"","application/vnd.google-apps.folder")).firstOrNull() ?: "root"}}
     if(driveClipboardCut)api.move(item,destination.id)else copyTree(api,item,destination.id,0,mutableSetOf(),intArrayOf(0));finished++
    }
   };runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();result.onSuccess{driveClipboard=emptyList();status.text="Pasted $finished item(s)"}.onFailure{tokenFailed(it);showError("Paste interrupted after $finished of ${snapshot.size}: ${it.message}")};load()}
  }}
 }
 private fun localDestination(move:Boolean,selection:List<DriveItem> = chosen.toList()){
  if(selection.isEmpty()){showError("Select Drive files or folders first.");return}
  pickFolder(if(move)"Cut / Move to phone · choose destination" else "Copy / Download to phone · choose destination",if(move)"Move here" else "Paste here"){root,folder->
   if(move){AlertDialog.Builder(this).setTitle("Move from Google Drive?").setMessage("${selection.size} selected item(s) will be downloaded and verified in ${folder.path}. Only successfully completed items will then be moved to Google Drive Trash. If interrupted, remaining Drive items stay in place.").setPositiveButton("Move here"){_,_->localTransfer(selection,root,folder,true)}.setNegativeButton("Cancel",null).show()}
   else localTransfer(selection,root,folder,false)
  }
 }
 private fun localTransfer(selection:List<DriveItem>,root:File,destination:File,move:Boolean){
  authorize{api->if(busy)return@authorize;busy=true;stop.set(false);controls();status.text=if(move)"Moving Drive items to phone…" else "Downloading Drive items…";work.execute{
   var finished=0;var downloaded=0;var duplicates=0
   val result=runCatching{
    for(item in selection){check(!stop.get()){ "Transfer cancelled" }
     val current=DriveTransfers(api,root,hidden(),{stop.get()},::report).download(listOf(item),destination)
     require(current.skipped==0){"${item.name}: some unsupported entries were skipped; source kept in Drive"}
     downloaded+=current.copied;duplicates+=current.same
     check(!stop.get()){ "Transfer cancelled before source deletion" }
     if(move){api.trash(item)}
     finished++
    }
   }
   runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();result.onSuccess{
     chosen.clear();status.text="${if(move)"Moved" else "Downloaded"} $finished item(s) · $downloaded files · $duplicates identical"
     AlertDialog.Builder(this).setTitle("Transfer complete").setMessage("Destination: ${destination.path}\n$finished item(s) completed.${if(move)" Drive originals were moved to Trash after verification." else " Drive originals were preserved."}").setPositiveButton("OK",null).show()
    }.onFailure{tokenFailed(it);showError("Transfer stopped after $finished of ${selection.size} item(s): ${it.message}. Completed local copies remain. Unfinished Drive originals were not deleted.")};load()}
  }}
 }
 private fun copySelected(){destinationMenu(false)}
 private fun moveSelected(){destinationMenu(true)}
 private fun copyToDriveSelected(){driveDestination("Copy to Drive folder"){dest->showOperation("Copying Drive items"){api,selected->
  for(item in selected){
   if(item.folder){var current=dest.id;val checked=mutableSetOf<String>();while(current!="root" && checked.add(current)){require(current!=item.id){"Cannot copy a folder into itself or a subfolder"};current=api.parents(DriveItem(current,"","application/vnd.google-apps.folder")).firstOrNull() ?: "root"}}
   copyTree(api,item,dest.id,0,mutableSetOf(),intArrayOf(0))
  }
 }}}
 private fun moveToDriveSelected(){driveDestination("Move to Drive folder"){dest->showOperation("Moving Drive items"){api,selected->selected.forEach{api.move(it,dest.id)}}}}
 private fun renameSelected(){val item=chosen.singleOrNull()?:return;val field=EditText(this).apply{setSingleLine(true);setText(item.name);selectAll()}
  AlertDialog.Builder(this).setTitle("Rename in Google Drive").setView(field).setPositiveButton("Rename"){_,_->val name=field.text.toString().trim();if(name.isBlank()||name.contains('/')||name.length>200){showError("Invalid name")}else showOperation("Renaming"){api,selected->api.rename(selected.single(),name)}}.setNegativeButton("Cancel",null).show()
 }
 private fun deleteSelected(){AlertDialog.Builder(this).setTitle("Move to Google Drive Trash?").setMessage("${chosen.size} selected item(s) will be moved to Trash, where they can be restored using Google Drive.").setPositiveButton("Move to Trash"){_,_->showOperation("Moving to Trash"){api,selected->selected.forEach{api.trash(it)}}}.setNegativeButton("Cancel",null).show()}
 private fun driveSettings(){HeaderMenus.show(this,headerMore,listOf("Refresh" to {chosen.clear();load()},"New Drive folder" to {chosen.clear();newDriveFolder()},"Change account" to {chooseAccount()},"Disconnect" to {disconnect()}))}
 private fun shareSelected(){val item=chosen.singleOrNull();if(item==null){showError("Choose one Drive file or folder to share.");return};val url=if(item.folder)"https://drive.google.com/drive/folders/${Uri.encode(item.id)}" else "https://drive.google.com/file/d/${Uri.encode(item.id)}/view";startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,url),"Share Drive link"))}
 private fun openSelected(){val item=chosen.singleOrNull();if(item==null){showError("Choose one item to open.");return};val url=if(item.folder)"https://drive.google.com/drive/folders/${Uri.encode(item.id)}" else "https://drive.google.com/file/d/${Uri.encode(item.id)}/view";runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}.onFailure{showError("No browser available")}}
 private fun bookmarkSelected(){val item=chosen.singleOrNull();if(item==null){showError("Select one item to bookmark.");return};prefs.edit().putString("bookmark_${item.id}",item.name).apply();Toast.makeText(this,"Bookmarked ${item.name}",Toast.LENGTH_SHORT).show()}
 private fun propertiesSelected(){val item=chosen.singleOrNull();if(item==null){showError("Select one item for properties.");return};AlertDialog.Builder(this).setTitle("Properties").setMessage("Name: ${item.name}\nType: ${item.mime}\nSize: ${if(item.folder)"Folder" else FileManagerOps.formatBytes(item.size)}\nModified: ${item.modified.ifBlank{"Unavailable"}}\nDrive ID: ${item.id}").setPositiveButton("Close",null).show()}
 private fun hidden()=getSharedPreferences("files-manager",MODE_PRIVATE).getBoolean("showHidden",false)
 private fun report(value:String){runOnUiThread{if(!destroyed && busy)status.text=value}}
 private fun tokenFailed(e:Throwable){if(e is DriveFailure && e.status==401){activeToken?.let{Identity.getAuthorizationClient(this).clearToken(ClearTokenRequest.builder().setToken(it).build())};activeToken=null}}
 private fun showError(message:String){if(!destroyed)AlertDialog.Builder(this).setTitle("Google Drive").setMessage(message).setPositiveButton("Close",null).show()}
 private fun chooseAccount(){if(busy||authorizing)return;activeToken=null;val availability=GoogleApiAvailability.getInstance();val code=availability.isGooglePlayServicesAvailable(this);if(code!=ConnectionResult.SUCCESS){showError("Google Play services with a Google account is required for direct Drive access. Update Play services or use Cloud → Other document providers.");return}
  runCatching{startActivityForResult(AccountManager.newChooseAccountIntent(null,null,arrayOf("com.google"),null,null,null,null),52)}.onFailure{showError("Google account selection is unavailable on this device.")}
 }
 private fun authorize(done:(GoogleDriveApi)->Unit){
  if(authorizing||busy)return
  // The access token is already authorized for this Activity; reuse it across folder taps and file actions.
  // A real HTTP 401 clears it via tokenFailed(), so the next user action requests a fresh token.
  val cached=activeToken
  if(!cached.isNullOrBlank() && !notesSetup){done(GoogleDriveApi(cached));return}
  val account=prefs.getString("account",null);if(account==null){pending=done;chooseAccount();return};pending=done;authorizing=true;status.text="Connecting to Google Drive…"
  val request=AuthorizationRequest.builder().setAccount(Account(account,"com.google")).setRequestedScopes(listOf(Scope(requestedScope))).build()
  Identity.getAuthorizationClient(this).authorize(request).addOnSuccessListener{result->if(destroyed)return@addOnSuccessListener
   if(result.hasResolution()){runCatching{startIntentSenderForResult(result.pendingIntent!!.intentSender,51,null,0,0,0)}.onFailure{authorizing=false;pending=null;showError("Could not open Google consent screen.")}}
   else authorized(result)
  }.addOnFailureListener{authorizationFailed(it,null)}
 }
 private fun authorizationFailed(error:Throwable?,resultCode:Int?){authorizing=false;pending=null;if(destroyed)return;val code=(error as? com.google.android.gms.common.api.ApiException)?.statusCode;val message=GoogleDriveAuthMessages.describe(code,resultCode);status.text=if(code!=null)"Google connection failed · Error $code" else "Google sign-in did not complete";controls();AlertDialog.Builder(this).setTitle("Google Drive connection").setMessage(message).setPositiveButton("Retry"){_,_->chooseAccount()}.setNegativeButton("Close",null).show()}
 private fun authorized(result:AuthorizationResult){authorizing=false;if(destroyed)return;val token=result.accessToken
  if(token.isNullOrBlank() || requestedScope !in result.grantedScopes){pending=null;showError("Drive permission was not granted.");return};if(notesSetup){val account=prefs.getString("account",null) ?: return;NotesSync.enable(this,account);Toast.makeText(this,"Notes auto-sync enabled",Toast.LENGTH_SHORT).show();pending=null;finish();return};activeToken=token;val next=pending;pending=null;controls();(next ?: {api:GoogleDriveApi->loadWith(api)})(GoogleDriveApi(token))
 }
 @Deprecated("Platform result") override fun onActivityResult(request:Int,result:Int,data:Intent?){super.onActivityResult(request,result,data)
  when(request){51->{authorizing=false;if(data==null){authorizationFailed(null,result);return};runCatching{authorizationResultParser?.invoke(data) ?: Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data)}.onSuccess(::authorized).onFailure{authorizationFailed(it,result)}}
   52->{if(result!=RESULT_OK){pending=null;return};val name=data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME) ?: return;activeToken=null;prefs.edit().putString("account",name).apply();items=emptyList();chosen.clear();trail.clear();trail.add(DriveItem("root","My Drive","application/vnd.google-apps.folder"));val next=pending;pending=null;authorize(next ?: {loadWith(it)})}
   53->{if(result!=RESULT_OK||data==null)return;val uris=mutableListOf<android.net.Uri>();data.clipData?.let{for(i in 0 until it.itemCount)uris.add(it.getItemAt(i).uri)} ?: data.data?.let{uris.add(it)};if(uris.isEmpty())return;if(uris.size>1000){showError("Select up to 1,000 files per upload");return};val parent=uploadParent
    authorize{api->transfer("Uploading files…"){
     val cache=File(cacheDir.canonicalFile,"drive-${UUID.randomUUID()}");check(cache.mkdir());try{val root=cache.canonicalFile;var size=0L;val staged=uris.distinct().mapIndexed{i,uri->check(!stop.get()){ "Transfer cancelled" };var name="File ${i+1}";contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())name=it.getString(0) ?: name};require(SharedFiles(root,true).validName(name)){"Unsupported source name"};val sub=File(root,i.toString()).apply{check(mkdir())};val dest=File(sub,name);(contentResolver.openInputStream(uri) ?: kotlin.error("Source unavailable")).use{input->dest.outputStream().use{out->val b=ByteArray(65536);while(true){check(!stop.get()){ "Transfer cancelled" };val n=input.read(b);if(n<0)break;size+=n;require(size<=8L*1024*1024*1024){"Upload selection exceeds 8 GB"};out.write(b,0,n)}}};dest};DriveTransfers(api,root,true,{stop.get()},::report).upload(staged,parent)}finally{cache.deleteRecursively()}
    }}
   }
  }
 }
 private fun load(){authorize(::loadWith)}
 private fun loadWith(api:GoogleDriveApi){if(destroyed)return;busy=true;stop.set(false);controls();status.text="Reading Drive…";val folder=trail.last();work.execute{val result=runCatching{api.list(folder.id)};runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();if(stop.get()){status.text="Cancelled";return@runOnUiThread};result.onSuccess{items=it;chosen.clear();controls();path.text=trail.joinToString(" / "){p->p.name};status.text="${prefs.getString("account","")} · ${items.size} items";bind()}.onFailure{tokenFailed(it);status.text="Could not read Drive";showError(it.message ?: "Drive unavailable")}}}}
 private fun bind(){list.adapter=object:BaseAdapter(){override fun getCount()=items.size;override fun getItem(position:Int)=items[position];override fun getItemId(position:Int)=position.toLong();override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
  val item=items[position];val line=LinearLayout(this@GoogleDriveActivity).apply{orientation=if(driveGrid)LinearLayout.VERTICAL else LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(4),dp(2),dp(4),dp(2))};line.addView(CheckBox(this@GoogleDriveActivity).apply{isChecked=item in chosen;isEnabled=!busy;setOnCheckedChangeListener{_,checked->if(checked)chosen.add(item)else chosen.remove(item);selectionChanged()}},LinearLayout.LayoutParams(dp(42),dp(52)))
  val kind=when(item.mime){"application/vnd.google-apps.folder"->"Folder";"application/vnd.google-apps.document"->"Word";"application/vnd.google-apps.spreadsheet"->"Excel";"application/vnd.google-apps.presentation"->"Presentation";else->FileTypeIcons.kind(File(item.name))};line.addView(ImageView(this@GoogleDriveActivity).apply{setImageDrawable(ManagerIcon(kind))},LinearLayout.LayoutParams(dp(52),dp(52)));val labels=LinearLayout(this@GoogleDriveActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(6),0,0,0)};labels.addView(text(item.name,15f).apply{maxLines=2});labels.addView(text(if(item.folder)"Folder" else if(item.workspace)"Google document" else FileManagerOps.formatBytes(item.size),12f));line.addView(labels,if(driveGrid)LinearLayout.LayoutParams(-1,-2) else LinearLayout.LayoutParams(0,-2,1f));return line
 }};list.setOnItemClickListener{_,_,position,_->if(!busy){val item=items[position];if(chosen.isNotEmpty()){if(!chosen.add(item))chosen.remove(item);bind();controls()}else if(item.folder){trail.add(item);load()}else{openDriveFile(item)}}}
  list.setOnItemLongClickListener{_,_,position,_->if(busy)false else{val item=items[position];if(!chosen.add(item))chosen.remove(item);bind();controls();true}}
 }
 private fun pickFiles(){if(busy)return;uploadParent=trail.last().id;runCatching{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),53)}.onFailure{showError("No file picker available")}}
 private fun downloadSelected(){localDestination(false)}
 /** Open a Drive file directly from a trusted, app-private temporary copy. Never open a download folder picker on a tap. */
 private fun openDriveFile(item:DriveItem){
  if(item.folder){trail.add(item);load();return}
  authorize{api->
   busy=true;stop.set(false);controls();status.text="Opening ${item.name}…"
   work.execute{
    val result=runCatching{
     val root=File(cacheDir,"app-shares").canonicalFile.apply{if(!exists())check(mkdirs()){"Cannot prepare preview cache"}}
     val batch=File(root,"drive-preview-${UUID.randomUUID()}").apply{check(mkdir()){"Cannot prepare preview"}}
     val transfer=DriveTransfers(api,batch,true,{stop.get()},::report).download(listOf(item),batch)
     require(transfer.skipped==0 && transfer.copied+transfer.same>0){"Drive item could not be opened"}
     val file=batch.listFiles()?.singleOrNull{it.isFile} ?: error("Drive file preview is unavailable")
     Triple(batch,file,root)
    }
    runOnUiThread{
     if(destroyed)return@runOnUiThread
     busy=false;controls()
     result.onSuccess{(batch,file,root)->
      status.text="Opened ${item.name}"
      // Keep the temporary copy available while the viewer is active; OS may later clean app cache.
      val nativeTypes=setOf("jpg","jpeg","png","gif","webp","bmp","heic","pdf","mp4","mkv","webm","mp3","m4a","wav","txt","md","csv","json","xml","log","html","htm")
      if(file.extension.lowercase() in nativeTypes){
       getSharedPreferences("files-preview",MODE_PRIVATE).edit().putString("root",batch.absolutePath).putString("file",file.absolutePath).putString("siblings","[\""+file.absolutePath.replace("\\","\\\\").replace("\"","\\\"")+"\"]").putBoolean("showHidden",true).apply()
       runCatching{startActivity(Intent(this,FilesPreviewActivity::class.java))}.onFailure{showError("Preview unavailable: ${it.message}")}
      }else{
       runCatching{
        val uri=FileProvider.getUriForFile(this,"$packageName.files",file)
        val view=Intent(Intent.ACTION_VIEW).setDataAndType(uri,FileDetails.mime(file)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        view.clipData=ClipData.newRawUri(file.name,uri)
        startActivity(Intent.createChooser(view,"Open ${file.name}"))
       }.onFailure{showError("No compatible viewer is installed. Use Copy to phone to save the file.")}
      }
     }.onFailure{tokenFailed(it);showError("Cannot open ${item.name}: ${it.message}")}
    }
   }
  }
 }

 private fun pickFolder(title:String,confirmLabel:String="Use this folder",done:(File,File)->Unit){val roots=runCatching{StorageAccess.volumes(this)}.getOrElse{showError(it.message ?: "Allow storage access from Files first");return}
  fun browse(root:File,folder:File){val ops=FileManagerOps(root,hidden());val children=folder.listFiles()?.filter{it.isDirectory && runCatching{ops.checked(it)}.isSuccess}?.sortedBy{it.name.lowercase()} ?: emptyList();val names=(if(folder!=root)listOf("↑ Up")else emptyList())+children.map{it.name}
   AlertDialog.Builder(this).setTitle(title+"\n"+folder.path).setItems(names.toTypedArray()){_,i->if(folder!=root && i==0){var parent=folder.parentFile ?: root;while(parent!=root && runCatching{ops.checked(parent,true)}.isFailure)parent=parent.parentFile ?: root;browse(root,parent)}else browse(root,children[i-(if(folder!=root)1 else 0)])}.setPositiveButton(confirmLabel){_,_->done(root,folder)}.setNeutralButton("Storage"){_,_->AlertDialog.Builder(this).setTitle("Storage").setItems(roots.map{it.name}.toTypedArray()){_,i->browse(roots[i].folder,roots[i].folder)}.show()}.setNegativeButton("Cancel",null).show()
  }
  val initial=intent.getStringExtra("local")?.let{File(it)};val volume=roots.firstOrNull{initial!=null && runCatching{FileManagerOps(it.folder,hidden()).checked(initial,true)}.isSuccess} ?: roots.first();browse(volume.folder,if(initial!=null && initial.isDirectory && runCatching{FileManagerOps(volume.folder,hidden()).checked(initial,true)}.isSuccess)initial else volume.folder)
 }
 private fun transfer(message:String,task:()->DriveTransfers.Result){if(busy)return;busy=true;stop.set(false);controls();status.text=message;work.execute{val result=runCatching(task);runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();result.onSuccess{status.text="${it.copied} copied · ${it.same} identical · ${it.skipped} skipped";AlertDialog.Builder(this).setTitle("Transfer complete").setMessage(status.text.toString()+"\nExisting different files were kept as copies. Nothing was deleted.").setPositiveButton("Close"){_,_->load()}.show()}.onFailure{tokenFailed(it);status.text="Transfer stopped";showError((it.message ?: "Transfer unavailable")+"\nCompleted copies were kept. Check both folders before retrying.")}}}}
 private fun menu(anchor:View){if(busy||authorizing)return
  if(chosen.isNotEmpty()){selectionMenu();return}
  if(notesSetup){HeaderMenus.show(this,anchor,listOf("Choose account" to {chooseAccount()},"Close" to {finish()}));return}
  if(!prefs.contains("account")){HeaderMenus.show(this,anchor,listOf("Connect Google Drive" to {chooseAccount()}));return}
  val menu=mutableListOf<Pair<String,()->Unit>>()
  if(driveClipboard.isNotEmpty()){
   menu.add("Paste ${driveClipboard.size} item(s) here" to {drivePaste()})
   menu.add("Cancel clipboard" to {driveClipboard=emptyList();status.text="Clipboard cleared"})
  }
  menu.addAll(listOf(
   "Upload files" to {pickFiles()},
   "Upload folder" to {pickFolder("Choose folder to upload"){root,folder->val parent=trail.last().id;authorize{api->transfer("Uploading folder…"){DriveTransfers(api,root,hidden(),{stop.get()},::report).upload(listOf(folder),parent)}}}},
   "Refresh" to {load()},"New Drive folder" to {newDriveFolder()},"Change account" to {chooseAccount()},"Disconnect" to {disconnect()}
  ))
  HeaderMenus.show(this,anchor,menu)
 }
 private fun newDriveFolder(){val input=EditText(this);AlertDialog.Builder(this).setTitle("New Drive folder").setView(input).setPositiveButton("Create"){_,_->val name=input.text.toString().trim();if(name.isBlank()||name.contains('/')||name.length>200){showError("Enter a valid folder name");return@setPositiveButton};val parent=trail.last().id;authorize{api->transfer("Creating folder…"){api.mkdir(parent,name);DriveTransfers.Result()}}}.setNegativeButton("Cancel",null).show()}
 private fun disconnect(){val account=prefs.getString("account",null) ?: return;authorizing=true;Identity.getAuthorizationClient(this).revokeAccess(RevokeAccessRequest.builder().setAccount(Account(account,"com.google")).setScopes(listOf(Scope(requestedScope))).build()).addOnSuccessListener{authorizing=false;if(NotesSync.prefs(this).getString("account",null)==account)NotesSync.disable(this);prefs.edit().clear().apply();activeToken=null;items=emptyList();chosen.clear();pending=null;bind();controls();status.text="Disconnected";path.text="My Drive"}.addOnFailureListener{authorizing=false;showError("Could not revoke access. Check internet, or remove Files from your Google account's third-party access settings.")}}
 private fun back(){if(busy){stop.set(true);status.text="Cancelling…";return};if(authorizing)return;if(trail.size>1){trail.removeAt(trail.lastIndex);load()}else finish()}
 @Deprecated("Platform back") override fun onBackPressed(){back()}
}
