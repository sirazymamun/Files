package com.example.httpsserver

import android.accounts.Account
import android.accounts.AccountManager
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.gms.auth.api.identity.*
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.Scope
import java.io.File
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Direct Drive browsing and user-initiated transfers; no account password or refresh token storage. */
class GoogleDriveActivity:Activity(){
 private val work=Executors.newSingleThreadExecutor();private val stop=AtomicBoolean(false);private val prefs by lazy{getSharedPreferences("google-drive",MODE_PRIVATE)}
 private lateinit var status:TextView;private lateinit var path:TextView;private lateinit var list:ListView;private lateinit var actions:LinearLayout
 private var items=listOf<DriveItem>();private val chosen=linkedSetOf<DriveItem>();private val trail=mutableListOf(DriveItem("root","My Drive","application/vnd.google-apps.folder"))
 internal var authorizationResultParser:((Intent)->AuthorizationResult)?=null
 private var activeToken:String?=null;private val notesSetup get()=intent.getBooleanExtra("notesSync",false)
 private val requestedScope get()=if(notesSetup)DriveNotesRemote.SCOPE else GoogleDriveApi.SCOPE
 private var busy=false;private var pending:((GoogleDriveApi)->Unit)?=null;private var authorizing=false;private var destroyed=false;private var uploadParent="root"
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun row()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
 private fun text(value:String,size:Float=14f)=TextView(this).apply{text=value;textSize=size;setTextColor(Color.rgb(30,45,50))}
 private fun button(label:String,run:()->Unit)=Button(this).apply{text=label;isAllCaps=false;textSize=13f;minWidth=0;minimumWidth=0;setTextColor(Color.rgb(0,132,121));setOnClickListener{run()}}
 override fun onCreate(state:Bundle?){super.onCreate(state);window.statusBarColor=Color.rgb(32,32,32);window.navigationBarColor=Color.WHITE
  val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)};val header=row().apply{setBackgroundColor(Color.rgb(32,32,32))}
  header.addView(button("←"){back()}.apply{setTextColor(Color.WHITE);textSize=24f;setBackgroundColor(Color.TRANSPARENT);stateListAnimator=null;elevation=0f},LinearLayout.LayoutParams(dp(48),dp(56)));header.addView(text("Google Drive",20f).apply{setTextColor(Color.WHITE)},LinearLayout.LayoutParams(0,-2,1f));header.addView(HeaderMenus.more(this){menu(it)},LinearLayout.LayoutParams(dp(48),dp(56)));shell.addView(header)
  path=text("My Drive",14f).apply{setPadding(dp(12),dp(10),dp(12),dp(10))};shell.addView(path)
  status=text("Connect your Google account",12f).apply{setPadding(dp(12),dp(5),dp(12),dp(5))};shell.addView(status)
  list=ListView(this);shell.addView(list,LinearLayout.LayoutParams(-1,0,1f));actions=row();shell.addView(actions);setContentView(shell)
  if(state!=null){val ids=state.getStringArrayList("ids");val names=state.getStringArrayList("names");if(ids!=null && names!=null && ids.size==names.size && ids.isNotEmpty()){trail.clear();ids.forEachIndexed{i,id->trail.add(DriveItem(id,names[i],"application/vnd.google-apps.folder"))}}}
  controls();if(prefs.contains("account"))load()
 }
 override fun onSaveInstanceState(out:Bundle){out.putStringArrayList("ids",ArrayList(trail.map{it.id}));out.putStringArrayList("names",ArrayList(trail.map{it.name}));super.onSaveInstanceState(out)}
 override fun onDestroy(){destroyed=true;stop.set(true);pending=null;work.shutdownNow();super.onDestroy()}
 private fun controls(){if(busy)window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);actions.removeAllViews();if(busy){actions.addView(button("Cancel transfer"){stop.set(true);status.text="Cancelling…"},LinearLayout.LayoutParams(-1,dp(50)));return}
  if(notesSetup||!prefs.contains("account")){actions.addView(button(if(notesSetup)"Connect Notes sync" else "Connect Google Drive"){chooseAccount()},LinearLayout.LayoutParams(-1,dp(52)));return}
  for((label,run) in listOf<Pair<String,()->Unit>>("Upload files" to {pickFiles()},"Upload folder" to {pickFolder("Choose folder to upload"){root,folder->val parent=trail.last().id;authorize{api->transfer("Uploading folder…"){DriveTransfers(api,root,hidden(),{stop.get()},::report).upload(listOf(folder),parent)}}}},"Download" to {downloadSelected()}))actions.addView(button(label){if(!busy)run()},LinearLayout.LayoutParams(0,dp(52),1f))
 }
 private fun hidden()=getSharedPreferences("files-manager",MODE_PRIVATE).getBoolean("showHidden",false)
 private fun report(value:String){runOnUiThread{if(!destroyed && busy)status.text=value}}
 private fun tokenFailed(e:Throwable){if(e is DriveFailure && e.status==401){activeToken?.let{Identity.getAuthorizationClient(this).clearToken(ClearTokenRequest.builder().setToken(it).build())};activeToken=null}}
 private fun showError(message:String){if(!destroyed)AlertDialog.Builder(this).setTitle("Google Drive").setMessage(message).setPositiveButton("Close",null).show()}
 private fun chooseAccount(){if(busy||authorizing)return;val availability=GoogleApiAvailability.getInstance();val code=availability.isGooglePlayServicesAvailable(this);if(code!=ConnectionResult.SUCCESS){showError("Google Play services with a Google account is required for direct Drive access. Update Play services or use Cloud → Other document providers.");return}
  runCatching{startActivityForResult(AccountManager.newChooseAccountIntent(null,null,arrayOf("com.google"),null,null,null,null),52)}.onFailure{showError("Google account selection is unavailable on this device.")}
 }
 private fun authorize(done:(GoogleDriveApi)->Unit){if(authorizing||busy)return;val account=prefs.getString("account",null);if(account==null){pending=done;chooseAccount();return};pending=done;authorizing=true;status.text="Connecting to Google Drive…"
  val request=AuthorizationRequest.builder().setAccount(Account(account,"com.google")).setRequestedScopes(listOf(Scope(requestedScope))).build()
  Identity.getAuthorizationClient(this).authorize(request).addOnSuccessListener{result->if(destroyed)return@addOnSuccessListener
   if(result.hasResolution()){runCatching{startIntentSenderForResult(result.pendingIntent!!.intentSender,51,null,0,0,0)}.onFailure{authorizing=false;pending=null;showError("Could not open Google consent screen.")}}
   else authorized(result)
  }.addOnFailureListener{authorizationFailed(it,null)}
 }
 private fun authorizationFailed(error:Throwable?,resultCode:Int?){authorizing=false;pending=null;if(destroyed)return;val code=(error as? com.google.android.gms.common.api.ApiException)?.statusCode;val message=GoogleDriveAuthMessages.describe(code,resultCode);status.text=if(code!=null)"Google connection failed · Error $code" else "Google sign-in did not complete";controls();AlertDialog.Builder(this).setTitle("Google Drive connection").setMessage(message).setPositiveButton("Retry"){_,_->chooseAccount()}.setNegativeButton("Close",null).show()}
 private fun authorized(result:AuthorizationResult){authorizing=false;if(destroyed)return;val token=result.accessToken
  if(token.isNullOrBlank() || requestedScope !in result.grantedScopes){pending=null;showError("Drive permission was not granted.");return};if(notesSetup){val account=prefs.getString("account",null) ?: return;NotesSync.enable(this,account);Toast.makeText(this,"Notes auto-sync enabled",Toast.LENGTH_SHORT).show();pending=null;finish();return};activeToken=token;val next=pending;pending=null;controls();(next ?: {api:GoogleDriveApi->loadWith(api)})(GoogleDriveApi(token))
 }
 @Deprecated("Platform result") override fun onActivityResult(request:Int,result:Int,data:Intent?){super.onActivityResult(request,result,data)
  when(request){51->{authorizing=false;if(data==null){authorizationFailed(null,result);return};runCatching{authorizationResultParser?.invoke(data) ?: Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data)}.onSuccess(::authorized).onFailure{authorizationFailed(it,result)}}
   52->{if(result!=RESULT_OK){pending=null;return};val name=data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME) ?: return;prefs.edit().putString("account",name).apply();items=emptyList();chosen.clear();trail.clear();trail.add(DriveItem("root","My Drive","application/vnd.google-apps.folder"));val next=pending;pending=null;authorize(next ?: {loadWith(it)})}
   53->{if(result!=RESULT_OK||data==null)return;val uris=mutableListOf<android.net.Uri>();data.clipData?.let{for(i in 0 until it.itemCount)uris.add(it.getItemAt(i).uri)} ?: data.data?.let{uris.add(it)};if(uris.isEmpty())return;if(uris.size>1000){showError("Select up to 1,000 files per upload");return};val parent=uploadParent
    authorize{api->transfer("Uploading files…"){
     val cache=File(cacheDir.canonicalFile,"drive-${UUID.randomUUID()}");check(cache.mkdir());try{val root=cache.canonicalFile;var size=0L;val staged=uris.distinct().mapIndexed{i,uri->check(!stop.get()){ "Transfer cancelled" };var name="File ${i+1}";contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())name=it.getString(0) ?: name};require(SharedFiles(root,true).validName(name)){"Unsupported source name"};val sub=File(root,i.toString()).apply{check(mkdir())};val dest=File(sub,name);(contentResolver.openInputStream(uri) ?: kotlin.error("Source unavailable")).use{input->dest.outputStream().use{out->val b=ByteArray(65536);while(true){check(!stop.get()){ "Transfer cancelled" };val n=input.read(b);if(n<0)break;size+=n;require(size<=8L*1024*1024*1024){"Upload selection exceeds 8 GB"};out.write(b,0,n)}}};dest};DriveTransfers(api,root,true,{stop.get()},::report).upload(staged,parent)}finally{cache.deleteRecursively()}
    }}
   }
  }
 }
 private fun load(){authorize(::loadWith)}
 private fun loadWith(api:GoogleDriveApi){if(destroyed)return;busy=true;stop.set(false);controls();status.text="Reading Drive…";val folder=trail.last();work.execute{val result=runCatching{api.list(folder.id)};runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();if(stop.get()){status.text="Cancelled";return@runOnUiThread};result.onSuccess{items=it;chosen.clear();path.text=trail.joinToString(" / "){p->p.name};status.text="${prefs.getString("account","")} · ${items.size} items";bind()}.onFailure{tokenFailed(it);status.text="Could not read Drive";showError(it.message ?: "Drive unavailable")}}}}
 private fun bind(){list.adapter=object:BaseAdapter(){override fun getCount()=items.size;override fun getItem(position:Int)=items[position];override fun getItemId(position:Int)=position.toLong();override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
  val item=items[position];val line=row().apply{setPadding(dp(4),dp(3),dp(8),dp(3))};line.addView(CheckBox(this@GoogleDriveActivity).apply{isChecked=item in chosen;isEnabled=!busy;setOnCheckedChangeListener{_,checked->if(checked)chosen.add(item)else chosen.remove(item)}},LinearLayout.LayoutParams(dp(42),dp(52)))
  val kind=when(item.mime){"application/vnd.google-apps.folder"->"Folder";"application/vnd.google-apps.document"->"Word";"application/vnd.google-apps.spreadsheet"->"Excel";"application/vnd.google-apps.presentation"->"Presentation";else->FileTypeIcons.kind(File(item.name))};line.addView(ImageView(this@GoogleDriveActivity).apply{setImageDrawable(ManagerIcon(kind))},LinearLayout.LayoutParams(dp(52),dp(52)));val labels=LinearLayout(this@GoogleDriveActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(6),0,0,0)};labels.addView(text(item.name,15f).apply{maxLines=2});labels.addView(text(if(item.folder)"Folder" else if(item.workspace)"Google document" else FileManagerOps.formatBytes(item.size),12f));line.addView(labels,LinearLayout.LayoutParams(0,-2,1f));return line
 }};list.setOnItemClickListener{_,_,position,_->if(!busy){val item=items[position];if(item.folder){trail.add(item);load()}else{chosen.clear();chosen.add(item);bind();downloadSelected()}}}
 }
 private fun pickFiles(){if(busy)return;uploadParent=trail.last().id;runCatching{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),53)}.onFailure{showError("No file picker available")}}
 private fun downloadSelected(){if(chosen.isEmpty()){showError("Select files or folders to download.");return};val selected=chosen.toList();pickFolder("Choose download destination"){root,folder->authorize{api->transfer("Downloading…"){DriveTransfers(api,root,hidden(),{stop.get()},::report).download(selected,folder)}}}}
 private fun pickFolder(title:String,done:(File,File)->Unit){val roots=runCatching{StorageAccess.volumes(this)}.getOrElse{showError(it.message ?: "Allow storage access from Files first");return}
  fun browse(root:File,folder:File){val ops=FileManagerOps(root,hidden());val children=folder.listFiles()?.filter{it.isDirectory && runCatching{ops.checked(it)}.isSuccess}?.sortedBy{it.name.lowercase()} ?: emptyList();val names=(if(folder!=root)listOf("↑ Up")else emptyList())+children.map{it.name}
   AlertDialog.Builder(this).setTitle(title+"\n"+folder.path).setItems(names.toTypedArray()){_,i->if(folder!=root && i==0){var parent=folder.parentFile ?: root;while(parent!=root && runCatching{ops.checked(parent,true)}.isFailure)parent=parent.parentFile ?: root;browse(root,parent)}else browse(root,children[i-(if(folder!=root)1 else 0)])}.setPositiveButton("Use this folder"){_,_->done(root,folder)}.setNeutralButton("Storage"){_,_->AlertDialog.Builder(this).setTitle("Storage").setItems(roots.map{it.name}.toTypedArray()){_,i->browse(roots[i].folder,roots[i].folder)}.show()}.setNegativeButton("Cancel",null).show()
  }
  val initial=intent.getStringExtra("local")?.let{File(it)};val volume=roots.firstOrNull{initial!=null && runCatching{FileManagerOps(it.folder,hidden()).checked(initial,true)}.isSuccess} ?: roots.first();browse(volume.folder,if(initial!=null && initial.isDirectory && runCatching{FileManagerOps(volume.folder,hidden()).checked(initial,true)}.isSuccess)initial else volume.folder)
 }
 private fun transfer(message:String,task:()->DriveTransfers.Result){if(busy)return;busy=true;stop.set(false);controls();status.text=message;work.execute{val result=runCatching(task);runOnUiThread{if(destroyed)return@runOnUiThread;busy=false;controls();result.onSuccess{status.text="${it.copied} copied · ${it.same} identical · ${it.skipped} skipped";AlertDialog.Builder(this).setTitle("Transfer complete").setMessage(status.text.toString()+"\nExisting different files were kept as copies. Nothing was deleted.").setPositiveButton("Close"){_,_->load()}.show()}.onFailure{tokenFailed(it);status.text="Transfer stopped";showError((it.message ?: "Transfer unavailable")+"\nCompleted copies were kept. Check both folders before retrying.")}}}}
 private fun menu(anchor:View){if(busy||authorizing)return
  if(notesSetup){HeaderMenus.show(this,anchor,listOf("Choose account" to {chooseAccount()},"Close" to {finish()}));return}
  if(!prefs.contains("account")){HeaderMenus.show(this,anchor,listOf("Connect Google Drive" to {chooseAccount()}));return}
  HeaderMenus.show(this,anchor,listOf("Refresh" to {load()},"New Drive folder" to {newDriveFolder()},"Change account" to {chooseAccount()},"Disconnect" to {disconnect()}))
 }
 private fun newDriveFolder(){val input=EditText(this);AlertDialog.Builder(this).setTitle("New Drive folder").setView(input).setPositiveButton("Create"){_,_->val name=input.text.toString().trim();if(name.isBlank()||name.contains('/')||name.length>200){showError("Enter a valid folder name");return@setPositiveButton};val parent=trail.last().id;authorize{api->transfer("Creating folder…"){api.mkdir(parent,name);DriveTransfers.Result()}}}.setNegativeButton("Cancel",null).show()}
 private fun disconnect(){val account=prefs.getString("account",null) ?: return;authorizing=true;Identity.getAuthorizationClient(this).revokeAccess(RevokeAccessRequest.builder().setAccount(Account(account,"com.google")).setScopes(listOf(Scope(requestedScope))).build()).addOnSuccessListener{authorizing=false;if(NotesSync.prefs(this).getString("account",null)==account)NotesSync.disable(this);prefs.edit().clear().apply();activeToken=null;items=emptyList();chosen.clear();pending=null;bind();controls();status.text="Disconnected";path.text="My Drive"}.addOnFailureListener{authorizing=false;showError("Could not revoke access. Check internet, or remove Files from your Google account's third-party access settings.")}}
 private fun back(){if(busy){stop.set(true);status.text="Cancelling…";return};if(authorizing)return;if(trail.size>1){trail.removeAt(trail.lastIndex);load()}else finish()}
 @Deprecated("Platform back") override fun onBackPressed(){back()}
}
