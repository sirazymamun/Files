package com.example.httpsserver

import org.json.JSONObject
import org.json.JSONArray
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

internal data class DriveItem(val id:String,val name:String,val mime:String,val size:Long=0,val md5:String?=null,val modified:String=""){
 val folder get()=mime=="application/vnd.google-apps.folder"
 val workspace get()=mime.startsWith("application/vnd.google-apps.") && !folder
 companion object{fun parse(j:JSONObject)=DriveItem(j.getString("id"),j.getString("name"),j.getString("mimeType"),j.optString("size","0").toLongOrNull() ?: 0,j.optString("md5Checksum").takeIf{it.isNotEmpty()},j.optString("modifiedTime"))}
}
internal interface DriveRemote{
 fun list(parent:String):List<DriveItem>
 fun mkdir(parent:String,name:String):DriveItem
 fun upload(parent:String,name:String,file:File,mime:String,check:()->Unit,progress:(Long)->Unit):DriveItem
 fun download(item:DriveItem,out:OutputStream,check:(Int)->Unit)
}
internal class DriveFailure(val status:Int,message:String):IOException(message)
internal data class DriveReply(val code:Int,val body:ByteArray,val headers:Map<String,String> = emptyMap())
internal interface DriveTransport{
 fun request(method:String,url:String,headers:Map<String,String>,body:ByteArray?=null):DriveReply
 fun stream(url:String,headers:Map<String,String>,out:OutputStream,check:(Int)->Unit)
}
internal class DriveHttps:DriveTransport{
 companion object{
  fun trusted(url:String):Boolean=runCatching{val u=URL(url);u.protocol=="https" && u.host in setOf("www.googleapis.com","content.googleapis.com") && u.port in setOf(-1,443) && u.userInfo==null}.getOrDefault(false)
 }
 private fun connection(method:String,url:String,headers:Map<String,String>):HttpURLConnection{
  require(trusted(url)){"Untrusted Drive endpoint"};return (URL(url).openConnection() as HttpURLConnection).apply{requestMethod=method;instanceFollowRedirects=false;connectTimeout=30000;readTimeout=60000;useCaches=false;headers.forEach{(k,v)->setRequestProperty(k,v)}}
 }
 override fun request(method:String,url:String,headers:Map<String,String>,body:ByteArray?):DriveReply{
  val c=connection(method,url,headers)
  try{if(body!=null){c.doOutput=true;c.setFixedLengthStreamingMode(body.size);c.outputStream.use{it.write(body)}}
   val code=c.responseCode;val input=if(code in 200..399)c.inputStream else c.errorStream
   val bytes=input?.use{val out=ByteArrayOutputStream();val b=ByteArray(8192);while(true){val n=it.read(b);if(n<0)break;check(out.size()+n<=4*1024*1024){"Drive response too large"};out.write(b,0,n)};out.toByteArray()} ?: byteArrayOf()
   return DriveReply(code,bytes,c.headerFields.filterKeys{it!=null}.mapKeys{it.key.lowercase(Locale.ROOT)}.mapValues{it.value.firstOrNull() ?: ""})
  }finally{c.disconnect()}
 }
 override fun stream(url:String,headers:Map<String,String>,out:OutputStream,check:(Int)->Unit){
  val c=connection("GET",url,headers);try{val code=c.responseCode;if(code !in 200..299)throw DriveFailure(code,if(code==401)"Google session expired. Reconnect and retry." else "Drive download failed (HTTP $code)")
   c.inputStream.use{val b=ByteArray(65536);while(true){check(0);val n=it.read(b);if(n<0)break;check(n);out.write(b,0,n)}}
  }finally{c.disconnect()}
 }
}
/** Tokens are supplied in memory for each action, never written to settings or logs. */
internal class GoogleDriveApi(private val token:String,private val http:DriveTransport=DriveHttps()):DriveRemote{
 companion object{const val SCOPE="https://www.googleapis.com/auth/drive";private const val API="https://www.googleapis.com/drive/v3/files";private const val FIELDS="id,name,mimeType,size,md5Checksum,modifiedTime";fun enc(s:String)=URLEncoder.encode(s,"UTF-8")}
 private fun headers(type:String?=null)=mutableMapOf("Authorization" to "Bearer $token").apply{if(type!=null)put("Content-Type",type)}
 private fun good(r:DriveReply):JSONObject{
  if(r.code !in 200..299)throw DriveFailure(r.code,when(r.code){401->"Google session expired. Reconnect and retry.";403->"Drive refused access. Check account permission, API setup or quota.";404->"Drive item is unavailable.";429->"Drive is busy. Retry later.";else->"Drive request failed (HTTP ${r.code})"})
  return if(r.body.isEmpty())JSONObject() else JSONObject(String(r.body,Charsets.UTF_8))
 }
 private fun json(method:String,url:String,value:JSONObject?=null)=good(http.request(method,url,headers(if(value!=null)"application/json; charset=UTF-8" else null),value?.toString()?.toByteArray(Charsets.UTF_8)))
 override fun list(parent:String):List<DriveItem>{
  require(parent.matches(Regex("[A-Za-z0-9_-]+"))){"Invalid Drive folder"};val result=mutableListOf<DriveItem>();var page="";val seen=mutableSetOf<String>()
  do{val q="'$parent' in parents and trashed = false";val response=json("GET",API+"?q="+enc(q)+"&spaces=drive&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true&fields="+enc("nextPageToken,files($FIELDS)")+if(page.isEmpty())"" else "&pageToken="+enc(page));val files=response.optJSONArray("files") ?: JSONArray();for(i in 0 until files.length()){result.add(DriveItem.parse(files.getJSONObject(i)));check(result.size<=10000){"Drive folder exceeds 10,000 items"}};page=response.optString("nextPageToken");check(page.isEmpty()||seen.add(page)){"Repeated Drive page"}}while(page.isNotEmpty())
  return result.sortedWith(compareBy<DriveItem>{!it.folder}.thenBy{it.name.lowercase(Locale.ROOT)})
 }
 override fun mkdir(parent:String,name:String)=DriveItem.parse(json("POST",API+"?fields="+enc(FIELDS)+"&supportsAllDrives=true",JSONObject().put("name",name).put("mimeType","application/vnd.google-apps.folder").put("parents",JSONArray().put(parent))))
 override fun upload(parent:String,name:String,file:File,mime:String,check:()->Unit,progress:(Long)->Unit):DriveItem{
  val total=file.length();val modified=file.lastModified();check();val metadata=JSONObject().put("name",name).put("mimeType",mime).put("parents",JSONArray().put(parent))
  val h=headers("application/json; charset=UTF-8").apply{put("X-Upload-Content-Type",mime);put("X-Upload-Content-Length",total.toString())}
  val start=http.request("POST","https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&supportsAllDrives=true&fields="+enc(FIELDS),h,metadata.toString().toByteArray(Charsets.UTF_8));good(start)
  val location=start.headers["location"] ?: error("Drive did not start upload");require(DriveHttps.trusted(location)){"Untrusted upload endpoint"}
  var offset=0L;var failures=0
  RandomAccessFile(file,"r").use{input->while(true){
   check();require(file.length()==total && file.lastModified()==modified){"Local source changed during upload"}
   val count=minOf(4L*1024*1024,total-offset).toInt();val bytes=ByteArray(count);input.seek(offset);input.readFully(bytes)
   val head=headers(mime).apply{put("Content-Range",if(total==0L)"bytes */0" else "bytes $offset-${offset+count-1}/$total")}
   var reply=try{http.request("PUT",location,head,bytes)}catch(e:IOException){if(++failures>3)throw e;check();http.request("PUT",location,headers().apply{put("Content-Range","bytes */$total")},byteArrayOf())}
   if(reply.code in listOf(429,500,502,503,504)){if(++failures>3)good(reply);check();Thread.sleep(1000L*failures);reply=http.request("PUT",location,headers().apply{put("Content-Range","bytes */$total")},byteArrayOf())}
   if(reply.code in 200..299){require(file.length()==total && file.lastModified()==modified){"Local source changed during upload"};progress(total);return DriveItem.parse(good(reply))}
   if(reply.code!=308)good(reply)
   val next=reply.headers["range"]?.substringAfterLast('-')?.toLongOrNull()?.plus(1) ?: 0L
   require(next in 0..total){"Invalid Drive upload position"};if(next<=offset && ++failures>3)error("Drive upload made no progress");offset=next;progress(offset)
  }}
 }
 override fun download(item:DriveItem,out:OutputStream,check:(Int)->Unit){
  require(!item.folder){"Choose files inside the folder"};val export=when(item.mime){"application/vnd.google-apps.document"->"application/vnd.openxmlformats-officedocument.wordprocessingml.document";"application/vnd.google-apps.spreadsheet"->"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";"application/vnd.google-apps.presentation"->"application/vnd.openxmlformats-officedocument.presentationml.presentation";else->null}
  require(!item.workspace || export!=null){"This Google file cannot be exported here. Use Drive's Export option."}
  http.stream(API+"/"+enc(item.id)+(if(export!=null)"/export?mimeType="+enc(export)else "?alt=media&supportsAllDrives=true"),headers(),out,check)
 }
}

internal class DriveNotesRemote(private val token:String,private val http:DriveTransport=DriveHttps()):NotesRemote{
 companion object{const val SCOPE="https://www.googleapis.com/auth/drive.appdata"}
 private val auth get()=mapOf("Authorization" to "Bearer $token")
 private fun good(r:DriveReply):JSONObject{if(r.code !in 200..299)throw DriveFailure(r.code,"Notes Drive request failed (HTTP ${r.code}). Reconnect if access expired.");return if(r.body.isEmpty())JSONObject()else JSONObject(String(r.body,Charsets.UTF_8))}
 override fun read():List<NoteEvent>{val files=mutableListOf<DriveItem>();var page="";val pages=mutableSetOf<String>();do{val url="https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q="+GoogleDriveApi.enc("trashed = false and name contains 'files-note-v1-'")+"&pageSize=1000&fields="+GoogleDriveApi.enc("nextPageToken,files(id,name,mimeType,size)")+(if(page.isEmpty())"" else "&pageToken="+GoogleDriveApi.enc(page));val j=good(http.request("GET",url,auth));val a=j.optJSONArray("files") ?: JSONArray();for(i in 0 until a.length()){files.add(DriveItem.parse(a.getJSONObject(i)));require(files.size<=10000){"Notes cloud revision limit reached"}};page=j.optString("nextPageToken");require(page.isEmpty()||pages.add(page)){"Repeated notes page"}}while(page.isNotEmpty())
  var bytes=0L;return files.map{item->require(item.size<=8L*1024*1024){"Cloud note revision too large"};val out=object:ByteArrayOutputStream(){override fun write(b:ByteArray,off:Int,len:Int){bytes+=len;require(count+len<=8*1024*1024 && bytes<=64L*1024*1024){"Notes cloud history exceeds sync limit"};super.write(b,off,len)}};http.stream("https://www.googleapis.com/drive/v3/files/"+GoogleDriveApi.enc(item.id)+"?alt=media",auth,out){if(Thread.currentThread().isInterrupted)throw InterruptedIOException("Notes sync cancelled")};NoteEvent.parse(JSONObject(out.toString("UTF-8")))}
 }
 override fun write(event:NoteEvent){val boundary="files-note-"+java.util.UUID.randomUUID();val meta=JSONObject().put("name","files-note-v1-${event.rev}.json").put("mimeType","application/json").put("parents",JSONArray().put("appDataFolder"));val body=("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+meta+"\r\n--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+event.json()+"\r\n--$boundary--\r\n").toByteArray(Charsets.UTF_8);require(body.size<=8*1024*1024){"Notes revision too large"};good(http.request("POST","https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id",auth+mapOf("Content-Type" to "multipart/related; boundary=$boundary"),body))}
}
