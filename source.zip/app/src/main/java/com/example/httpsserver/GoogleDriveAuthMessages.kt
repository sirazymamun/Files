package com.example.httpsserver

/** A cancelled activity result is not proof that the person cancelled Google authorization. */
internal object GoogleDriveAuthMessages {
 fun describe(code:Int?,resultCode:Int?):String {
  val reason=when(code){
   10 -> "Google rejected this app's OAuth configuration (developer error)."
   7 -> "Google reported a network error. Check internet access and try again."
   4 -> "Google requires account sign-in or renewed consent."
   16,12501 -> "Google authorization was cancelled or did not complete. This alone does not confirm why it stopped."
   else -> if(code==null)"Google returned no authorization details. The connection did not complete; the exact cause is unavailable." else "Google authorization failed (error $code)."
  }
  val detail=if(code==null)"" else "\nGoogle error code: $code"
  val returned=if(resultCode==null)"" else "\nActivity result: $resultCode"
  val setup=if(code==7 || code==4)"" else "\n\nCheck Google Cloud OAuth registration against this APK's package and signing SHA-1. Setup steps: TUTORIAL_BN.txt."
  return reason+detail+returned+setup
 }
}
