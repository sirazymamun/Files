package com.example.httpsserver

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.PopupMenu

/** One accessible overflow control for the dark native headers. */
internal object HeaderMenus {
 fun more(activity:Activity,label:String="More options",click:(View)->Unit):ImageButton{
  fun dp(value:Int)=(value*activity.resources.displayMetrics.density).toInt()
  return ImageButton(activity).apply{
   setImageDrawable(ManagerIcon("More"));contentDescription=label;scaleType=android.widget.ImageView.ScaleType.FIT_CENTER;setPadding(dp(8),dp(8),dp(8),dp(8));minimumWidth=dp(48);minimumHeight=dp(48);isFocusable=true;isClickable=true;stateListAnimator=null;elevation=0f
   val focus=StateListDrawable().apply{addState(intArrayOf(android.R.attr.state_focused),ColorDrawable(Color.rgb(59,81,88)));addState(intArrayOf(),ColorDrawable(Color.TRANSPARENT))}
   background=RippleDrawable(ColorStateList.valueOf(Color.argb(65,255,255,255)),focus,null);setOnClickListener{click(it)}
  }
 }
 fun show(activity:Activity,anchor:View,actions:List<Pair<String,()->Unit>>){
  PopupMenu(activity,anchor,Gravity.END).apply{
   actions.forEachIndexed{i,action->menu.add(0,i,i,action.first)}
   setOnMenuItemClickListener{item->actions.getOrNull(item.itemId)?.second?.invoke();true};show()
  }
 }
}
