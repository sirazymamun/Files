package com.example.httpsserver

import android.content.Context
import android.os.Build
import android.os.CancellationSignal
import android.provider.MediaStore
import java.io.File

/** MediaStore plus a direct shared-storage scan, grouped by real parent path, never app-name guesses. */
internal object ImageAlbums {
 data class Photo(val file:File,val root:File,val recent:Long)
 data class Album(val folder:File,val root:File,val photos:List<Photo>){val cover get()=photos.first();val name get()=folder.name}
 data class Result(val albums:List<Album>,val partial:Boolean,val unreadable:Int){val photos get()=albums.sumOf{it.photos.size}}
 fun group(photos:Collection<Photo>,partial:Boolean=false,unreadable:Int=0):Result=Result(photos.groupBy{it.file.parentFile!!.path}.values.map{items->val ordered=items.sortedWith(compareByDescending<Photo>{it.recent}.thenBy{it.file.name});Album(ordered.first().file.parentFile!!,ordered.first().root,ordered)}.sortedWith(compareByDescending<Album>{it.cover.recent}.thenBy{it.folder.path}),partial,unreadable)
 @Suppress("DEPRECATION")
 fun scan(context:Context,roots:List<File>,hidden:Boolean,cancelled:()->Boolean={false},indexed:((Result)->Unit)?=null,signal:CancellationSignal=CancellationSignal()):Result {
  val bases=roots.map{it.canonicalFile}.distinct().sortedByDescending{it.path.length};val photos=linkedMapOf<String,Photo>();val excluded=hashSetOf<String>();var partial=false;var unreadable=0
  fun add(file:File,recent:Long=0,indexedPhoto:Boolean=false){
   if(cancelled())return
   runCatching{val canonical=file.canonicalFile;if(file.absolutePath!=canonical.path || canonical.path in excluded)return
    val base=bases.firstOrNull{canonical.path.startsWith(it.path+File.separator)} ?: return
    if(SharedFiles(base,hidden).resolve(canonical.path.removePrefix(base.path))!=canonical || !canonical.isFile || !canonical.canRead())return
    if(!indexedPhoto && FileManagerOps.category(canonical)!="Images")return
    val time=maxOf(recent,canonical.lastModified(),photos[canonical.path]?.recent ?: 0);photos[canonical.path]=Photo(canonical,base,time)
   }
  }
  try{
   val uri=if(Build.VERSION.SDK_INT>=29)MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
   val columns=mutableListOf("_data","date_added","date_modified");if(Build.VERSION.SDK_INT>=29)columns.add("is_pending");if(Build.VERSION.SDK_INT>=30)columns.add("is_trashed")
   context.contentResolver.query(uri,columns.toTypedArray(),null,null,"date_added DESC",signal)?.use{cursor->
    val path=cursor.getColumnIndex("_data");val added=cursor.getColumnIndex("date_added");val modified=cursor.getColumnIndex("date_modified");val pending=cursor.getColumnIndex("is_pending");val trashed=cursor.getColumnIndex("is_trashed");var n=0
    while(path>=0 && cursor.moveToNext() && !cancelled()){
     if(++n>250000){partial=true;break};val value=cursor.getString(path) ?: continue;val file=File(value);if(!file.isAbsolute)continue
     if(pending>=0 && cursor.getInt(pending)!=0 || trashed>=0 && cursor.getInt(trashed)!=0){excluded.add(file.canonicalPath);continue}
     fun date(column:Int)=if(column>=0)cursor.getLong(column).coerceIn(0,Long.MAX_VALUE/1000)*1000 else 0
     add(file,maxOf(date(added),date(modified)),true)
    }
   }
  }catch(_:Exception){/* OEM/permission/index failures fall back to direct shared-storage reads. */}
  if(!cancelled())indexed?.invoke(group(photos.values,partial,unreadable))
  val start=System.nanoTime();var visited=0
  fun walk(base:File,dir:File,depth:Int){
   if(cancelled() || Thread.currentThread().isInterrupted)return
   if(depth>128 || visited>=250000 || System.nanoTime()-start>45000000000L){partial=true;return}
   val children=runCatching{dir.listFiles()}.getOrNull();if(children==null){unreadable++;return}
   val policy=SharedFiles(base,hidden)
   for(file in children){
    if(cancelled() || Thread.currentThread().isInterrupted)return
    if(++visited>250000 || System.nanoTime()-start>45000000000L){partial=true;return}
    if(!policy.allowedPart(file.name) || runCatching{file.absolutePath!=file.canonicalPath || policy.resolve(file.path.removePrefix(base.path))==null}.getOrDefault(true))continue
    if(file.isDirectory)walk(base,file,depth+1)else add(file)
   }
  }
  for(base in bases){walk(base,base,0);val media=File(base,"Android/media");if(media.isDirectory && !cancelled())walk(base,media,0)}
  return group(photos.values,partial,unreadable)
 }
 fun albumPhotos(root:File,folder:File,hidden:Boolean,known:List<Photo> = emptyList()):List<Photo>{
  FileManagerOps(root,hidden).checked(folder,true);val policy=SharedFiles(root,hidden);val files=folder.listFiles() ?: error("Photo folder cannot be read")
  val seen=known.associateBy{it.file.path};return files.mapNotNull{file->runCatching{
   if(!file.isFile || !file.canRead() || file.path!=file.canonicalPath || policy.resolve(file.path.removePrefix(root.path))!=file || FileManagerOps.category(file)!="Images" && file.path !in seen)return@runCatching null
   Photo(file,root,maxOf(file.lastModified(),seen[file.path]?.recent ?: 0))
  }.getOrNull()}.sortedWith(compareByDescending<Photo>{it.recent}.thenBy{it.file.name})
 }
}
