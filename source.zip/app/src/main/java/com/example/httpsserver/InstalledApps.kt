package com.example.httpsserver

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import java.io.File
import java.util.Locale

internal object InstalledApps {
 data class App(val packageName:String,val label:String,val version:String,val versionCode:Long,val system:Boolean,val updatedSystem:Boolean,val apkBytes:Long?,val parts:Int,val installedAt:Long,val updatedAt:Long){
  val downloaded get()=!system || updatedSystem
  val canUninstall get()=!system || updatedSystem
 }
 @Suppress("DEPRECATION")
 fun app(context:Context,info:android.content.pm.PackageInfo):App {
  val a=info.applicationInfo ?: error("Application info unavailable")
  val sources=(listOfNotNull(a.sourceDir)+a.splitSourceDirs.orEmpty()).distinct().map(::File)
  val readable=sources.isNotEmpty() && sources.all{it.isFile && it.canRead()}
  return App(info.packageName,runCatching{context.packageManager.getApplicationLabel(a).toString()}.getOrDefault(info.packageName),info.versionName ?: "",if(Build.VERSION.SDK_INT>=28)info.longVersionCode else info.versionCode.toLong(),a.flags and ApplicationInfo.FLAG_SYSTEM!=0,a.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP!=0,if(readable)sources.sumOf{it.length()}else null,sources.size,info.firstInstallTime,info.lastUpdateTime)
 }
 @Suppress("DEPRECATION")
 fun list(context:Context):List<App> = context.packageManager.getInstalledPackages(0).mapNotNull{runCatching{app(context,it)}.getOrNull()}.sortedWith(compareBy<App>{it.label.lowercase(Locale.ROOT)}.thenBy{it.packageName})
 @Suppress("DEPRECATION")
 fun snapshot(context:Context,packageName:String):ApkBackup.Snapshot {
  val info=context.packageManager.getPackageInfo(packageName,0);val a=info.applicationInfo ?: error("App is no longer installed");val row=app(context,info)
  val sources=(listOfNotNull(a.sourceDir)+a.splitSourceDirs.orEmpty()).distinct().map{ApkBackup.Source(File(it))}
  require(sources.isNotEmpty() && sources.all{it.file.isFile && it.file.canRead()}){"This device does not allow reading all APK parts for ${row.label}"}
  return ApkBackup.Snapshot(row.packageName,row.label,row.version,row.versionCode,sources)
 }
 fun sameVersion(context:Context,snapshot:ApkBackup.Snapshot):Boolean=runCatching{val now=InstalledApps.snapshot(context,snapshot.packageName);now.versionCode==snapshot.versionCode && now.sources.map{it.file.path}==snapshot.sources.map{it.file.path}}.getOrDefault(false)
}
