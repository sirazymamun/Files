package com.example.httpsserver

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/** Device app inventory and user-initiated installer export/actions; no private data access. */
class InstalledAppsActivity:Activity(){
 private val ink=Color.rgb(30,45,50);private val teal=Color.rgb(0,132,121);private val dark=Color.rgb(32,32,32)
 private lateinit var title:TextView;private lateinit var status:TextView;private lateinit var search:EditText;private lateinit var list:ListView
 private lateinit var left:ImageButton;private lateinit var more:ImageButton;private lateinit var downloadedTab:TextView;private lateinit var allTab:TextView
 private lateinit var downloadedLine:View;private lateinit var allLine:View;private lateinit var bar:LinearLayout;private lateinit var resultBar:LinearLayout
 private val work=Executors.newSingleThreadExecutor();private var apps=listOf<InstalledApps.App>();private var shown=listOf<InstalledApps.App>()
 private var downloaded=true;private var order="Name";private val selected=linkedSetOf<String>();private var busy=false;private var request=0
 private val uninstallQueue=java.util.ArrayDeque<String>();private var uninstallActive=false
 private val adapter by lazy{AppAdapter()};private val marks by lazy{getSharedPreferences("app-backups",MODE_PRIVATE)}
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun label(value:String,size:Float=14f)=TextView(this).apply{text=value;textSize=size;setTextColor(ink)}
 private fun horizontal()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
 private fun background(dark:Boolean=false)=android.graphics.drawable.StateListDrawable().apply{
  addState(intArrayOf(android.R.attr.state_focused),android.graphics.drawable.ColorDrawable(if(dark)Color.rgb(62,94,95)else Color.rgb(218,239,234)))
  addState(intArrayOf(android.R.attr.state_pressed),android.graphics.drawable.ColorDrawable(if(dark)Color.rgb(62,94,95)else Color.rgb(218,239,234)))
  addState(intArrayOf(),android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
 }
 private fun imageButton(kind:String,description:String,action:()->Unit)=ImageButton(this).apply{
  contentDescription=description;setImageDrawable(if(kind in setOf("Close","Select all"))AppActionIcon(kind)else ManagerIcon(kind));scaleType=ImageView.ScaleType.FIT_CENTER;setPadding(dp(6),dp(6),dp(6),dp(6));background=background(true);setOnClickListener{if(!busy)action()}
 }
 override fun onCreate(state:Bundle?){super.onCreate(state)
  window.statusBarColor=dark;window.navigationBarColor=if(Build.VERSION.SDK_INT>=26)Color.rgb(250,250,250)else Color.BLACK;window.decorView.systemUiVisibility=if(Build.VERSION.SDK_INT>=26)View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else 0
  downloaded=state?.getBoolean("downloaded") ?: true;order=state?.getString("order") ?: "Name"
  val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
  val header=horizontal().apply{setBackgroundColor(dark)};left=imageButton("Up","Back"){if(selected.isEmpty())finish()else clearSelection()};header.addView(left,LinearLayout.LayoutParams(dp(48),dp(56)))
  title=label("Apps",20f).apply{gravity=Gravity.CENTER_VERTICAL;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD);isSingleLine=true};header.addView(title,LinearLayout.LayoutParams(0,dp(56),1f))
  header.addView(imageButton("Search","Search apps"){search.visibility=if(search.visibility==View.VISIBLE)View.GONE else View.VISIBLE;if(search.visibility==View.VISIBLE)search.requestFocus()},LinearLayout.LayoutParams(dp(48),dp(56)))
  more=HeaderMenus.more(this,"App options"){options()};header.addView(more,LinearLayout.LayoutParams(dp(48),dp(56)));shell.addView(header)
  val tabs=horizontal()
  fun tab(value:String,select:()->Unit):Pair<TextView,View>{val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;isFocusable=true;contentDescription=value;background=background();setOnClickListener{if(!busy){clearSelection();select();update()}}};val text=label(value,12f).apply{gravity=Gravity.CENTER;letterSpacing=.07f;setTypeface(null,Typeface.BOLD)};val line=View(this);box.addView(text,LinearLayout.LayoutParams(-1,dp(45)));box.addView(line,LinearLayout.LayoutParams(-1,dp(3)));tabs.addView(box,LinearLayout.LayoutParams(0,dp(48),1f));return text to line}
  tab("DOWNLOADED"){downloaded=true}.also{downloadedTab=it.first;downloadedLine=it.second};tab("ALL"){downloaded=false}.also{allTab=it.first;allLine=it.second};shell.addView(tabs)
  search=EditText(this).apply{hint="Search app name or package";textSize=14f;isSingleLine=true;visibility=View.GONE;setPadding(dp(14),0,dp(14),0)};shell.addView(search,LinearLayout.LayoutParams(-1,dp(44)))
  search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){update()};override fun afterTextChanged(s:android.text.Editable?){} })
  status=label("Loading installed apps…",11f).apply{setTextColor(Color.GRAY);setPadding(dp(14),dp(4),dp(14),dp(4))};shell.addView(status)
  list=ListView(this).apply{divider=android.graphics.drawable.ColorDrawable(Color.rgb(224,224,224));dividerHeight=dp(1);isDrawSelectorOnTop=true;selector=android.graphics.drawable.ColorDrawable(Color.argb(60,0,132,121));adapter=this@InstalledAppsActivity.adapter}
  list.setOnItemClickListener{_,_,position,_->shown.getOrNull(position)?.let{if(selected.isEmpty())appMenu(it)else toggle(it.packageName)}}
  list.setOnItemLongClickListener{_,_,position,_->shown.getOrNull(position)?.let{toggle(it.packageName)};true};shell.addView(list,LinearLayout.LayoutParams(-1,0,1f))
  resultBar=horizontal().apply{setBackgroundColor(Color.rgb(246,248,247));visibility=View.GONE};shell.addView(resultBar)
  bar=horizontal().apply{setBackgroundColor(Color.rgb(0,55,68));visibility=View.GONE};shell.addView(bar,LinearLayout.LayoutParams(-1,dp(56)))
  setContentView(shell);update()
 }
 override fun onResume(){super.onResume();if(!busy)reload()}
 override fun onSaveInstanceState(out:Bundle){out.putBoolean("downloaded",downloaded);out.putString("order",order);super.onSaveInstanceState(out)}
 override fun onDestroy(){request++;work.shutdownNow();super.onDestroy()}
 private fun reload(){val token=++request;status.text="Loading installed apps…";work.execute{val result=runCatching{InstalledApps.list(this)};runOnUiThread{if(token==request && !isFinishing){result.onSuccess{apps=it;selected.retainAll(apps.map{a->a.packageName}.toSet());update()}.onFailure{status.text=it.message ?: "Unable to read installed apps"}}}}}
 private fun update(){
  val filter=search.text.toString();shown=apps.filter{(!downloaded||it.downloaded)&&(it.label.contains(filter,true)||it.packageName.contains(filter,true))}.let{rows->when(order){"APK size"->rows.sortedByDescending{it.apkBytes ?: -1};"Updated"->rows.sortedByDescending{it.updatedAt};else->rows.sortedWith(compareBy<InstalledApps.App>{it.label.lowercase(Locale.ROOT)}.thenBy{it.packageName})}}
  downloadedLine.setBackgroundColor(if(downloaded)teal else Color.TRANSPARENT);allLine.setBackgroundColor(if(downloaded)Color.TRANSPARENT else teal);downloadedTab.setTextColor(if(downloaded)teal else Color.GRAY);allTab.setTextColor(if(downloaded)Color.GRAY else teal)
  title.text=if(selected.isEmpty())"Apps" else  "${selected.size}/${shown.size}";left.setImageDrawable(if(selected.isEmpty())ManagerIcon("Up")else AppActionIcon("Close"));left.contentDescription=if(selected.isEmpty())"Back" else  "Clear selection"
  more.setImageDrawable(if(selected.isEmpty())ManagerIcon("More")else AppActionIcon("Select all"));more.setOnClickListener{if(!busy){if(selected.isEmpty())options()else{selected.addAll(shown.map{it.packageName});update()}}};more.contentDescription=if(selected.isEmpty())"App options" else  "Select all shown apps"
  if(!busy)status.text="${shown.size} ${if(shown.size==1)"app" else  "apps"} • APK size (base + splits)"
  adapter.notifyDataSetChanged();bar.removeAllViews();bar.visibility=if(selected.isEmpty())View.GONE else View.VISIBLE
  val targets=apps.filter{it.packageName in selected}
  for(action in listOf("Backup","Uninstall","Share","Open","Store")){
   val cell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=background(true);isFocusable=true;contentDescription=action}
   cell.addView(ImageView(this).apply{setImageDrawable(AppActionIcon(action))},LinearLayout.LayoutParams(dp(23),dp(23)))
   cell.addView(label(action,10f).apply{setTextColor(Color.WHITE);gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,dp(19)))
   val enabled=when(action){"Open","Store"->targets.size==1;"Uninstall"->targets.isNotEmpty()&&targets.all{it.canUninstall};else->targets.isNotEmpty()};cell.isEnabled=enabled;cell.alpha=if(enabled)1f else .4f
   cell.setOnClickListener{if(!busy)when(action){"Backup"->export(targets,false);"Share"->export(targets,true);"Uninstall"->uninstall(targets);"Open"->openApp(targets.single());"Store"->store(targets.single())}}
   bar.addView(cell,LinearLayout.LayoutParams(0,dp(56),1f))
  }
 }
 private fun clearSelection(){selected.clear();update()}
 private fun toggle(packageName:String){if(busy)return;if(!selected.add(packageName))selected.remove(packageName);update()}
 private fun options(){val popup=PopupMenu(this,more,Gravity.END);listOf("Select all shown","Sort","Refresh","Saved APK files","Backup folder").forEachIndexed{i,s->popup.menu.add(0,i,0,s)};popup.setOnMenuItemClickListener{when(it.itemId){0->{selected.addAll(shown.map{a->a.packageName});update()};1->AlertDialog.Builder(this).setTitle("Sort apps").setItems(arrayOf("Name","APK size","Updated")){_,i->order=arrayOf("Name","APK size","Updated")[i];update()}.show();2->reload();3->{setResult(RESULT_OK,Intent().putExtra("saved_apks",true));finish()};4->returnFolder(backupDirectory())};true};popup.show()}
 private fun appMenu(app:InstalledApps.App){val actions=listOf("Open","Backup","Share","Store","App info","Properties")+(if(app.canUninstall)listOf("Uninstall")else emptyList());AlertDialog.Builder(this).setTitle(app.label).setItems(actions.toTypedArray()){_,i->when(actions[i]){"Open"->openApp(app);"Backup"->export(listOf(app),false);"Share"->export(listOf(app),true);"Store"->store(app);"App info"->appInfo(app);"Properties"->properties(app);"Uninstall"->uninstall(listOf(app))}}.show()}
 private fun openApp(app:InstalledApps.App){val pm=packageManager;val tv=resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK==android.content.res.Configuration.UI_MODE_TYPE_TELEVISION;val intent=(if(tv)pm.getLeanbackLaunchIntentForPackage(app.packageName)else pm.getLaunchIntentForPackage(app.packageName)) ?: pm.getLaunchIntentForPackage(app.packageName) ?: pm.getLeanbackLaunchIntentForPackage(app.packageName);if(intent==null)show("Open app","This app has no launchable screen.")else runCatching{startActivity(intent)}.onFailure{show("Open app",it.message ?: "App unavailable")}}
 private fun store(app:InstalledApps.App){runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=${app.packageName}")))}.onFailure{runCatching{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=${app.packageName}")))}.onFailure{show("Store","No app store or browser is available.")}}}
 private fun appInfo(app:InstalledApps.App){runCatching{startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:${app.packageName}")))}.onFailure{show("App info",it.message ?: "Unavailable")}}
 private fun backupDirectory():File? {if(!StorageAccess.hasFullAccess(this)){requestStorage();return null};return runCatching{
  val root=StorageAccess.root(this);val ops=FileManagerOps(root);val backups=ops.child(root,"backups");if(!backups.exists())check(backups.mkdir());require(backups.isDirectory);val apps=ops.child(backups,"apps");if(!apps.exists())check(apps.mkdir());require(apps.isDirectory);apps
 }.getOrElse{show("Backup folder",it.message ?: "Cannot create backup folder");null}}
 private fun requestStorage(){AlertDialog.Builder(this).setTitle("Storage permission needed").setMessage("Allow device storage access to save backups in /backups/apps. Sharing uses private temporary storage.").setPositiveButton("Allow"){_,_->if(Build.VERSION.SDK_INT>=30)runCatching{startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:$packageName")))}.onFailure{runCatching{startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))}}else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE),72)}.setNegativeButton("Cancel",null).show()}
 private fun returnFolder(folder:File?){if(folder!=null){setResult(RESULT_OK,Intent().putExtra("folder",folder.path));finish()}}
 private fun export(targets:List<InstalledApps.App>,sharing:Boolean){
  if(busy || targets.isEmpty())return
  if(targets.size>200){show("Apps","Select at most 200 apps at a time.");return}
  val folder=if(sharing)runCatching{ApkBackup.shareDirectory(cacheDir)}.getOrElse{show("Share",it.message ?: "Cannot prepare temporary package");return}else backupDirectory() ?: return
  busy=true;status.text=if(sharing)"Preparing app packages…" else  "Backing up apps…";resultBar.visibility=View.GONE;update()
  work.execute{
   val files=mutableListOf<File>();val errors=mutableListOf<String>()
   for((i,app) in targets.withIndex()){
    if(Thread.currentThread().isInterrupted)break
    runOnUiThread{status.text="${if(sharing)"Preparing" else  "Backing up"} ${i+1}/${targets.size}: ${app.label}"}
    runCatching{val snapshot=InstalledApps.snapshot(this,app.packageName);val result=ApkBackup.write(snapshot,folder);if(!InstalledApps.sameVersion(this,snapshot)){ApkBackup.discard(result);error("App updated during backup. Refresh and retry.")};files.addAll(if(sharing)ApkBackup.apkFiles(result)else listOf(result));if(!sharing)marks.edit().putLong("version:${app.packageName}",snapshot.versionCode).putString("path:${app.packageName}",result.path).putInt("parts:${app.packageName}",snapshot.sources.size).apply()}.onFailure{errors.add("${app.label}: ${it.message}")}
   }
   runOnUiThread{if(!isFinishing){busy=false;selected.clear();update();if(sharing && files.isNotEmpty()){if(errors.isEmpty())shareFiles(files)else AlertDialog.Builder(this).setTitle("Some app exports failed").setMessage(errors.joinToString("\n")).setPositiveButton("Share ${files.size} APK files"){_,_->shareFiles(files)}.setNegativeButton("Close",null).show()}else if(!sharing && files.isNotEmpty()){
    resultBar.removeAllViews();val text=label("${files.size} app(s) backed up to /backups/apps",12f).apply{setPadding(dp(12),dp(10),0,dp(10))};resultBar.addView(text,LinearLayout.LayoutParams(0,-2,1f));resultBar.addView(Button(this).apply{setText("OPEN");isAllCaps=false;background=background();setTextColor(teal);setOnClickListener{returnFolder(folder)}});resultBar.visibility=View.VISIBLE
   };if(errors.isNotEmpty() && (!sharing || files.isEmpty()))show("App export result",errors.joinToString("\n"))}}
  }
 }
 private fun shareFiles(files:List<File>){runCatching{
  val uris=ArrayList(files.map{FileProvider.getUriForFile(this,"$packageName.files",it)});val type=if(files.all{it.extension=="apk"})"application/vnd.android.package-archive" else  "application/zip"
  val intent=if(uris.size==1)Intent(Intent.ACTION_SEND).setType(type).putExtra(Intent.EXTRA_STREAM,uris.first())else Intent(Intent.ACTION_SEND_MULTIPLE).setType(if(files.map{it.extension}.distinct().size==1)type else "*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris)
  intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.clipData=ClipData.newRawUri("App packages",uris.first()).apply{uris.drop(1).forEach{addItem(ClipData.Item(it))}};startActivity(Intent.createChooser(intent,"Share app packages"))
 }.onFailure{show("Share",it.message ?: "No compatible sharing app")}}
 private fun uninstall(targets:List<InstalledApps.App>){if(targets.any{!it.canUninstall}){show("Uninstall","System apps must be managed in Android App info.");return};uninstallQueue.clear();targets.forEach{uninstallQueue.add(it.packageName)};nextUninstall()}
 @Suppress("DEPRECATION") private fun nextUninstall(){val name=uninstallQueue.poll() ?: run{uninstallActive=false;reload();return};uninstallActive=true;runCatching{startActivityForResult(Intent(Intent.ACTION_UNINSTALL_PACKAGE,Uri.parse("package:$name")).putExtra(Intent.EXTRA_RETURN_RESULT,true),71)}.onFailure{uninstallActive=false;uninstallQueue.clear();show("Uninstall",it.message ?: "Device does not allow this uninstall")}}
 @Deprecated("Platform result") override fun onActivityResult(request:Int,result:Int,data:Intent?){super.onActivityResult(request,result,data);if(request==71){uninstallActive=false;if(result==RESULT_OK)nextUninstall()else{uninstallQueue.clear();reload()}}}
 private fun properties(app:InstalledApps.App){val text="Name: ${app.label}\nPackage: ${app.packageName}\nVersion: ${app.version}\nVersion code: ${app.versionCode}\nType: ${if(app.system)if(app.updatedSystem)"Updated system app" else  "System app" else  "Downloaded app"}\nAPK size: ${app.apkBytes?.let{FileManagerOps.formatBytes(it)+" ($it bytes)"} ?: "Unavailable"}\nAPK parts: ${app.parts}\nInstalled: ${FileDetails.date(app.installedAt)}\nUpdated: ${FileDetails.date(app.updatedAt)}\nTime zone: ${java.util.TimeZone.getDefault().id}\n\nInstaller files only; app data and cache are not included."
  AlertDialog.Builder(this).setTitle("App properties").setView(ScrollView(this).apply{addView(label(text,14f).apply{setTextIsSelectable(true);setPadding(dp(18),dp(12),dp(18),dp(12))})}).setPositiveButton("Close",null).setNeutralButton("Copy"){_,_->(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("App properties",text))}.show()
 }
 private fun show(title:String,message:String)=AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Close",null).show()
 @Deprecated("Platform back") override fun onBackPressed(){if(busy){Toast.makeText(this,"App export is running",Toast.LENGTH_SHORT).show();return};if(selected.isNotEmpty())clearSelection()else super.onBackPressed()}
 private inner class AppAdapter:BaseAdapter(){override fun getCount()=shown.size;override fun getItem(position:Int)=shown[position];override fun getItemId(position:Int)=position.toLong()
  override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
   val app=getItem(position);val row=horizontal().apply{minimumHeight=dp(64);setPadding(dp(10),dp(7),dp(10),dp(7));setBackgroundColor(if(app.packageName in selected)Color.rgb(181,224,218)else Color.WHITE)}
   if(selected.isNotEmpty())row.addView(CheckBox(this@InstalledAppsActivity).apply{isFocusable=false;isChecked=app.packageName in selected;contentDescription="Select ${app.label}";setOnClickListener{toggle(app.packageName)}},LinearLayout.LayoutParams(dp(34),dp(40)))
   val frame=FrameLayout(this@InstalledAppsActivity);frame.addView(ImageView(this@InstalledAppsActivity).apply{scaleType=ImageView.ScaleType.FIT_CENTER;setImageDrawable(runCatching{packageManager.getApplicationIcon(app.packageName)}.getOrNull() ?: ManagerIcon("Apps"))},FrameLayout.LayoutParams(dp(42),dp(42)))
   val backup=marks.getString("path:${app.packageName}",null);if(backup!=null && marks.getLong("version:${app.packageName}",-1)==app.versionCode && runCatching{ApkBackup.apkFiles(File(backup)).size==marks.getInt("parts:${app.packageName}",1)}.getOrDefault(false))frame.addView(ImageView(this@InstalledAppsActivity).apply{setBackgroundColor(teal);setImageDrawable(AppActionIcon("Backup"));contentDescription="Backed up"},FrameLayout.LayoutParams(dp(16),dp(16),Gravity.BOTTOM or Gravity.RIGHT))
   row.addView(frame,LinearLayout.LayoutParams(dp(44),dp(44)).apply{rightMargin=dp(12)})
   val labels=LinearLayout(this@InstalledAppsActivity).apply{orientation=LinearLayout.VERTICAL};labels.addView(label(app.label,15f).apply{maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END});labels.addView(label(app.apkBytes?.let{FileManagerOps.formatBytes(it)} ?: "Size unavailable",11f).apply{setTextColor(Color.GRAY)})
   row.addView(labels,LinearLayout.LayoutParams(0,-2,1f));row.addView(label(app.version,11f).apply{setTextColor(Color.GRAY);maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END;gravity=Gravity.RIGHT;maxWidth=dp(resources.configuration.screenWidthDp/3)},LinearLayout.LayoutParams(-2,-2).apply{gravity=Gravity.BOTTOM;leftMargin=dp(8);bottomMargin=dp(3)})
   return row
  }
 }
}
