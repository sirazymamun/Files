package com.example.httpsserver

import com.github.junrar.Archive
import net.lingala.zip4j.ZipFile
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Decode into a fresh staging folder; commit to existing destinations without overwriting. */
internal object LocalArchives {
 data class Entry(val name:String,val bytes:Long,val directory:Boolean)
 private const val MAX_ENTRIES=10000
 private const val MAX_BYTES=8L*1024*1024*1024
 fun entries(file:File,password:String=""):List<Entry> = when(file.extension.lowercase()){
  "zip" -> ZipFile(file,password.toCharArray()).use {zip -> zip.fileHeaders.take(MAX_ENTRIES+1).map{Entry(it.fileName,it.uncompressedSize,it.isDirectory)}}
  "rar" -> Archive(file,password).use {rar -> rar.fileHeaders.take(MAX_ENTRIES+1).map{Entry(it.fileName,it.fullUnpackSize,it.isDirectory)}}
  else -> throw IOException("Built-in extraction supports ZIP and RAR. Use Open with for this format.")
 }.also{require(it.size<=MAX_ENTRIES){"Archive has too many entries"}}
 private fun relative(name:String):String {
  val normalized=name.replace('\\','/').trimEnd('/')
  require(normalized.isNotBlank() && !normalized.startsWith('/') && !Regex("^[A-Za-z]:").containsMatchIn(normalized)){"Unsafe archive path"}
  val parts=normalized.split('/')
  require(parts.size<=128){"Archive path is nested too deeply"}
  require(parts.none{it.isBlank()||it=="."||it==".."||it.contains(':')}){"Unsafe archive path"}
  return parts.joinToString("/")
 }
 fun extract(root:File,archive:File,destination:File,password:String="",includeHidden:Boolean=false,destinationRoot:File=root):Int {
  FileManagerOps(root,includeHidden).checked(archive);val ops=FileManagerOps(destinationRoot,includeHidden);ops.archiveChecked(destination)
  require(!destination.exists()){"Choose a new destination folder"}
  val listed=entries(archive,password);val paths=mutableSetOf<String>()
  for(entry in listed){val path=relative(entry.name);require(paths.add(path)){"Duplicate archive path"};var item=destination;for(part in path.split('/'))item=ops.childForArchive(item,part);require(entry.bytes<=MAX_BYTES){"Archive entry is too large"}}
  check(destination.mkdir()){"Cannot create extraction folder"};val made=mutableListOf(destination);var bytes=0L;val started=System.nanoTime()
  fun checkBudget(){if(Thread.currentThread().isInterrupted || System.nanoTime()-started>600000000000L)throw IOException("Extraction cancelled or time limit reached")}
  fun target(name:String,directory:Boolean):File {
   checkBudget();val rel=relative(name);var parent=destination
   val parts=rel.split('/');for(part in parts.dropLast(1)){val child=ops.childForArchive(parent,part);if(!child.exists()){check(made.size<MAX_ENTRIES*2){"Archive creates too many folders"};check(child.mkdir());made.add(child)};require(child.isDirectory);parent=child}
   val result=ops.childForArchive(parent,parts.last())
   if(directory){if(!result.exists()){check(made.size<MAX_ENTRIES*2){"Archive creates too many folders"};check(result.mkdir());made.add(result)};require(result.isDirectory)}else{check(result.createNewFile()){"Archive entry already exists"};made.add(result)}
   return result
  }
  fun output(file:File):OutputStream {val stream=file.outputStream();return object:OutputStream(){
   override fun write(value:Int){val b=byteArrayOf(value.toByte());write(b,0,1)}
   override fun write(buffer:ByteArray,offset:Int,length:Int){checkBudget();if(length.toLong()>MAX_BYTES-bytes)throw IOException("Extraction exceeds 8 GB limit");bytes+=length;stream.write(buffer,offset,length)}
   override fun close(){stream.close()}
  }}
  try {
   when(archive.extension.lowercase()){
    "zip" -> ZipFile(archive,password.toCharArray()).use{zip->for(header in zip.fileHeaders){
     val f=target(header.fileName,header.isDirectory)
     if(!header.isDirectory)zip.getInputStream(header).use{input->output(f).use{out->input.copyTo(out,65536)}}
     if(header.lastModifiedTimeEpoch>0)f.setLastModified(header.lastModifiedTimeEpoch)
    }}
    "rar" -> Archive(archive,password).use{rar->for(header in rar.fileHeaders){
     require(header.redirection==null && !(header.hostOS?.name=="unix" && header.fileAttr and 61440==40960)){"Archive links are not supported"}
     val f=target(header.fileName,header.isDirectory)
     if(!header.isDirectory)output(f).use{out->rar.extractFile(header,out)}
     header.mTime?.time?.takeIf{it>0}?.let{f.setLastModified(it)}
    }}
   }
   return listed.count{!it.directory}
  }catch(e:Exception){made.asReversed().forEach{runCatching{it.delete()}};throw IOException("Extraction failed: ${e.message}. Try Open with for unsupported archives.",e)}
 }
 data class Extraction(val files:Int,val renamed:Int)
 fun availableFolder(root:File,parent:File,name:String,includeHidden:Boolean=false):File {
  val ops=FileManagerOps(root,includeHidden);ops.checked(parent,true);var target=ops.child(parent,name);var i=1
  while(target.exists()){require(i<=10000){"Too many existing folders"};target=ops.child(parent,"$name (${i++})")};return target
 }
 /** Existing files are retained. Conflicting incoming files get a new name; directories merge. */
 fun extractInto(root:File,archive:File,directory:File,password:String="",includeHidden:Boolean=false,destinationRoot:File=root):Extraction {
  val ops=FileManagerOps(destinationRoot,includeHidden);ops.checked(directory,true);require(directory.isDirectory && directory.canWrite()){"Choose a writable destination folder"}
  val container=File(directory,".Files-extract-"+java.util.UUID.randomUUID());ops.archiveChecked(container);check(container.mkdir()){"Cannot create extraction staging folder"};val stage=File(container,"payload");val made=mutableListOf<File>();val reserved=mutableSetOf(container.path);var renamed=0;val started=System.nanoTime()
  fun budget(){check(!Thread.currentThread().isInterrupted && System.nanoTime()-started<1200000000000L){"Extraction cancelled or time limit reached"}}
  fun cleanup(file:File){if(java.nio.file.Files.isSymbolicLink(file.toPath())){file.delete();return};if(file.absolutePath!=file.canonicalPath || (file!=container && !file.path.startsWith(container.path+File.separator)))return;if(file.isDirectory)file.listFiles()?.forEach(::cleanup);file.delete()}
  try{
   val count=extract(root,archive,stage,password,includeHidden,destinationRoot)
   data class Move(val source:File,val target:File,val existingDirectory:Boolean,val modified:Long)
   val plan=mutableListOf<Move>()
   fun incoming(parent:File,name:String,isDirectory:Boolean):File {
    val direct=ops.childForArchive(parent,name)
    if(direct.path !in reserved && (!direct.exists() || isDirectory && direct.isDirectory)){reserved.add(direct.path);return direct}
    val dot=name.lastIndexOf('.');val stem=if(!isDirectory && dot>0)name.substring(0,dot)else name;val ext=if(!isDirectory && dot>0)name.substring(dot)else "";var i=1
    while(i<=10000){val next=ops.childForArchive(parent,"$stem (extracted ${i++})$ext");if(!next.exists() && reserved.add(next.path)){renamed++;return next}};error("Too many name conflicts")
   }
   fun visit(source:File,parent:File,depth:Int){budget();require(depth<=128 && plan.size<MAX_ENTRIES*2){"Extraction tree limit"};val target=incoming(parent,source.name,source.isDirectory);plan.add(Move(source,target,source.isDirectory && target.isDirectory,source.lastModified()));if(source.isDirectory)(source.listFiles() ?: error("Staged folder cannot be read")).forEach{visit(it,target,depth+1)}}
   (stage.listFiles() ?: error("Staging folder cannot be read")).forEach{visit(it,directory,0)}
   for(move in plan){budget();ops.archiveChecked(move.target);if(move.source.isDirectory){if(!move.existingDirectory){check(move.target.mkdir()){"Destination changed. Retry extraction."};made.add(move.target)}}else{val length=move.source.length();java.nio.file.Files.move(move.source.toPath(),move.target.toPath());made.add(move.target);check(move.target.length()==length){"Extracted file is incomplete"};move.target.setLastModified(move.modified)}}
   plan.filter{it.source.isDirectory && !it.existingDirectory}.asReversed().forEach{it.target.setLastModified(it.modified)}
   return Extraction(count,renamed)
  }catch(e:Exception){made.asReversed().forEach{runCatching{it.delete()}};throw e}finally{runCatching{cleanup(container)}}
 }
 // For preflight, ancestors need not exist yet; use policy + canonical containment directly.
 private fun FileManagerOps.archiveChecked(file:File):File {
  val base=root.canonicalFile;val target=file.canonicalFile
  require(target.path==file.absolutePath && target.path.startsWith(base.path+File.separator)){"Archive path escapes storage or uses a link"}
  val parts=target.path.removePrefix(base.path+File.separator).split(File.separatorChar)
  val publicMedia=parts.size>=2 && parts[0].equals("Android",true) && parts[1].equals("media",true)
  // Only real protected *root* paths are forbidden here. A nested file named
  // desktop.ini or a nested folder named Android is harmless archive content.
  val protectedRoot=parts.firstOrNull()?.lowercase(java.util.Locale.ROOT) in setOf(
   "android","lost.dir","system volume information","$"+"recycle.bin","desktop.ini","thumbs.db","thumbcache.db"
  ) && !publicMedia
  require(!protectedRoot && parts.all{SharedFiles(root).allowedArchivePart(it)}){
   "Archive destination uses a protected or invalid path: ${file.name}"
  }
  return target
 }
 private fun FileManagerOps.childForArchive(parent:File,name:String):File {
  require(SharedFiles(root).allowedArchivePart(name)){"Archive entry has an unsafe name: $name"}
  return archiveChecked(File(parent,name))
 }
 fun compress(root:File,items:List<File>,destination:File,includeHidden:Boolean=false):Int {
  val ops=FileManagerOps(root,includeHidden);ops.checked(destination);require(items.isNotEmpty());require(!destination.exists()){"Archive already exists"}
  val paths=mutableSetOf<String>();val plan=mutableListOf<Pair<File,String>>();val started=System.nanoTime()
  fun visit(file:File,path:String,depth:Int){
   check(!Thread.currentThread().isInterrupted && depth<=128 && plan.size<MAX_ENTRIES && System.nanoTime()-started<600000000000L){"Compression limit reached"};ops.archiveChecked(file);require(file.canRead()){"Cannot read ${file.name}"};require(paths.add(path)){"Duplicate archive filename"};plan.add(file to path)
   if(file.isDirectory)(file.listFiles() ?: throw IOException("Folder cannot be read")).forEach{visit(it,"$path/${it.name}",depth+1)}else require(file.isFile)
  }
  items.forEach{ops.checked(it);require(destination!=it && !destination.path.startsWith(it.path+File.separator)){"Archive cannot be created inside a selected folder"};visit(it,it.name,0)}
  check(destination.createNewFile())
  try{ZipOutputStream(destination.outputStream(),Charsets.UTF_8).use{zip->for((f,path) in plan){ops.archiveChecked(f);zip.putNextEntry(ZipEntry(path+if(f.isDirectory)"/" else  "").apply{time=f.lastModified()});if(f.isFile)f.inputStream().use{input->val buffer=ByteArray(65536);while(true){check(!Thread.currentThread().isInterrupted && System.nanoTime()-started<600000000000L){"Compression cancelled or time limit reached"};val n=input.read(buffer);if(n<0)break;zip.write(buffer,0,n)}};zip.closeEntry()}}}catch(e:Exception){destination.delete();throw e}
  return plan.count{it.first.isFile}
 }
}
