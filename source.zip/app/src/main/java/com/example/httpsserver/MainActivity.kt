package com.example.httpsserver

import android.Manifest
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import androidx.appcompat.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.provider.Settings
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.text.InputType
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.text.DateFormat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var toggle: SwitchCompat
    private lateinit var status: TextView
    private lateinit var qr: ImageView
    private lateinit var url: TextView
    private lateinit var pass: TextView
    private lateinit var setup: TextView
    private lateinit var copyInfo: Button
    private lateinit var certBtn: Button
    private lateinit var storageStatus: TextView
    private lateinit var fileAccess: Button
    private lateinit var stopButton: Button
    private var wantedStart = false
    private var waitingForStart = false
    private var waitingForSettings = false
    private var receiverRegistered = false
    private var permissionDialog: AlertDialog? = null
    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            waitingForStart = false
            render(ServerService.running || ServerService.starting)
            updateStorageStatus()
        }
    }
    private var syncing = false
    private var busy = false
    private val bg = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toggle = findViewById(R.id.serverSwitch)
        status = findViewById(R.id.status)
        qr = findViewById(R.id.qr)
        url = findViewById(R.id.url)
        pass = findViewById(R.id.pass)
        setup = findViewById(R.id.setup)
        certBtn = findViewById(R.id.certBtn)
        copyInfo = findViewById(R.id.copyInfo)
        copyInfo.setOnClickListener { copyConnectionInfo() }
        storageStatus = findViewById(R.id.storageStatus)
        fileAccess = findViewById(R.id.fileAccess)
        stopButton = findViewById(R.id.stopButton)
        fileAccess.setOnClickListener {
            if (ServerService.running || ServerService.starting || waitingForStart) {
                Toast.makeText(this, "Stop the server before changing file access", Toast.LENGTH_LONG).show()
            } else { wantedStart = false; requestStorageAccess() }
        }
        stopButton.setOnClickListener { stopServer() }
        findViewById<Button>(R.id.editDomain).setOnClickListener { editDomain() }
        findViewById<Button>(R.id.portForward).setOnClickListener {
            startActivity(Intent(this, PortForwardActivity::class.java))
        }

        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)

        toggle.setOnCheckedChangeListener { _, on ->
            if (syncing) return@setOnCheckedChangeListener
            if (on) startServer() else stopServer()
        }
        certBtn.setOnClickListener { onCertButton() }
        // Copy the complete displayed address block and password without changing credentials.
        for (label in listOf(url, pass)) {
            label.setOnClickListener { copyConnectionInfo() }
            label.setOnLongClickListener { copyConnectionInfo(); true }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(this, stateReceiver, IntentFilter(ServerService.ACTION_STATE), ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        if (!StorageAccess.hasFullAccess(this) &&
            (ServerService.running || ServerService.starting)) {
            stopServer()
        }
        render(ServerService.running || ServerService.starting || waitingForStart)
        updateStorageStatus()
        refreshCert()
        if (waitingForSettings) {
            waitingForSettings = false
            if (StorageAccess.hasFullAccess(this)) onFullAccessGranted() else showPermissionUnavailable()
        }
    }

    override fun onPause() {
        if (receiverRegistered) { unregisterReceiver(stateReceiver); receiverRegistered = false }
        super.onPause()
    }

    override fun onDestroy() {
        permissionDialog?.dismiss()
        super.onDestroy()
    }

    private fun updateStorageStatus() {
        val access = if (StorageAccess.hasFullAccess(this))
            "Device storage access allowed — internal storage and mounted SD / USB. Protected system / private app data is excluded."
        else "Device storage permission is required. Tap Device storage access to open Android / Fire OS settings."
        val extra = ServerService.lastMessage.takeIf { it.isNotBlank() }?.let { "\n$it" } ?: ""
        storageStatus.text = access + extra
    }

    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT < 30) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_STORAGE)
        } else openStorageSettings()
    }

    private fun openStorageSettings() {
        val app = Uri.parse("package:$packageName")
        val intents = if (Build.VERSION.SDK_INT >= 30) listOf(
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, app),
            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, app)
        ) else listOf(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, app))
        for (intent in intents) {
            try {
                waitingForSettings = true
                startActivity(intent)
                return
            } catch (_: Exception) { waitingForSettings = false }
        }
        showPermissionUnavailable()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_STORAGE -> if (StorageAccess.hasFullAccess(this)) onFullAccessGranted() else showPermissionUnavailable()

        }
    }

    private fun onFullAccessGranted() {
        updateStorageStatus()
        if (wantedStart) startActualServer()
    }

    private fun showPermissionUnavailable() {
        wantedStart = false
        waitingForStart = false
        updateStorageStatus()
        render(ServerService.running || ServerService.starting)
        permissionDialog?.dismiss()
        permissionDialog = AlertDialog.Builder(this)
            .setTitle("Device storage permission is off")
            .setMessage("Android / Fire OS has not granted device storage access. In system settings enable All Files / Allow management of all files for TV2U. If your Fire OS refuses the switch, this app cannot grant it itself. No private app-folder mode is used. Protected system files and other apps' private data are unavailable to a normal app.")
            .setPositiveButton("Open device settings") { _, _ -> requestStorageAccess() }
            .setNegativeButton("Close") { _, _ -> render(ServerService.running || ServerService.starting) }
            .show()
    }

    private fun startServer() {
        wantedStart = true
        if (!StorageDecision.canStart(StorageAccess.hasFullAccess(this))) {
            render(false)
            requestStorageAccess()
            return
        }
        startActualServer()
    }

    private fun startActualServer() {
        if (!wantedStart) return
        if (ServerService.running || ServerService.starting || waitingForStart) return
        if (CertHelper.localIp() == null) {
            wantedStart = false
            Toast.makeText(this, "Connect to Wi-Fi or LAN first", Toast.LENGTH_LONG).show()
            render(false)
            return
        }
        try {
            waitingForStart = true
            ContextCompat.startForegroundService(this, Intent(this, ServerService::class.java).setAction(ServerService.ACTION_START))
            render(true)
        } catch (e: Exception) {
            waitingForStart = false
            wantedStart = false
            ServerService.lastMessage = "The server could not start: ${e.message}"
            render(false)
            updateStorageStatus()
        }
    }

    private fun stopServer() {
        // Always available: no storage check, no permission settings and no new foreground service.
        wantedStart = false
        waitingForStart = false
        waitingForSettings = false
        permissionDialog?.dismiss()
        ServerService.lastMessage = "Server stopped"
        stopService(Intent(this, ServerService::class.java))
        render(false)
        updateStorageStatus()
    }

    private fun editDomain() {
        if (ServerService.running || ServerService.starting || waitingForStart || busy) {
            Toast.makeText(this, "Stop the server and wait for certificate setup before editing the domain", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(Provisioner.domain(this@MainActivity))
        }
        val dialog = AlertDialog.Builder(this).setTitle("Edit domain")
            .setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (ServerService.running || ServerService.starting || waitingForStart || busy) return@setOnClickListener
                try {
                    Provisioner.saveDomain(this, input.text.toString())
                    dialog.dismiss()
                    refreshCert()
                    render(false)
                    Toast.makeText(this, "Domain saved", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) { input.error = e.message ?: "Invalid domain" }
            }
        }
        dialog.show()
    }

    private fun serverAddress(): String =
        if (CertHelper.domainCertExpiry(this) != null) "https://${Provisioner.domain(this)}:${ServerService.PORT}"
        else "https://${CertHelper.localIp()}:${ServerService.PORT}"

    private fun render(on: Boolean) {
        syncing = true
        toggle.isChecked = on
        syncing = false
        status.text = if (!on) "Server off" else if (ServerService.running) "Server on" else "Starting... (Stop is available)"
        if (on && ServerService.running) {
            val address = serverAddress()
            qr.setImageBitmap(qrBitmap(address))
            qr.visibility = View.VISIBLE
            url.text = ConnectionInfo.addresses(
                "https://${CertHelper.localIp() ?: "127.0.0.1"}:${ServerService.PORT}",
                "https://${Provisioner.domain(this)}:${ServerService.PORT}"
            )
            pass.text = "Password: ${Auth.password(this)}"
            pass.visibility = View.VISIBLE
            copyInfo.visibility = View.VISIBLE
        } else {
            qr.visibility = View.INVISIBLE
            url.text = ""
            pass.visibility = View.GONE
            pass.text = ""
            copyInfo.visibility = View.GONE
        }
    }

    private fun copyConnectionInfo() {
        if (url.text.isNullOrBlank() || pass.visibility != View.VISIBLE) return
        val text = ConnectionInfo.text(url.text.toString(), Auth.password(this))
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("tv2u server connection", text))
        Toast.makeText(this, "Addresses and password copied", Toast.LENGTH_SHORT).show()
    }

    private fun refreshCert() {
        val expiry = CertHelper.domainCertExpiry(this)
        setup.visibility = View.VISIBLE
        if (expiry != null) {
            certBtn.visibility = View.GONE
            setup.text = "Trusted certificate for ${Provisioner.domain(this)}\nValid until ${DateFormat.getDateInstance().format(expiry)}"
            if (expiry.time - System.currentTimeMillis() < 30L * 24 * 3600 * 1000) runProvision()
            return
        }
        certBtn.visibility = View.VISIBLE
        val creds = Provisioner.creds(this)
        if (creds == null) {
            setup.text = "No trusted certificate yet. Browsers will show a warning until you set one up."
            certBtn.text = "Set up trusted certificate"
        } else {
            setup.text = Provisioner.instructions(this, creds)
            certBtn.text = "I added the records, get certificate"
        }
    }

    private fun onCertButton() {
        if (busy) return
        if (Provisioner.creds(this) != null) {
            runProvision()
            return
        }
        busy = true
        certBtn.isEnabled = false
        setup.text = "Preparing…"
        bg.execute {
            try {
                Provisioner.register(this)
                runOnUiThread { busy = false; certBtn.isEnabled = true; refreshCert() }
            } catch (e: Exception) {
                runOnUiThread {
                    busy = false
                    certBtn.isEnabled = true
                    setup.text = "Couldn't reach the setup service: ${e.message}"
                }
            }
        }
    }

    private fun runProvision() {
        if (busy) return
        busy = true
        certBtn.isEnabled = false
        bg.execute {
            try {
                Provisioner.provision(this) { msg -> runOnUiThread { setup.text = msg } }
                runOnUiThread {
                    busy = false
                    certBtn.isEnabled = true
                    refreshCert()
                    render(ServerService.running)
                    if (ServerService.running)
                        Toast.makeText(this, "Turn the server off and on to use the new certificate", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                val hint = Provisioner.dnsHint(this)
                runOnUiThread {
                    busy = false
                    certBtn.isEnabled = true
                    setup.append("\n\nFailed: ${e.message}\n$hint")
                }
            }
        }
    }

    companion object {
        private const val REQUEST_STORAGE = 41
    }

    private fun qrBitmap(text: String, size: Int = 512): Bitmap {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size,
            mapOf(EncodeHintType.MARGIN to 0))
        val px = IntArray(size * size) { i -> if (m[i % size, i / size]) Color.BLACK else Color.WHITE }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }
}
