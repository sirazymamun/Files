package com.example.httpsserver

import java.io.File
import java.io.IOException

/** Local UI-only folder listing. Does not change the server, provider or write security policy.
 * The Android directory is a navigation shell: only Android/media is browseable via
 * the existing SharedFiles shared-storage policy; Android/data and Android/obb stay blocked.
 */
internal object MainStorageListing {
    fun androidDirectory(root: File): File = File(root, "Android")
    fun isAndroidDirectory(root: File, folder: File): Boolean =
        folder.absolutePath == androidDirectory(root).absolutePath &&
            folder.canonicalPath == androidDirectory(root).canonicalPath

    fun browseable(root: File, folder: File, policy: SharedFiles): Boolean =
        isAndroidDirectory(root, folder) || policy.resolve(folder.path.removePrefix(root.path)) != null

    fun children(root: File, folder: File, policy: SharedFiles, hideEmpty: Boolean): List<File> {
        val isAndroid = isAndroidDirectory(root, folder)
        val children = folder.listFiles() ?: throw IOException("Folder permission denied or storage disconnected")
        return children.filter { child ->
            if (child.absolutePath != child.canonicalPath) return@filter false
            if (isAndroid) {
                // Android/media is shared content. Private app directories are not.
                child.name == "media" && child.isDirectory &&
                    policy.resolve(child.path.removePrefix(root.path)) != null &&
                    (!hideEmpty || policy.visibleInListing(child))
            } else if (folder.canonicalPath == root.canonicalPath && isAndroidDirectory(root, child)) {
                // Show the Android folder like other file managers, without granting
                // access to Android/data, Android/obb or other protected descendants.
                child.isDirectory && (!hideEmpty || File(child, "media").isDirectory)
            } else {
                policy.allowedPart(child.name) &&
                    policy.resolve(child.path.removePrefix(root.path)) != null &&
                    (!hideEmpty || policy.visibleInListing(child))
            }
        }
    }
}
