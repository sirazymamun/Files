package com.example.httpsserver

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.os.Build
import android.os.CancellationSignal
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import java.io.File

/** Small, bounded in-memory thumbnails. Call load on a worker, never the UI thread. */
internal class MediaThumbnails {
 private val cache=object:LruCache<String,Bitmap>(8*1024*1024){override fun sizeOf(key:String,value:Bitmap)=value.allocationByteCount}
 private val signals=mutableSetOf<CancellationSignal>()
 @Volatile private var closed=false
 @Suppress("DEPRECATION") fun load(root:File,file:File,includeHidden:Boolean=false):Bitmap? {
  if(closed || Thread.currentThread().isInterrupted)return null
  val signal=CancellationSignal()
  synchronized(signals){if(closed)return null;signals.add(signal)}
  try{
   FileManagerOps(root,includeHidden).checked(file);if(!file.isFile || !file.canRead())return null
   val length=file.length();val modified=file.lastModified();val key=file.canonicalPath+"|$length|$modified"
   cache.get(key)?.let{return it}
   val decoded=when(FileManagerOps.category(file)){
    "Videos"->if(Build.VERSION.SDK_INT>=29)ThumbnailUtils.createVideoThumbnail(file,Size(SIDE,SIDE),signal)else ThumbnailUtils.createVideoThumbnail(file.path,MediaStore.Images.Thumbnails.MINI_KIND)
    "Images"->{val options=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeFile(file.path,options);if(options.outWidth<=0 || options.outHeight<=0)return null;var sample=1;while(maxOf(options.outWidth,options.outHeight)/sample>SIDE && sample<=16384)sample*=2;options.inSampleSize=sample;options.inJustDecodeBounds=false;BitmapFactory.decodeFile(file.path,options)}
    else->null
   } ?: return null
   val largest=maxOf(decoded.width,decoded.height)
   val bitmap=if(largest>SIDE){val scale=SIDE.toDouble()/largest;Bitmap.createScaledBitmap(decoded,(decoded.width*scale).toInt().coerceAtLeast(1),(decoded.height*scale).toInt().coerceAtLeast(1),true).also{if(it!==decoded)decoded.recycle()}}else decoded
   if(closed || signal.isCanceled || Thread.currentThread().isInterrupted || file.length()!=length || file.lastModified()!=modified){bitmap.recycle();return null}
   cache.put(key,bitmap);return bitmap
  }catch(_:Exception){return null}catch(_:OutOfMemoryError){return null}finally{synchronized(signals){signals.remove(signal)}}
 }
 fun close(){closed=true;val pending=synchronized(signals){signals.toList().also{signals.clear()}};pending.forEach{it.cancel()};cache.evictAll()}
 companion object{const val SIDE=256}
}
