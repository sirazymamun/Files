package com.example.httpsserver

import java.io.*
import java.util.concurrent.Semaphore
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Streams selected sibling files and folders as a single ZIP. */
internal object MultiArchive {
    private val slots = Semaphore(2)
    fun stream(root: File, items: List<File>): InputStream? {
        if (!slots.tryAcquire()) return null
        val input = PipedInputStream(128 * 1024)
        val output = PipedOutputStream(input)
        val worker = Thread({
            try {
                val base = root.canonicalFile
                val policy = SharedFiles(base)
                ZipOutputStream(output, Charsets.UTF_8).use { zip ->
                    val buffer = ByteArray(65536)
                    fun add(file: File, name: String, depth: Int) {
                        if (Thread.currentThread().isInterrupted) throw IOException("Cancelled")
                        if (depth > 128) throw IOException("Folder depth exceeded")
                        val canonical = file.canonicalFile
                        if (canonical.path != file.absolutePath || policy.resolve(canonical.path.removePrefix(base.path)) != canonical || !file.canRead()) return
                        if (file.isDirectory) {
                            zip.putNextEntry(ZipEntry("$name/").apply { time = file.lastModified() }); zip.closeEntry()
                            for (child in (file.listFiles() ?: throw IOException("Unreadable folder")).sortedBy { it.name }) {
                                if (policy.allowedPart(child.name)) add(child, "$name/${child.name}", depth + 1)
                            }
                        } else if (file.isFile) {
                            zip.putNextEntry(ZipEntry(name).apply { time = file.lastModified() })
                            file.inputStream().use { source -> while (true) { val n = source.read(buffer); if (n < 0) break; zip.write(buffer, 0, n) } }
                            zip.closeEntry()
                        }
                    }
                    for (item in items) add(item, item.name, 0)
                }
            } catch (_: Exception) { /* Closed connection terminates transfer. */ }
            finally { try { output.close() } finally { slots.release() } }
        }, "tv2u-multi-zip").apply { isDaemon = true }
        val wrapped = object : FilterInputStream(input) { override fun close() { worker.interrupt(); super.close() } }
        try { worker.start() } catch (e: Exception) { output.close(); input.close(); slots.release(); throw e }
        return wrapped
    }
}
