package com.example.httpsserver

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.util.concurrent.Executors

/** A small notes editor in the same native theme; saved notes remain ordinary shared TXT files. */
class NotesActivity:Activity(){
 private lateinit var store:NotesStore
 private lateinit var shell:LinearLayout
 private lateinit var heading:TextView
 private lateinit var content:LinearLayout
 private lateinit var status:TextView
 private lateinit var search:EditText
 private var titleInput:EditText?=null
 private var bodyInput:EditText?=null
 private var note:NotesStore.Note?=null
 private var newAfterClose=false;private var editor=false;private var dirty=false;private var busy=false
 private val syncHandler=android.os.Handler(android.os.Looper.getMainLooper());private var syncStamp=0L
 private val syncWatch=object:Runnable{override fun run(){val stamp=NotesSync.prefs(this@NotesActivity).getLong("last",0);if(stamp!=syncStamp && !editor && !busy){syncStamp=stamp;showList()};syncHandler.postDelayed(this,3000)}}
 private var notes=listOf<NotesStore.Summary>();private var lastDeleted:TrashStore.Entry?=null
 private val work=Executors.newSingleThreadExecutor()
 private val drafts by lazy{getSharedPreferences("notes-draft",MODE_PRIVATE)}
 private val teal=Color.rgb(0,132,121);private val ink=Color.rgb(30,45,50)
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun text(value:String,size:Float=14f)=TextView(this).apply{text=value;textSize=size;setTextColor(ink)}
 private fun row()=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
 private fun action(value:String,dark:Boolean=false,click:()->Unit)=Button(this).apply{text=value;isAllCaps=false;textSize=if(value=="←"||value=="⋮")24f else 14f;stateListAnimator=null;elevation=0f;minWidth=0;minimumWidth=0;setTextColor(if(dark)Color.WHITE else teal);setBackgroundColor(Color.TRANSPARENT);setOnClickListener{if(!busy)click()}}
 override fun onCreate(state:Bundle?){super.onCreate(state)
  try{store=NotesStore(StorageAccess.root(this));store.directory()}catch(e:Exception){Toast.makeText(this,e.message ?: "Storage access is required",Toast.LENGTH_LONG).show();finish();return}
  window.statusBarColor=Color.rgb(32,32,32);window.navigationBarColor=Color.WHITE
  shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE)}
  val top=row().apply{setBackgroundColor(Color.rgb(32,32,32))};top.addView(action("←",true){back()},LinearLayout.LayoutParams(dp(48),dp(56)))
  heading=text("Notes",20f).apply{setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)};top.addView(heading,LinearLayout.LayoutParams(0,-2,1f))
  top.addView(action("New note",true){newNote()},LinearLayout.LayoutParams(dp(98),dp(56)))
  top.addView(HeaderMenus.more(this,"Notes options"){options(it)},LinearLayout.LayoutParams(dp(48),dp(56)));shell.addView(top)
  status=text("Notes · saved as TXT",11f).apply{setPadding(dp(14),dp(5),dp(14),dp(5));setTextColor(Color.GRAY)};shell.addView(status)
  search=EditText(this).apply{hint="Search notes";isSingleLine=true;textSize=14f;setPadding(dp(14),0,dp(14),0)};shell.addView(search,LinearLayout.LayoutParams(-1,dp(44)))
  content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};shell.addView(content,LinearLayout.LayoutParams(-1,0,1f));setContentView(shell)
  search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(!editor)bindList()};override fun afterTextChanged(s:Editable?){} })
  if(drafts.contains("body")){
   val path=drafts.getString("path",null);val old=path?.let{NotesStore.Note(File(it),drafts.getString("originalTitle","") ?: "","",drafts.getString("digest","") ?: "")}
   openEditor(old,drafts.getString("title","New note") ?: "New note",drafts.getString("body","") ?: "");dirty=true;status.text="Unsaved draft restored"
  }else showList()
 }
 override fun onResume(){super.onResume();if(::store.isInitialized){NotesSync.request(this);syncHandler.post(syncWatch)}}
 override fun onPause(){syncHandler.removeCallbacks(syncWatch);stashDraft();super.onPause()}
 override fun onSaveInstanceState(out:Bundle){stashDraft();super.onSaveInstanceState(out)}
 override fun onDestroy(){work.shutdown();super.onDestroy()}
 private fun stashDraft(){if(!editor || !dirty || busy)return;drafts.edit().putString("title",titleInput?.text?.toString()).putString("body",bodyInput?.text?.toString()).putString("path",note?.file?.path).putString("originalTitle",note?.title).putString("digest",note?.digest).apply()}
 private fun showList(message:String=""){
  editor=false;dirty=false;titleInput=null;bodyInput=null;note=null;heading.text="Notes";search.visibility=View.VISIBLE;content.removeAllViews();status.text=if(message.isBlank())"Reading notes…" else message
  work.execute{val result=runCatching{store.list()};runOnUiThread{if(!isDestroyed && !editor){result.onSuccess{notes=it;status.text=if(message.isNotBlank())message else "${it.size} notes · ${store.directory().path}";if(NotesSync.enabled(this))status.text=status.text.toString()+" · Drive: "+NotesSync.prefs(this).getString("status","");bindList()}.onFailure{status.text=it.message ?: "Cannot read notes"}}}}
 }
 private fun bindList(){if(editor)return;content.removeAllViews();val shown=notes.filter{it.title.contains(search.text.toString(),true)}
  val list=ListView(this);list.adapter=object:BaseAdapter(){override fun getCount()=shown.size;override fun getItem(position:Int)=shown[position];override fun getItemId(position:Int)=position.toLong();override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
   val item=shown[position];val line=row().apply{setPadding(dp(10),dp(5),dp(6),dp(5))};line.addView(ImageView(this@NotesActivity).apply{setImageDrawable(ManagerIcon("Notes"));scaleType=ImageView.ScaleType.FIT_CENTER},LinearLayout.LayoutParams(dp(44),dp(44)))
   val labels=LinearLayout(this@NotesActivity).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,0,0)};labels.addView(text(item.title,16f).apply{maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END});labels.addView(text(FileDetails.date(item.modified)+" · "+FileManagerOps.formatBytes(item.bytes),11f));line.addView(labels,LinearLayout.LayoutParams(0,-2,1f));return line
  }}
  list.setOnItemClickListener{_,_,position,_->load(shown[position].file)};list.setOnItemLongClickListener{_,_,position,_->noteOptions(shown[position]);true};content.addView(list,LinearLayout.LayoutParams(-1,0,1f))
  if(shown.isEmpty())content.addView(text(if(notes.isEmpty())"No notes yet. Tap New note." else "No matching notes",14f).apply{setPadding(dp(16),dp(8),dp(16),dp(8))})
  if(lastDeleted!=null)content.addView(action("Undo delete"){val entry=lastDeleted ?: return@action;operate({store.restore(entry)}){lastDeleted=null;NotesSync.request(this);showList("Note restored")}},LinearLayout.LayoutParams(-1,dp(48)))
 }
 private fun load(file:File){operate({store.read(file)}){openEditor(it,it.title,it.text)}}
 private fun openEditor(value:NotesStore.Note?,title:String,body:String){
  note=value;editor=true;dirty=false;heading.text=if(value==null)"New note" else "Edit note";search.visibility=View.GONE;content.removeAllViews();status.text="UTF-8 text · Up to 1 MB · Save to keep changes"
  titleInput=EditText(this).apply{hint="Note title";isSingleLine=true;setText(title);textSize=18f;setPadding(dp(14),dp(4),dp(14),dp(4))};content.addView(titleInput,LinearLayout.LayoutParams(-1,dp(52)))
  bodyInput=EditText(this).apply{hint="Write your note…";gravity=Gravity.TOP or Gravity.LEFT;setText(body);textSize=16f;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;setPadding(dp(14),dp(10),dp(14),dp(10));setHorizontallyScrolling(false)};content.addView(bodyInput,LinearLayout.LayoutParams(-1,0,1f))
  val watcher=object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){dirty=true};override fun afterTextChanged(s:Editable?){} };titleInput!!.addTextChangedListener(watcher);bodyInput!!.addTextChangedListener(watcher)
  val buttons=row();buttons.addView(action("Save"){save()},LinearLayout.LayoutParams(0,dp(48),1f));buttons.addView(action("Close"){back()},LinearLayout.LayoutParams(0,dp(48),1f));content.addView(buttons)
 }
 private fun newNote(){if(editor && dirty){newAfterClose=true;back();return};runCatching{store.nextTitle()}.onSuccess{openEditor(null,it,"")}.onFailure{error(it.message ?: "Cannot create note")}}
 private fun save(copy:Boolean=false){
  stashDraft();val before=if(copy)null else note;val title=titleInput?.text?.toString() ?: return;val body=bodyInput?.text?.toString() ?: return
  operate({val desired=if(copy)store.nextTitle(title+" copy")else title;val saved=store.save(before,desired,body);drafts.edit().clear().apply();NotesSync.request(this);saved}){if(newAfterClose){newAfterClose=false;dirty=false;newNote()}else showList("Saved: ${it.title}")}
 }
 private fun noteOptions(item:NotesStore.Summary){AlertDialog.Builder(this).setTitle(item.title).setItems(arrayOf("Open / Edit","Rename","Share","Copy text","Delete")){_,which->when(which){0->load(item.file);1->rename(item.file);2->operate({store.read(item.file)}){share(it.title,it.text)};3->operate({store.read(item.file)}){copy(it.text)};4->delete(item.file)}}.show()}
 private fun rename(file:File){operate({store.read(file)}){original->val input=EditText(this).apply{isSingleLine=true;setText(original.title)};AlertDialog.Builder(this).setTitle("Rename note").setView(input).setPositiveButton("Rename"){_,_->val value=input.text.toString();operate({store.rename(original,value)}){NotesSync.request(this);showList("Note renamed")}}.setNegativeButton("Cancel",null).show()}}
 private fun delete(file:File){operate({store.delete(store.read(file))}){entry->lastDeleted=entry;NotesSync.request(this);drafts.edit().clear().apply();showList("Note moved to Recycle Bin")}}
 private fun options(anchor:View){if(busy)return
  if(editor){val actions=mutableListOf<Pair<String,()->Unit>>("Share" to {share(titleInput!!.text.toString(),bodyInput!!.text.toString())},"Copy text" to {copy(bodyInput!!.text.toString())},"Save a copy" to {save(true)},"Google Drive sync" to {syncSettings()});if(note!=null)actions.add("Delete" to {note?.let{delete(it.file)};Unit});HeaderMenus.show(this,anchor,actions)}
  else HeaderMenus.show(this,anchor,listOf("New note" to {newNote()},"Refresh" to {NotesSync.request(this);showList()},"Google Drive sync" to {syncSettings()}))
 }
 private fun syncSettings(){val p=NotesSync.prefs(this);val enabled=NotesSync.enabled(this);val last=p.getLong("last",0);val details=(if(enabled)"Auto-sync on" else "Auto-sync off")+"\n"+(p.getString("account","") ?: "")+"\n"+(p.getString("status","") ?: "")+(if(last>0)"\nLast sync: "+FileDetails.date(last)else "");val dialog=AlertDialog.Builder(this).setTitle("Notes · Google Drive").setMessage(details).setPositiveButton(if(enabled)"Reconnect" else "Enable auto-sync"){_,_->startActivity(Intent(this,GoogleDriveActivity::class.java).putExtra("notesSync",true))};if(enabled)dialog.setNeutralButton("Sync now"){_,_->NotesSync.request(this)};dialog.setNegativeButton(if(enabled)"Turn off" else "Close"){_,_->if(enabled)NotesSync.disable(this)}.show()}
 private fun share(title:String,body:String){runCatching{startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,title).putExtra(Intent.EXTRA_TEXT,body),"Share note"))}.onFailure{error(it.message ?: "No sharing app available")}}
 private fun copy(body:String){(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Note",body));Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show()}
 private fun error(message:String){AlertDialog.Builder(this).setTitle("Notes").setMessage(message).setPositiveButton("Close",null).show()}
 private fun <T> operate(task:()->T,done:(T)->Unit){if(busy)return;busy=true;titleInput?.isEnabled=false;bodyInput?.isEnabled=false;status.text="Working…";work.execute{val result=runCatching(task);runOnUiThread{busy=false;titleInput?.isEnabled=true;bodyInput?.isEnabled=true;if(!isDestroyed && !isFinishing)result.onSuccess(done).onFailure{status.text=it.message ?: "Operation failed";error(it.message ?: "Operation failed")}}}}
 private fun back(){if(busy)return;if(!editor){finish();return};if(!dirty){drafts.edit().clear().apply();showList();return};AlertDialog.Builder(this).setTitle("Save changes?").setPositiveButton("Save"){_,_->save()}.setNegativeButton("Discard"){_,_->drafts.edit().clear().apply();if(newAfterClose){newAfterClose=false;dirty=false;newNote()}else showList()}.setNeutralButton("Keep editing"){_,_->newAfterClose=false}.setOnCancelListener{newAfterClose=false}.show()}
 @Deprecated("Platform back") override fun onBackPressed(){back()}
}
