package com.example.httpsserver

import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.security.MessageDigest
import java.util.UUID

internal data class NoteEvent(val id:String,val rev:String,val parents:List<String>,val title:String,val text:String,val deleted:Boolean){
 fun json()=JSONObject().put("schema",1).put("id",id).put("revision",rev).put("parents",JSONArray(parents)).put("title",title).put("text",text).put("deleted",deleted)
 companion object{fun parse(j:JSONObject):NoteEvent{require(j.getInt("schema")==1){"Unsupported notes cloud format"};val id=j.getString("id");val rev=j.getString("revision");require(id.matches(Regex("[A-Za-z0-9-]{1,100}")) && rev.matches(Regex("[A-Za-z0-9-]{1,100}"))){"Invalid note revision"};val a=j.getJSONArray("parents");require(a.length()<=1000);val parents=(0 until a.length()).map{a.getString(it)};val text=j.getString("text");require(text.toByteArray(Charsets.UTF_8).size<=NotesStore.MAX_BYTES){"Cloud note exceeds 1 MB"};return NoteEvent(id,rev,parents,j.getString("title"),text,j.getBoolean("deleted"))}}
}
internal interface NotesRemote{fun read():List<NoteEvent>;fun write(event:NoteEvent)}
/** Immutable revisions + parent links make concurrent edits detectable without timestamp guesses. */
internal class NotesCloudSync(private val store:NotesStore,private val stateFile:File,private val remote:NotesRemote,private val cancelled:()->Boolean={false}){
 data class Result(var sent:Int=0,var received:Int=0,var conflicts:Int=0)
 private data class Record(val id:String,var rev:String,var title:String,var path:String,var digest:String,var deleted:Boolean){fun json()=JSONObject().put("id",id).put("rev",rev).put("title",title).put("path",path).put("digest",digest).put("deleted",deleted)}
 private val records=linkedMapOf<String,Record>();private val pending=mutableListOf<NoteEvent>();private val result=Result()
 private fun hash(value:String)=MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it.toInt() and 255)}
 private fun ensure(){if(cancelled()||Thread.currentThread().isInterrupted)throw java.util.concurrent.CancellationException("Notes sync cancelled")}
 private fun persist(){ensure();stateFile.parentFile!!.mkdirs();val json=JSONObject().put("schema",1).put("records",JSONArray(records.values.map{it.json()})).put("pending",JSONArray(pending.map{it.json()}));val stage=File(stateFile.parentFile,stateFile.name+".tmp");val data=json.toString().toByteArray(Charsets.UTF_8);require(data.size<=32*1024*1024){"Notes pending data exceeds sync limit"};stage.outputStream().use{out->out.write(data);out.fd.sync()};check(stage.renameTo(stateFile)){"Cannot save notes sync state"}}
 private fun load(){if(!stateFile.exists())return;require(stateFile.length()<=32L*1024*1024){"Notes sync state is too large"};val j=JSONObject(stateFile.readText());require(j.getInt("schema")==1);val a=j.getJSONArray("records");for(i in 0 until a.length()){val r=a.getJSONObject(i);val item=Record(r.getString("id"),r.getString("rev"),r.getString("title"),r.getString("path"),r.getString("digest"),r.getBoolean("deleted"));records[item.id]=item};val q=j.getJSONArray("pending");for(i in 0 until q.length())pending.add(NoteEvent.parse(q.getJSONObject(i)))}
 private fun unique(title:String,id:String,own:File?=null):String{val used=store.list().map{it.file}.filter{it!=own}.map{it.name.lowercase()}.toSet();var value=title;var i=0;while((value+".txt").lowercase() in used){value=title.take(100)+" ("+id.takeLast(8)+(if(i++==0)"" else " $i")+")"};return value}
 fun sync():Result{
  ensure();load();val events=linkedMapOf<String,NoteEvent>();for(e in remote.read()){val previous=events.put(e.rev,e);require(previous==null||previous==e){"Inconsistent cloud note revision"}}
  fun flush(){for(e in pending.toList()){val old=events[e.rev];require(old==null||old==e){"Conflicting cloud event"};if(old==null){remote.write(e);events[e.rev]=e;result.sent++};pending.remove(e);persist()}}
  flush()
  val local=store.list();require(local.size<=1000){"Notes auto-sync supports up to 1,000 notes"};val byPath=local.associateBy{it.file.path};var total=0L
  for(record in records.values.toList().filter{!it.deleted}){
   val summary=byPath[record.path]
   if(summary==null){val e=NoteEvent(record.id,UUID.randomUUID().toString(),listOf(record.rev),record.title,"",true);record.rev=e.rev;record.deleted=true;pending.add(e);persist()}
   else{val n=store.read(summary.file);total+=n.text.toByteArray(Charsets.UTF_8).size;require(total<=8L*1024*1024){"Notes total exceeds 8 MB auto-sync limit"};if(n.digest!=record.digest||n.title!=record.title){val e=NoteEvent(record.id,UUID.randomUUID().toString(),listOf(record.rev),n.title,n.text,false);record.rev=e.rev;record.title=n.title;record.digest=n.digest;pending.add(e);persist()}}
  }
  val tracked=records.values.filter{!it.deleted}.map{it.path}.toSet()
  for(summary in local.filter{it.file.path !in tracked}){val n=store.read(summary.file);val referenced=events.values.flatMap{it.parents}.toSet();val matches=events.values.filter{!it.deleted && it.rev !in referenced && it.id !in records && it.title==n.title && it.text==n.text};if(matches.size==1){val e=matches.single();records[e.id]=Record(e.id,e.rev,n.title,n.file.path,n.digest,false);persist();continue};total+=n.text.toByteArray(Charsets.UTF_8).size;require(total<=8L*1024*1024){"Notes total exceeds 8 MB auto-sync limit"};val id=UUID.randomUUID().toString();val e=NoteEvent(id,UUID.randomUUID().toString(),emptyList(),n.title,n.text,false);records[id]=Record(id,e.rev,n.title,n.file.path,n.digest,false);pending.add(e);persist()}
  flush()
  val grouped=events.values.groupBy{it.id}
  for((id,history) in grouped){val referenced=history.flatMap{it.parents}.toSet();val heads=history.filter{it.rev !in referenced}.sortedBy{it.rev};if(heads.size<=1)continue
   val key=hash(id+heads.joinToString("|"){it.rev});val live=heads.filter{!it.deleted};val main=live.firstOrNull() ?: heads.first()
   for(other in live.drop(1).filter{it.title!=main.title || it.text!=main.text}){val fork="conflict-"+hash(id+other.rev);val title=other.title.take(100)+" (conflict "+other.rev.takeLast(8)+")";val event=NoteEvent(fork,fork,emptyList(),title,other.text,false);if(event.rev !in events){pending.add(event);result.conflicts++}}
   val merged=NoteEvent(id,"merge-$key",heads.map{it.rev},main.title,main.text,live.isEmpty());pending.add(merged);persist()
  }
  flush()
  val active=events.values.groupBy{it.id}.values.map{history->val parents=history.flatMap{it.parents}.toSet();history.filter{it.rev !in parents}}.flatten().filter{!it.deleted};require(active.size<=1000 && active.sumOf{it.text.toByteArray(Charsets.UTF_8).size.toLong()}<=8L*1024*1024){"Cloud notes exceed 1,000 notes / 8 MB sync limit"}
  for((id,history) in events.values.groupBy{it.id}){ensure();val referenced=history.flatMap{it.parents}.toSet();val heads=history.filter{it.rev !in referenced};require(heads.size==1){"Cloud note conflict needs retry"};val e=heads.single();val record=records[id];if(record?.rev==e.rev)continue
   val before=if(record!=null && !record.deleted)runCatching{store.read(File(record.path))}.getOrNull()else null
   if(record!=null && !record.deleted)require(before!=null && before.digest==record.digest){"A local note changed during sync. Retry to keep that edit."}
   if(e.deleted){if(before!=null)store.delete(before);records[id]=Record(id,e.rev,e.title,record?.path ?: "","",true)}else{
    val title=unique(e.title,id,before?.file);val saved=store.save(before,title,e.text);records[id]=Record(id,e.rev,saved.title,saved.file.path,saved.digest,false)
   };persist();result.received++
  }
  return result
 }
}
