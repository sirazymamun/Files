package com.example.httpsserver

import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.security.MessageDigest
import java.util.UUID

/** Portable UTF-8 notes in shared storage. Existing contents are checked before replacement. */
internal class NotesStore(val root:File){
 data class Summary(val file:File,val title:String,val modified:Long,val bytes:Long)
 data class Note(val file:File,val title:String,val text:String,val digest:String)
 private val ops=FileManagerOps(root)
 fun directory():File=ops.child(root,"Notes").apply{if(!exists())check(mkdir()){"Cannot create Notes folder"};require(isDirectory){"Notes is not a folder"}}
 private fun target(title:String):File{val name=title.trim().let{if(it.endsWith(".txt",true))it.dropLast(4)else it};require(name.isNotBlank() && name.toByteArray(Charsets.UTF_8).size<=220){"Use a title of 1–220 UTF-8 bytes"};return ops.child(directory(),"$name.txt")}
 private fun checked(file:File):File{ops.checked(file);require(file.parentFile==directory() && file.extension.equals("txt",true)){"This is not a Notes text file"};return file}
 private fun hash(bytes:ByteArray)=MessageDigest.getInstance("SHA-256").digest(bytes).joinToString(""){"%02x".format(it.toInt() and 255)}
 fun list():List<Summary> = directory().listFiles().orEmpty().filter{it.isFile && it.extension.equals("txt",true) && runCatching{checked(it);true}.getOrDefault(false)}.map{Summary(it,it.nameWithoutExtension,it.lastModified(),it.length())}.sortedWith(compareByDescending<Summary>{it.modified}.thenBy{it.title})
 fun nextTitle(base:String="New note"):String{val folder=directory();var number=1;var name=base;while(File(folder,"$name.txt").exists()){number++;name="$base $number"};return name}
 fun read(file:File):Note{checked(file);require(file.length()<=MAX_BYTES){"Note is larger than 1 MB; use another editor"};val buffer=ByteArray(MAX_BYTES+1);var length=0;file.inputStream().use{input->while(length<buffer.size){val n=input.read(buffer,length,buffer.size-length);if(n<0)break;length+=n}};val bytes=buffer.copyOf(length);require(bytes.size<=MAX_BYTES){"Note is larger than 1 MB"};val text=Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();return Note(file,file.nameWithoutExtension,text,hash(bytes))}
 fun unchanged(note:Note):Boolean=runCatching{read(note.file).digest==note.digest}.getOrDefault(false)
 @Synchronized fun save(previous:Note?,title:String,text:String):Note{
  val bytes=text.toByteArray(Charsets.UTF_8);require(bytes.size<=MAX_BYTES){"A note can contain up to 1 MB of UTF-8 text"};val requested=target(title);val dest=if(previous!=null && previous.title==requested.nameWithoutExtension)previous.file else requested;if(previous!=null)check(unchanged(previous)){"This note changed or was deleted outside the editor. Your draft was kept."}
  val same=previous?.file==dest;require(same || !dest.exists()){"A note with this title already exists"}
  val temp=File(directory(),".FilesNote-${UUID.randomUUID()}.part");check(temp.createNewFile());var reserved=false;var committed=false
  try{
   temp.outputStream().use{it.write(bytes)}
   if(previous!=null)check(unchanged(previous)){"This note changed outside the editor. Your draft was kept."}
   if(!same){check(dest.createNewFile()){"A note with this title already exists"};reserved=true}
   check(dest.canonicalFile==dest.absoluteFile && temp.renameTo(dest)){"Cannot save note. Existing content was kept."};committed=true
   if(previous!=null && !same){if(unchanged(previous))check(previous.file.delete()){"New note saved, but the old note could not be removed"}else error("Saved under the new title; the original changed and was kept.")}
   return read(dest)
  }finally{temp.delete();if(reserved && !committed)dest.delete()}
 }
 fun rename(note:Note,title:String)=save(note,title,note.text)
 fun delete(note:Note):TrashStore.Entry{check(unchanged(note)){"Note changed; reload it before deleting"};return TrashStore(root).put(note.file)}
 fun restore(entry:TrashStore.Entry)=TrashStore(root).restore(entry)
 companion object{const val MAX_BYTES=1024*1024}
}
