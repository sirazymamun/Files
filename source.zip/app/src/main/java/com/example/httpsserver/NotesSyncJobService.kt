package com.example.httpsserver

import android.accounts.Account
import android.app.job.*
import android.content.ComponentName
import android.content.Context
import com.google.android.gms.auth.api.identity.*
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicBoolean

internal object NotesSync{
 private const val PERIODIC=71281;private const val NOW=71282;private val lock=Any()
 fun prefs(c:Context)=c.getSharedPreferences("notes-drive-sync",Context.MODE_PRIVATE)
 fun enabled(c:Context)=prefs(c).getBoolean("enabled",false)
 private fun scheduler(c:Context)=c.getSystemService(JobScheduler::class.java)
 private fun builder(c:Context,id:Int)=JobInfo.Builder(id,ComponentName(c,NotesSyncJobService::class.java)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setBackoffCriteria(30000,JobInfo.BACKOFF_POLICY_EXPONENTIAL)
 fun enable(c:Context,account:String){val p=prefs(c);if(p.getString("account",null)!=account){scheduler(c).cancel(PERIODIC);scheduler(c).cancel(NOW)};p.edit().putBoolean("enabled",true).putString("account",account).putString("status","Waiting to sync").apply();val result=scheduler(c).schedule(builder(c,PERIODIC).setPeriodic(15*60*1000L).setPersisted(true).build());if(result!=JobScheduler.RESULT_SUCCESS)p.edit().putString("status","Background sync could not be scheduled. Open Notes and retry.").apply();request(c)}
 fun disable(c:Context){prefs(c).edit().putBoolean("enabled",false).putString("status","Auto-sync off").apply();scheduler(c).cancel(PERIODIC);scheduler(c).cancel(NOW)}
 fun request(c:Context){if(!enabled(c))return;scheduler(c).schedule(builder(c,NOW).setMinimumLatency(1000).build())}
 fun run(c:Context,stopped:()->Boolean):Boolean=synchronized(lock){val prefs=prefs(c);if(!enabled(c)||stopped())return@synchronized false;val name=prefs.getString("account",null) ?: return@synchronized false;var token:String?=null
  try{prefs.edit().putString("status","Syncing Notes…").apply();val auth=Tasks.await(Identity.getAuthorizationClient(c).authorize(AuthorizationRequest.builder().setAccount(Account(name,"com.google")).setRequestedScopes(listOf(Scope(DriveNotesRemote.SCOPE))).build()),60,TimeUnit.SECONDS)
   if(auth.hasResolution() || auth.accessToken.isNullOrBlank() || DriveNotesRemote.SCOPE !in auth.grantedScopes){prefs.edit().putString("status","Reconnect Notes to Google Drive").apply();return@synchronized false}
   token=auth.accessToken;val key=MessageDigest.getInstance("SHA-256").digest(name.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it.toInt() and 255)}
   fun cancelled()=stopped()||Thread.currentThread().isInterrupted||!enabled(c)||prefs.getString("account",null)!=name
   val remote=object:NotesRemote{private val delegate=DriveNotesRemote(token!!);override fun read():List<NoteEvent>{check(!cancelled());return delegate.read()};override fun write(event:NoteEvent){check(!cancelled());delegate.write(event)}}
   val root=StorageAccess.root(c);val result=NotesCloudSync(NotesStore(root),File(c.filesDir,"notes-sync/$key.json"),remote,::cancelled).sync()
   if(!cancelled())prefs.edit().putLong("last",System.currentTimeMillis()).putString("status","Synced · ${result.sent} sent · ${result.received} received · ${result.conflicts} conflicts kept").apply();false
  }catch(e:Exception){if(e is DriveFailure && e.status==401)token?.let{Identity.getAuthorizationClient(c).clearToken(ClearTokenRequest.builder().setToken(it).build())};if(enabled(c))prefs.edit().putString("status",(e.message ?: "Notes sync paused").take(180)).apply();!stopped() && enabled(c) && (e is java.io.IOException || e is TimeoutException || e is ExecutionException) && !(e is DriveFailure && e.status in listOf(401,403))}
 }
}
class NotesSyncJobService:JobService(){
 private val executor=Executors.newFixedThreadPool(2);private val tasks=ConcurrentHashMap<Int,Future<*>>();private val stopped=ConcurrentHashMap<Int,AtomicBoolean>()
 override fun onStartJob(params:JobParameters):Boolean{if(!NotesSync.enabled(this))return false;val flag=AtomicBoolean(false);stopped[params.jobId]=flag;tasks[params.jobId]=executor.submit{try{val retry=NotesSync.run(applicationContext){flag.get()};if(!flag.get())jobFinished(params,retry)}finally{stopped.remove(params.jobId);tasks.remove(params.jobId)}};return true}
 override fun onStopJob(params:JobParameters):Boolean{stopped.remove(params.jobId)?.set(true);tasks.remove(params.jobId)?.cancel(true);return NotesSync.enabled(this)}
 override fun onDestroy(){stopped.values.forEach{it.set(true)};executor.shutdownNow();super.onDestroy()}
}
