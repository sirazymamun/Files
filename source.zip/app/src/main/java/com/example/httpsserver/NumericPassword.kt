package com.example.httpsserver

import java.security.SecureRandom

/** Six ASCII digits, including leading zeroes. */
internal object NumericPassword {
    private val random = SecureRandom()
    fun isValid(value: String?): Boolean = value != null && value.length == 6 && value.all { it in '0'..'9' }
    fun generate(): String = buildString(6) { repeat(6) { append(('0'.code + random.nextInt(10)).toChar()) } }
}
