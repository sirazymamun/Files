package com.example.httpsserver

import java.security.MessageDigest
import java.security.SecureRandom

/** Bounded, expiring password-only sessions with per-client login throttling. */
internal class PasswordSessions(private val now: () -> Long = { System.currentTimeMillis() }) {
    private data class Session(val expires: Long, val passwordHash: ByteArray)
    private data class Attempts(var count: Int, var until: Long)
    private val sessions = linkedMapOf<String, Session>()
    private val attempts = linkedMapOf<String, Attempts>()
    private val random = SecureRandom()
    private fun hash(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
    private fun clean() {
        val time = now()
        sessions.entries.removeAll { it.value.expires <= time }
        attempts.entries.removeAll { it.value.until <= time }
    }
    @Synchronized fun blocked(client: String): Boolean {
        clean();return (attempts[client]?.count ?: 0) >= 5
    }
    @Synchronized fun login(client: String, supplied: String, expected: String): String? {
        clean()
        if (blocked(client)) return null
        if (!NumericPassword.isValid(supplied) || !MessageDigest.isEqual(hash(supplied), hash(expected))) {
            if (!attempts.containsKey(client) && attempts.size >= 256) attempts.remove(attempts.keys.first())
            val entry=attempts.getOrPut(client) { Attempts(0,now()+60_000) }
            entry.count++
            return null
        }
        attempts.remove(client)
        if(sessions.size >= 64) sessions.remove(sessions.keys.first())
        val token=ByteArray(32).also(random::nextBytes).joinToString("") { "%02x".format(it.toInt() and 255) }
        sessions[token]=Session(now()+12*60*60*1000L,hash(expected))
        return token
    }
    @Synchronized fun valid(token: String?, password: String): Boolean {
        clean();if(token==null)return false
        val session=sessions[token] ?: return false
        return MessageDigest.isEqual(session.passwordHash,hash(password))
    }
    @Synchronized fun logout(token: String?) { if(token!=null)sessions.remove(token) }
}
