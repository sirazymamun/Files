package com.example.httpsserver

import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import java.net.URL
import java.util.concurrent.Executors

/** Native, remote-focusable setup; no root, ADB or router password collection. */
class PortForwardActivity : AppCompatActivity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("public_access", Context.MODE_PRIVATE) }
    private lateinit var publicIp: EditText
    private lateinit var externalPort: EditText
    private lateinit var output: TextView
    private var gateway: RouterForwarding.Gateway? = null
    private val actions = mutableListOf<Button>()
    private var working = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val panel = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(32,24,32,24) }
        setContentView(ScrollView(this).apply { addView(panel) })
        fun label(text:String) = TextView(this).apply { this.text=text;textSize=16f;setPadding(0,12,0,12);panel.addView(this) }
        fun button(text:String, action:()->Unit) {
            val b=Button(this).apply { this.text=text;isAllCaps=false;isFocusable=true;minHeight=64;setOnClickListener { if(!working) action() } }
            actions.add(b);panel.addView(b)
        }
        label("Public IP / Port forwarding").textSize=22f
        label("HTTPS TCP → this device:8443\nISP public static IPv4 প্রয়োজন। Static কিনা app নিশ্চিত করতে পারে না।")
        label("Public static IPv4 (ISP থেকে পাওয়া)")
        publicIp=EditText(this).apply { inputType=InputType.TYPE_CLASS_TEXT;setSingleLine();hint="Public IPv4";setText(prefs.getString("public_ip",""));panel.addView(this) }
        label("External TCP port (1–65535)")
        externalPort=EditText(this).apply { inputType=InputType.TYPE_CLASS_NUMBER;setSingleLine();setText(prefs.getInt("port",8443).toString());panel.addView(this) }
        output=label("Router এখনও পরীক্ষা করা হয়নি। Internet থেকে সংযোগ যাচাই হয়নি।")
        button("1. Find router / WAN IP") {
            task {
                val g=RouterForwarding.discover();val wan=RouterForwarding.externalIp(g)
                runOnUiThread { gateway=g }
                "Router: ${g.control.host}\nDevice LAN IP: ${g.client}\nRouter WAN IP: $wan\n"+
                    if(RouterForwarding.publicIPv4(wan)) "Public-looking IPv4; ISP-র দেওয়া IP-র সঙ্গে মিলিয়ে নিন। Static বা remote access যাচাই হয়নি।"
                    else "Private / shared / reserved WAN IP: upstream NAT বা CGNAT হতে পারে। ISP-কে public IPv4 দিতে বলুন।"
            }
        }
        button("2. Enable forwarding") {
            if(prefs.contains("control")) { output.text="আগের saved rule সরাতে Remove forwarding চাপুন। তারপর নতুন rule যোগ করুন।";return@button }
            val ip=publicIp.text.toString().trim()
            val port=readPort() ?: return@button
            if(!RouterForwarding.publicIPv4(ip)) { output.text="সঠিক public IPv4 লিখুন।";return@button }
            val g=gateway ?: run { output.text="প্রথমে Find router / WAN IP চাপুন।";return@button }
            if(!ServerService.running) { output.text="আগের screen থেকে server ON করুন।";return@button }
            AlertDialog.Builder(this).setTitle("Enable public file access?")
                .setMessage("TCP $port → ${g.client}:8443 rule তৈরি হবে। Password জানা remote user নির্বাচিত files ব্যবহার করতে পারবে। অন্য router rule পরিবর্তন হবে না। Rule server Stop-এর পরও থাকে; Remove forwarding দিয়ে মুছুন।")
                .setPositiveButton("Enable") { _,_-> task {
                    val wan=RouterForwarding.externalIp(g)
                    check(wan==ip && RouterForwarding.publicIPv4(wan)) { "Router WAN IP ও লেখা public IP মিলছে না। Manual guide দেখুন; CGNAT/double NAT পরীক্ষা করুন।" }
                    RouterForwarding.add(g,port,ServerService.PORT)
                    prefs.edit().putString("public_ip",ip).putInt("port",port)
                        .putInt("rule_port",port).putString("control",g.control.toString()).putString("service",g.service).putString("client",g.client).apply()
                    "Router rule verified: TCP $port → ${g.client}:8443\nhttps://$ip:$port\nInternet reachability এখনও যাচাই হয়নি। Mobile data/অন্য network থেকে পরীক্ষা করুন।"
                } }.setNegativeButton("Cancel",null).show()
        }
        button("Remove forwarding") {
            val control=prefs.getString("control",null)
            if(control==null) { output.text="এই app-এর saved rule নেই। Manual rule হলে router থেকে সরান।";return@button }
            val g=RouterForwarding.Gateway(URL(control),prefs.getString("service","")!!,prefs.getString("client","")!!)
            val port=prefs.getInt("rule_port",8443)
            task { RouterForwarding.remove(g,port,ServerService.PORT);prefs.edit().remove("control").remove("service").remove("client").remove("rule_port").apply();"Saved TV2U TCP $port rule removed. Server আলাদা Stop button দিয়ে বন্ধ করুন।" }
        }
        button("copy") {
            val ip=publicIp.text.toString().trim();val port=readPort() ?: return@button
            if(!RouterForwarding.publicIPv4(ip)) { output.text="সঠিক public IPv4 লিখুন।";return@button }
            prefs.edit().putString("public_ip",ip).putInt("port",port).apply()
            val text=ConnectionInfo.text("https://$ip:$port",Auth.password(this))
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("TV2U",text))
            Toast.makeText(this,"Copied address and password",Toast.LENGTH_SHORT).show()
        }
        button("Manual / Firewall guide (বাংলা)") { showGuide() }
        button("Back") { finish() }
        prefs.getString("control",null)?.let { output.text="Saved rule: TCP ${prefs.getInt("rule_port",8443)} → ${prefs.getString("client","")}:8443\nবর্তমান router state / Internet reachability যাচাই হয়নি। Rule সরাতে Remove forwarding চাপুন।" }
    }
    private fun readPort():Int? = try { RouterForwarding.port(externalPort.text.toString().trim()) } catch(e:Exception) { output.text=e.message;null }
    private fun task(job:()->String) {
        working=true;actions.forEach { it.isEnabled=false };output.text="Working…"
        worker.execute {
            val result=try { job() } catch(e:Exception) { "ব্যর্থ: ${e.message}\nManual / Firewall guide দেখুন।" }
            runOnUiThread { if(!isDestroyed) { working=false;actions.forEach { it.isEnabled=true };output.text=result } }
        }
    }
    private fun showGuide() {
        val port=readPort() ?: return
        val lan=gateway?.client ?: CertHelper.localIp() ?: "DEVICE_LAN_IP"
        val guide="""
১. ISP থেকে inbound connection-সহ public static IPv4 নিন। App IP বরাদ্দ করতে পারে না। Router WAN IP public IP-র সমান হতে হবে। 100.64–100.127, 10.x, 172.16–31.x, 192.168.x হলে CGNAT/double NAT পরীক্ষা করুন।

২. Router DHCP reservation-এ এই Android/Fire TV-র LAN IP $lan স্থির করুন। Public static IP ও LAN reservation আলাদা। Wi-Fi/ethernet বদলালে rule আবার মিলিয়ে নিন।

৩. Auto: router-এ UPnP চালু থাকলে Find router, তারপর Enable forwarding। সমর্থিত WANIP/WANPPP IGD router-এ কেবল এই TCP rule তৈরি হবে। UPnP unavailable হলে নিচের manual পদ্ধতি।

৪. Router → NAT / Virtual Server / Port Forwarding → Add:
Name: TV2U HTTPS
Protocol: TCP only
WAN external port: $port
LAN destination: $lan
Internal port: 8443
Enabled: Yes
Source: প্রয়োজনমতো trusted remote IP; যেকোনো IP থেকে দরকার হলে Any।

৫. Router-এ আলাদা WAN firewall থাকলে inbound TCP $port-এর DNAT traffic $lan:8443-তে allow দিন। Vendor অনুযায়ী firewall pre-NAT public port বা post-NAT internal port চায়; router guide মিলিয়ে নিন। Established/related return traffic allow থাকতে হবে। কোনো UDP WAN rule, DMZ, router remote-admin বা পুরো firewall বন্ধ করার প্রয়োজন নেই। UPnP discovery কেবল LAN UDP 1900; Internet-এ UDP 1900 forward করবেন না।

৬. Android/Fire TV: app-এ INTERNET permission আছে। Non-root app system/third-party firewall rule লিখতে পারে না। Firewall/VPN app block করলে তার UI-তে TV2U-র local incoming TCP 8443 allow দিন। Files permission আলাদা: আগের screen-এর Device storage access ব্যবহার করুন। Windows Firewall এই Android build-এ প্রযোজ্য নয়।

৭. Double NAT হলে upstream router-এও $port → inner-router WAN IP:$port rule লাগবে। ISP CGNAT হলে ISP public IP ছাড়া এই পদ্ধতি কাজ করবে না। Port conflict হলে অন্য external port দিন।

৮. Server ON রাখুন। অন্য network/mobile data থেকে https://PUBLIC_IP:$port খুলুন। একই Wi-Fi-তে NAT loopback না থাকলে public address ব্যর্থ হলেও LAN URL চলতে পারে। Router rule success মানেই Internet থেকে reachable নয়।

৯. HTTPS certificate-এ ব্যবহৃত hostname/IP থাকতে হবে। App-এর self-signed বা domain-only certificate public IP-তে browser warning দিতে পারে। Forwarding trusted certificate তৈরি/renew করে না। Domain certificate হলে DNS A record public IP-তে দিন এবং https://DOMAIN:$port ব্যবহার করুন; private key প্রকাশ করবেন না।

১০. Remove forwarding কেবল saved app rule-র client/port/description মিলে গেলে মুছে দেয়। Manual rule router থেকে সরাতে হবে। Stop permission ছাড়াই server বন্ধ করে; router rule মুছে না। Permanent UPnP rule router reboot/reset-এ হারাতে পারে; প্রয়োজন হলে আবার Enable করুন। App uninstall-এর আগে rule সরান।
        """.trimIndent()
        val text=TextView(this).apply { this.text=guide;textSize=16f;setPadding(24,16,24,16);setTextIsSelectable(true) }
        AlertDialog.Builder(this).setTitle("Port forwarding / Firewall (বাংলা)")
            .setView(ScrollView(this).apply { addView(text) }).setPositiveButton("Close",null).show()
    }
    override fun onDestroy() { worker.shutdown();super.onDestroy() }
}
