package com.example.httpsserver
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.ExecutorService
internal object PropertiesDialog {
 fun show(activity:Activity,root:File,file:File,worker:ExecutorService,includeHidden:Boolean=false){
  val text=TextView(activity).apply{text="Reading properties…";textSize=14f;setTextIsSelectable(true);setPadding(24,20,24,20)}
  var details="";var hashing=false
  val builder=AlertDialog.Builder(activity).setTitle("Properties").setView(ScrollView(activity).apply{addView(text)}).setPositiveButton("Close",null).setNeutralButton("Copy",null)
  if(file.isFile)builder.setNegativeButton("SHA-256",null)
  val dialog=builder.create();dialog.show()
  dialog.getButton(-3).setOnClickListener{(activity.getSystemService(Activity.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("File properties",details))}
  worker.execute{val result=runCatching{FileDetails.describe(root,file,includeHidden).entries.joinToString("\n\n"){"${it.key}\n${it.value}"}};activity.runOnUiThread{details=result.getOrElse{it.message ?: "Unavailable"};if(dialog.isShowing)text.text=details}}
  if(file.isFile)dialog.getButton(-2).setOnClickListener{if(!hashing){hashing=true;dialog.getButton(-2).isEnabled=false;text.text="Calculating SHA-256…";worker.execute{val hash=runCatching{FileManagerOps(root,includeHidden).checked(file);val before=file.length() to file.lastModified();val result=FileDetails.sha256(file);check(before==(file.length() to file.lastModified())){"File changed during hashing"};result}.getOrElse{it.message ?: "Unavailable"};activity.runOnUiThread{details+="\n\nSHA-256\n$hash";if(dialog.isShowing)text.text=details}}}}
 }
}
