package com.example.httpsserver

import android.content.Context
import android.util.Base64
import java.net.InetAddress
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec

object Provisioner {
    const val DOMAIN = "tv2u-server.netcolink.com"

    fun domain(ctx: Context): String = prefs(ctx).getString("server_domain", DOMAIN) ?: DOMAIN

    fun saveDomain(ctx: Context, value: String) {
        val normalized = ServerDomain.normalize(value)
        check(prefs(ctx).edit().putString("server_domain", normalized).commit()) { "Could not save domain" }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("tv2u", Context.MODE_PRIVATE)

    fun creds(ctx: Context): AcmeDns.Creds? {
        val p = prefs(ctx)
        if ((p.getString("dns_domain", DOMAIN) ?: DOMAIN) != domain(ctx)) return null
        val user = p.getString("dns_user", null) ?: return null
        return AcmeDns.Creds(user, p.getString("dns_pass", "") ?: "", p.getString("dns_sub", "") ?: "", p.getString("dns_full", "") ?: "")
    }

    fun register(ctx: Context): AcmeDns.Creds {
        val selectedDomain = domain(ctx)
        val c = AcmeDns.register()
        check(domain(ctx) == selectedDomain) { "Domain changed; retry DNS setup" }
        prefs(ctx).edit()
            .putString("dns_domain", selectedDomain)
            .putString("dns_user", c.user).putString("dns_pass", c.pass)
            .putString("dns_sub", c.sub).putString("dns_full", c.full)
            .apply()
        return c
    }

    fun instructions(ctx: Context, c: AcmeDns.Creds): String {
        val selectedDomain = domain(ctx)
        val ip = CertHelper.localIp() ?: "<phone IP>"
        return "Add these 2 records at your authoritative DNS provider (DirectAdmin > DNS Management / DNS Zone):\n\n" +
            "1) A record\nName: $selectedDomain.\nAddress: $ip\n\n" +
            "2) CNAME record\nName: _acme-challenge.$selectedDomain.\nCNAME: ${c.full.trimEnd('.')}.\n\n" +
            "Reserve this IP for the phone in your router so the A record stays correct."
    }

    fun provision(ctx: Context, log: (String) -> Unit) {
        val selectedDomain = domain(ctx)
        val c = creds(ctx) ?: register(ctx)
        val p = prefs(ctx)
        val kf = KeyFactory.getInstance("RSA")
        val priv = p.getString("acct_priv", null)
        val pub = p.getString("acct_pub", null)
        val kp: KeyPair = if (priv != null && pub != null) {
            KeyPair(
                kf.generatePublic(X509EncodedKeySpec(Base64.decode(pub, Base64.NO_WRAP))),
                kf.generatePrivate(PKCS8EncodedKeySpec(Base64.decode(priv, Base64.NO_WRAP)))
            )
        } else {
            val fresh = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            p.edit()
                .putString("acct_priv", Base64.encodeToString(fresh.private.encoded, Base64.NO_WRAP))
                .putString("acct_pub", Base64.encodeToString(fresh.public.encoded, Base64.NO_WRAP))
                .apply()
            fresh
        }
        val client = AcmeClient(kp, p.getString("acct_kid", null), log)
        val (key, chain) = client.obtainCertificate(selectedDomain) { txt ->
            log("Publishing DNS challenge…")
            AcmeDns.update(c, txt)
        }
        client.kid?.let { p.edit().putString("acct_kid", it).apply() }
        check(domain(ctx) == selectedDomain) { "Domain changed; retry certificate setup" }
        CertHelper.saveDomainCert(ctx, key, chain)
    }

    fun dnsHint(ctx: Context): String {
        val selectedDomain = domain(ctx)
        return try {
            "$selectedDomain resolves to ${InetAddress.getByName(selectedDomain).hostAddress} (phone: ${CertHelper.localIp()})"
        } catch (e: Exception) {
            "$selectedDomain doesn't resolve yet (phone: ${CertHelper.localIp()})"
        }
    }
}
