package com.example.httpsserver;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

/** UPnP IGD IPv4 TCP only. No router credentials, DMZ, or unrelated rule changes. */
public final class RouterForwarding {
    public static final String DESCRIPTION = "TV2U HTTPS";
    public static final class Gateway {
        public final URL control;
        public final String service, client;
        public Gateway(URL control, String service, String client) {
            this.control = control; this.service = service; this.client = client;
        }
    }
    public static int port(String value) {
        if (!value.matches("[0-9]{1,5}")) throw new IllegalArgumentException("Port must be 1–65535");
        int p = Integer.parseInt(value);
        if (p < 1 || p > 65535) throw new IllegalArgumentException("Port must be 1–65535");
        return p;
    }
    public static boolean publicIPv4(String ip) {
        if (ip == null || !ip.matches("[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+")) return false;
        String[] bits=ip.split("\\."); int[] b=new int[4];
        for(int i=0;i<4;i++) { if(bits[i].length()>3) return false; b[i]=Integer.parseInt(bits[i]); if(b[i]>255) return false; }
        return !(b[0]==0 || b[0]==10 || b[0]==127 || b[0]>=224 ||
            (b[0]==100 && b[1]>=64 && b[1]<=127) || (b[0]==169 && b[1]==254) ||
            (b[0]==172 && b[1]>=16 && b[1]<=31) || (b[0]==192 && b[1]==168) ||
            (b[0]==192 && b[1]==0) || (b[0]==198 && (b[1]==18 || b[1]==19)) ||
            (b[0]==198 && b[1]==51 && b[2]==100) || (b[0]==203 && b[1]==0 && b[2]==113));
    }
    private static void local(URL url) throws Exception {
        if (!url.getProtocol().equals("http") || url.getUserInfo()!=null) throw new IOException("Invalid local router URL");
        InetAddress a=InetAddress.getByName(url.getHost());
        if (!(a instanceof Inet4Address) || !(a.isSiteLocalAddress() || a.isLoopbackAddress()))
            throw new IOException("Router URL must be a local IPv4 address");
        // Require literal IPv4 to prevent DNS rebinding between validation and request.
        if (!url.getHost().matches("[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+")) throw new IOException("Router URL must use its LAN IP");
    }
    private static String request(URL url, String action, String body) throws Exception {
        local(url);
        HttpURLConnection c=(HttpURLConnection)url.openConnection(Proxy.NO_PROXY);
        c.setConnectTimeout(4000);c.setReadTimeout(4000);c.setInstanceFollowRedirects(false);
        try {
            if(action!=null) {
                c.setRequestMethod("POST");c.setDoOutput(true);
                c.setRequestProperty("Content-Type","text/xml; charset=\"utf-8\"");
                c.setRequestProperty("SOAPAction","\""+action+"\"");
                byte[] data=body.getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(data.length);
                try(OutputStream o=c.getOutputStream()){o.write(data);}
            }
            int status=c.getResponseCode();
            InputStream stream=status>=400?c.getErrorStream():c.getInputStream();
            if(stream==null) throw new IOException("Router HTTP "+status);
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            try(InputStream in=stream){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(out.size()+n>262144)throw new IOException("Router reply too large");out.write(b,0,n);}}
            String text=out.toString("UTF-8");
            if(status<200 || status>=300) {
                String code="";try{code=value(xml(text),"errorCode");}catch(Exception ignored){}
                throw new IOException("Router rejected request (HTTP "+status+", UPnP "+code+"). Use manual setup; existing rules are not replaced.");
            }
            return text;
        } finally {c.disconnect();}
    }
    static Document xml(String text) throws Exception {
        if(text.toUpperCase(Locale.ROOT).contains("<!DOCTYPE") || text.toUpperCase(Locale.ROOT).contains("<!ENTITY")) throw new IOException("Unsafe router XML");
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);f.setExpandEntityReferences(false);
        return f.newDocumentBuilder().parse(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));
    }
    static String value(Node root,String name) {
        if(root instanceof Document)root=((Document)root).getDocumentElement();
        if(name.equals(root.getLocalName()) || name.equals(root.getNodeName()))return root.getTextContent().trim();
        NodeList list=root.getChildNodes();for(int i=0;i<list.getLength();i++){String v=value(list.item(i),name);if(!v.isEmpty())return v;}return "";
    }
    public static Gateway discover() throws Exception {
        Set<String> locations=new LinkedHashSet<>();
        try(DatagramSocket s=new DatagramSocket()) {
            s.setSoTimeout(900);
            for(String type:new String[]{"urn:schemas-upnp-org:device:InternetGatewayDevice:1","urn:schemas-upnp-org:service:WANIPConnection:1","urn:schemas-upnp-org:service:WANPPPConnection:1"}) {
                byte[] q=("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: "+type+"\r\n\r\n").getBytes(StandardCharsets.US_ASCII);
                s.send(new DatagramPacket(q,q.length,InetAddress.getByName("239.255.255.250"),1900));
            }
            long end=System.currentTimeMillis()+3500;
            while(System.currentTimeMillis()<end && locations.size()<8)try {
                byte[] b=new byte[8192];DatagramPacket p=new DatagramPacket(b,b.length);s.receive(p);
                for(String line:new String(b,0,p.getLength(),StandardCharsets.UTF_8).split("\r?\n"))
                    if(line.toLowerCase(Locale.ROOT).startsWith("location:"))locations.add(line.substring(9).trim());
            }catch(SocketTimeoutException ignored){}
        }
        for(String location:locations)try {
            URL base=new URL(location);local(base);
            Document d=xml(request(base,null,null));String ub=value(d,"URLBase");if(!ub.isEmpty()){base=new URL(ub);local(base);}
            NodeList services=d.getElementsByTagNameNS("*","service");
            for(int i=0;i<services.getLength();i++) {
                Node n=services.item(i);String type=value(n,"serviceType");
                if(!type.matches("urn:schemas-upnp-org:service:WAN(IP|PPP)Connection:[12]"))continue;
                URL control=new URL(base,value(n,"controlURL"));local(control);
                String client;
                try(DatagramSocket route=new DatagramSocket()){route.connect(InetAddress.getByName(control.getHost()),1900);client=route.getLocalAddress().getHostAddress();}
                Gateway g=new Gateway(control,type,client);externalIp(g);return g;
            }
        }catch(Exception ignored){}
        throw new IOException("No supported UPnP router found. Enable UPnP on your router or use Manual / Firewall guide.");
    }
    static String soap(Gateway g,String action,String args) throws Exception {
        if(!g.service.matches("urn:schemas-upnp-org:service:WAN(IP|PPP)Connection:[12]"))throw new IOException("Unsupported router service");
        String body="<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:"+action+" xmlns:u=\""+g.service+"\">"+args+"</u:"+action+"></s:Body></s:Envelope>";
        return request(g.control,g.service+"#"+action,body);
    }
    public static String externalIp(Gateway g) throws Exception {return value(xml(soap(g,"GetExternalIPAddress","")),"NewExternalIPAddress");}
    private static String key(int port){port(Integer.toString(port));return "<NewRemoteHost></NewRemoteHost><NewExternalPort>"+port+"</NewExternalPort><NewProtocol>TCP</NewProtocol>";}
    public static void add(Gateway g,int external,int internal) throws Exception {
        port(Integer.toString(internal));
        if(!g.client.matches("[0-9.]+"))throw new IOException("Invalid device IP");
        // Never overwrite any existing mapping, even one with the same description.
        try {soap(g,"GetSpecificPortMappingEntry",key(external));throw new IOException("This external port already has a rule. Remove it or choose another port.");}
        catch(IOException e){if(!e.getMessage().contains("UPnP 714"))throw e;}
        soap(g,"AddPortMapping",key(external)+"<NewInternalPort>"+internal+"</NewInternalPort><NewInternalClient>"+g.client+"</NewInternalClient><NewEnabled>1</NewEnabled><NewPortMappingDescription>"+DESCRIPTION+"</NewPortMappingDescription><NewLeaseDuration>0</NewLeaseDuration>");
        try { verify(g,external,internal); } catch(Exception e) { throw new IOException("Rule may have been created but verification failed. Check TV2U HTTPS in your router before retrying. "+e.getMessage(),e); }
    }
    private static void verify(Gateway g,int external,int internal) throws Exception {
        Document d=xml(soap(g,"GetSpecificPortMappingEntry",key(external)));
        if(!g.client.equals(value(d,"NewInternalClient")) || !Integer.toString(internal).equals(value(d,"NewInternalPort")) || !DESCRIPTION.equals(value(d,"NewPortMappingDescription")))
            throw new IOException("Rule ownership could not be verified. Check router manually.");
    }
    public static void remove(Gateway g,int external,int internal) throws Exception {
        verify(g,external,internal);soap(g,"DeletePortMapping",key(external));
    }
}
