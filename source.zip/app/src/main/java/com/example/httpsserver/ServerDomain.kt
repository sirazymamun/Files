package com.example.httpsserver

import java.net.IDN

internal object ServerDomain {
    fun normalize(input: String): String {
        val value = IDN.toASCII(input.trim().removeSuffix("."), IDN.USE_STD3_ASCII_RULES).lowercase()
        require(value.length <= 253 && value.contains('.') && !value.matches(Regex("[0-9.]+"))) { "Enter a domain name without https://, IP, port or path" }
        require(value.split('.').all { it.length in 1..63 && it.first().isLetterOrDigit() && it.last().isLetterOrDigit() && it.all { ch -> ch in 'a'..'z' || ch in '0'..'9' || ch == '-' } }) { "Invalid domain name" }
        return value
    }

    fun matchesName(domain: String, certificateName: String): Boolean {
        val name = certificateName.lowercase().removeSuffix(".")
        val host = domain.lowercase().removeSuffix(".")
        if (!name.startsWith("*.")) return host == name
        val suffix = name.substring(2)
        val prefix = host.removeSuffix(".$suffix")
        return host.endsWith(".$suffix") && prefix.isNotEmpty() && !prefix.contains('.')
    }
}
