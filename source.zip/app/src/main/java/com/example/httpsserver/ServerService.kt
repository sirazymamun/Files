package com.example.httpsserver

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import fi.iki.elonen.NanoHTTPD
import java.util.concurrent.Executors

class ServerService : Service() {
    private var server: HttpsServer? = null
    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var generation = 0
    private val permissionCheck = object : Runnable {
        override fun run() {
            if (!StorageDecision.canContinue(StorageAccess.hasFullAccess(this@ServerService))) {
                finishServer("File permission was removed. Server stopped.")
            } else if (running || starting) main.postDelayed(this, 1000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { finishServer("Server stopped"); return START_NOT_STICKY }
        if (running || starting) { announce(); return START_NOT_STICKY }
        // A system restart without the user's START action must not reopen file sharing.
        if (intent?.action != ACTION_START) { finishServer("Server off"); return START_NOT_STICKY }
        if (!StorageDecision.canStart(StorageAccess.hasFullAccess(this))) {
            finishServer("Grant device storage access in Android / Fire OS settings.")
            return START_NOT_STICKY
        }
        val folder = try { StorageAccess.root(this) } catch (e: Exception) {
            finishServer(e.message ?: "Storage is unavailable"); return START_NOT_STICKY
        }
        val token = synchronized(lock) { ++generation }
        starting = true
        lastMessage = "Starting server..."
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                nm.createNotificationChannel(NotificationChannel("srv", "Server", NotificationManager.IMPORTANCE_LOW))
            val notif = NotificationCompat.Builder(this, "srv")
                .setContentTitle("Files · Server")
                .setContentText("Device shared storage")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setOngoing(true).build()
            startForeground(1, notif)
        } catch (e: Exception) {
            finishServer("Could not start the server notification."); return START_NOT_STICKY
        }
        announce()
        main.removeCallbacks(permissionCheck)
        main.postDelayed(permissionCheck, 1000)
        worker.execute {
            var candidate: HttpsServer? = null
            try {
                // Key/certificate generation is off the UI thread, so STOP stays responsive.
                val ks = CertHelper.loadOrCreate(this)
                candidate = HttpsServer(PORT, applicationContext, folder, true).apply {
                    makeSecure(NanoHTTPD.makeSSLSocketFactory(ks, CertHelper.keyManagerFactory(ks)), null)
                }
                val current = candidate
                synchronized(lock) {
                    if (token != generation) { current.stop(); return@execute }
                    check(StorageDecision.canStart(StorageAccess.hasFullAccess(this))) { "File access was removed" }
                    current.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                    server = current
                    running = true
                    starting = false
                    lastMessage = "Device shared storage"
                }
                main.post { if (token == generation) announce() }
            } catch (e: Exception) {
                candidate?.stop()
                main.post { if (token == generation) finishServer(e.message ?: "The server could not start") }
            }
        }
        return START_NOT_STICKY
    }

    private fun announce() {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName))
    }

    private fun stopResources(message: String) {
        main.removeCallbacks(permissionCheck)
        synchronized(lock) {
            generation++
            server?.stop()
            server = null
            running = false
            starting = false
            lastMessage = message
        }
        announce()
    }

    private fun finishServer(message: String) {
        stopResources(message)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopResources(if (lastMessage.isBlank()) "Server off" else lastMessage)
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null

    companion object {
        const val PORT = 8443
        const val ACTION_START = "com.example.httpsserver.START"
        const val ACTION_STOP = "com.example.httpsserver.STOP"
        const val ACTION_STATE = "com.example.httpsserver.STATE"
        @Volatile var running = false
        @Volatile var starting = false
        @Volatile var lastMessage = ""
    }
}
