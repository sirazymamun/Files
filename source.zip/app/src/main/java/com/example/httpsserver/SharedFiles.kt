package com.example.httpsserver

import java.io.File
import java.util.Locale

/** One shared policy for listing, preview, download and every write operation. */
internal class SharedFiles(private val base: File,private val includeHidden:Boolean=false) {
    private val root get() = base.canonicalFile
    private val blocked = setOf("android", "lost.dir", "system volume information", "$" + "recycle.bin", "desktop.ini", "thumbs.db", "thumbcache.db")

    fun allowedPart(name: String): Boolean =
        name.isNotEmpty() && (includeHidden || !name.startsWith(".")) && name!="." && name!=".." && name.lowercase(Locale.ROOT)!=".filestrash" && name.lowercase(Locale.ROOT) !in blocked &&
            name.none { it == '\\' || it.code < 32 || it.code == 127 }

    // Archive payloads may contain ordinary dotfiles such as .github/.gitignore.
    // This does not make them visible or directly accessible through the browser.
    // Archive *entries* are data, not paths chosen by the file browser. ZIPs created on
    // Windows often contain desktop.ini/Thumbs.db, and ordinary packages may have
    // an Android/ or LOST.DIR/ folder under their own extraction directory.
    // Restrict protected real storage locations separately at the destination root.
    fun allowedArchivePart(name: String): Boolean = name.isNotBlank() && name != "." && name != ".." &&
        name.lowercase(Locale.ROOT) != ".filestrash" &&
        name.none { it == '/' || it == '\\' || it == ':' || it.code < 32 || it.code == 127 }

    fun segments(path: String): List<String>? {
        val parts = path.split('/').filter { it.isNotEmpty() }
        // Android/media is public shared media, unlike Android/data and Android/obb.
        val sharedMedia=parts.size>=2 && parts[0].equals("Android",true) && parts[1].equals("media",true)
        return if ((if(sharedMedia)parts.drop(2)else parts).all(::allowedPart)) parts else null
    }

    /** Hide only directories proven to have no visible immediate file/subfolder. */
    fun visibleInListing(file: File): Boolean {
        if (!allowedPart(file.name) || resolve(file.path.removePrefix(root.path)) == null) return false
        if (file.isFile) return true // Zero-byte files are still real content.
        if (!file.isDirectory) return false
        val children = file.list() ?: return true // Unknown/unreadable is not the same as empty.
        return children.any { name ->
            if (!allowedPart(name)) false else {
                val child = File(file, name)
                (child.isFile || child.isDirectory) && resolve(child.path.removePrefix(root.path)) != null
            }
        }
    }

    fun validName(name: String) = name.isNotBlank() && name.length <= 200 && '/' !in name && allowedPart(name)

    fun resolve(path: String): File? {
        val r = root
        var file = r
        for (part in segments(path) ?: return null) file = File(file, part)
        val canonical = file.canonicalFile
        if (canonical != r && !canonical.path.startsWith(r.path + File.separator)) return null
        return if (segments(canonical.path.removePrefix(r.path)) != null) canonical else null
    }
}
