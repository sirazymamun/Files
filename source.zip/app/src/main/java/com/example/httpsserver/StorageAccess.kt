package com.example.httpsserver

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import androidx.core.content.ContextCompat
import java.io.File
import java.security.MessageDigest

internal object StorageAccess {

    fun hasFullAccess(ctx: Context): Boolean = try {
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    } catch (_: RuntimeException) { false }

    fun root(ctx: Context): File {
        check(hasFullAccess(ctx)) { "Device storage permission has not been granted by Android / Fire OS" }
        val folder = Environment.getExternalStorageDirectory().canonicalFile
        check(folder.isDirectory && folder.canRead() && folder.listFiles() != null) {
            "Permission is granted, but this device still denied listing its shared storage"
        }
        return folder
    }

    fun volumes(ctx: Context): List<StorageVolumeRoot> {
        val primary = root(ctx)
        val result = mutableListOf(StorageVolumeRoot("primary", "Internal shared storage", primary))
        fun add(folder: File, description: String) {
            val canonical = folder.canonicalFile
            if (result.none { it.folder == canonical } && canonical.isDirectory && canonical.canRead())
                result.add(StorageVolumeRoot("volume-" + MessageDigest.getInstance("SHA-256").digest(canonical.path.toByteArray(Charsets.UTF_8)).take(8).joinToString("") { "%02x".format(it.toInt() and 255) }, description, canonical))
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val manager = ctx.getSystemService(StorageManager::class.java)
            for (volume in manager.storageVolumes) {
                if (volume.state != Environment.MEDIA_MOUNTED && volume.state != Environment.MEDIA_MOUNTED_READ_ONLY) continue
                runCatching { volume.directory?.let { add(it, volume.getDescription(ctx)) } }
            }
        } else {
            // API 24–29: only derive roots from the platform-returned app-files suffix.
            val suffix = "/Android/data/${ctx.packageName}/files"
            for (directory in ctx.getExternalFilesDirs(null).filterNotNull()) {
                val path = directory.absolutePath
                if (path.endsWith(suffix)) runCatching { add(File(path.removeSuffix(suffix)), "SD / USB storage") }
            }
        }
        return result
    }
}
