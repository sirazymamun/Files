package com.example.httpsserver

/** Device shared storage always requires its real OS permission. No private-folder fallback. */
internal object StorageDecision {
    fun canStart(fullAccess: Boolean): Boolean = fullAccess
    fun canContinue(fullAccess: Boolean): Boolean = fullAccess
}
