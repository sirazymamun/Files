package com.example.httpsserver

import java.io.File
import java.io.IOException
import java.util.Properties
import java.util.UUID

/** Same-volume, recoverable deletion. Bin storage is never shared by the HTTP server. */
internal class TrashStore(private val root:File,private val includeHidden:Boolean=false){
 data class Entry(val id:String,val original:String,val deletedAt:Long,val folder:Boolean)
 private val bin get()=File(root,".FilesTrash")
 private fun safeBin():File {require(root.isDirectory);require(bin.canonicalPath==bin.absolutePath){"Recycle Bin is a link"};if(!bin.exists())check(bin.mkdir()){"Cannot create Recycle Bin"};return bin}
 private fun bucket(id:String):File {require(runCatching{UUID.fromString(id).toString()==id}.getOrDefault(false));val f=File(safeBin(),id);require(f.canonicalPath==f.absolutePath);return f}
 fun put(source:File):Entry {
  val ops=FileManagerOps(root,includeHidden);ops.checked(source);require(source.isFile || source.isDirectory){"Item unavailable"}
  // Rename the whole folder without following children. Hidden metadata is preserved too.
  val entry=Entry(UUID.randomUUID().toString(),source.path.removePrefix(root.canonicalPath),System.currentTimeMillis(),source.isDirectory);val dir=bucket(entry.id);check(dir.mkdir())
  try{val p=Properties();p.setProperty("original",entry.original);p.setProperty("deletedAt",entry.deletedAt.toString());p.setProperty("folder",entry.folder.toString());File(dir,"record.properties").outputStream().use{p.store(it,"Files Recycle Bin")};check(source.renameTo(File(dir,"payload"))){"Cannot move item to Recycle Bin"};return entry}catch(e:Exception){File(dir,"record.properties").delete();dir.delete();throw e}
 }
 fun entries():List<Entry>{if(!bin.exists())return emptyList();return safeBin().listFiles()?.mapNotNull{folder->runCatching{val dir=bucket(folder.name);val p=Properties();File(dir,"record.properties").inputStream().use{p.load(it)};val original=p.getProperty("original");require(SharedFiles(root,includeHidden).resolve(original)!=null && original.isNotBlank());require(File(dir,"payload").exists());Entry(folder.name,original,p.getProperty("deletedAt").toLong(),p.getProperty("folder").toBoolean())}.getOrNull()}?.sortedByDescending{it.deletedAt} ?: emptyList()}
 fun restore(entry:Entry):File {
  val dir=bucket(entry.id);val payload=File(dir,"payload");require(payload.exists() && payload.canonicalPath==payload.absolutePath);val ops=FileManagerOps(root,includeHidden)
  val intended=SharedFiles(root,includeHidden).resolve(entry.original) ?: error("Original path is protected");ops.checked(intended)
  val parent=intended.parentFile!!;var ancestor=root.canonicalFile
  val parts=parent.path.removePrefix(root.canonicalPath).split('/').filter{it.isNotEmpty()};val sharedMedia=parts.size>=2 && parts[0].equals("Android",true) && parts[1].equals("media",true)
  if(sharedMedia){ancestor=File(root,parts.take(2).joinToString("/"));ops.checked(ancestor);require(ancestor.isDirectory){"Original shared media location is unavailable"}}
  for(part in (if(sharedMedia)parts.drop(2)else parts)){ancestor=ops.child(ancestor,part);if(!ancestor.exists())check(ancestor.mkdir()){"Cannot recreate original folder"};require(ancestor.isDirectory)}
  var target=intended;var i=1;while(target.exists()){target=ops.child(parent,intended.nameWithoutExtension+" (restored ${i++})"+if(intended.isFile && intended.extension.isNotEmpty())".${intended.extension}" else  "")}
  check(payload.renameTo(target)){"Restore failed; item remains in Bin"};File(dir,"record.properties").delete();dir.delete();return target
 }
 fun purge(entry:Entry){
  val dir=bucket(entry.id);require(dir.isDirectory);val plan=mutableListOf<File>();val start=System.nanoTime()
  fun walk(file:File,depth:Int){
   check(depth<=128 && plan.size<100000 && System.nanoTime()-start<20000000000L){"Bin item too large to remove"}
   require(file==dir || file.absolutePath.startsWith(dir.absolutePath+File.separator)){"Unsafe Bin path"}
   // A link is unlinked itself; its target is never visited.
   if(file.canonicalPath==file.absolutePath && file.isDirectory)(file.listFiles() ?: throw IOException("Cannot read Bin item")).forEach{walk(it,depth+1)}
   plan.add(file)
  }
  walk(dir,0);for(file in plan){require(file.parentFile!!.canonicalPath==file.parentFile!!.absolutePath){"Bin parent changed"};check(file.delete()){"Cannot permanently remove ${file.name}"}}
 }
}
