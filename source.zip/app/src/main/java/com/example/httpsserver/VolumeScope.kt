package com.example.httpsserver

import java.io.File

internal data class StorageVolumeRoot(val id: String, val name: String, val folder: File)

/** Storage is request-local, never a global browser-selected directory. */
internal class VolumeScope(val volumes: List<StorageVolumeRoot>) {
    init { require(volumes.isNotEmpty() && volumes.map { it.id }.distinct().size == volumes.size) }
    private val active = ThreadLocal<StorageVolumeRoot>()
    val current: StorageVolumeRoot get() = active.get() ?: volumes.first()
    fun select(id: String): StorageVolumeRoot? {
        active.remove()
        return volumes.firstOrNull { it.id == id }?.also { active.set(it) }
    }
    fun clear() { active.remove() }
}
