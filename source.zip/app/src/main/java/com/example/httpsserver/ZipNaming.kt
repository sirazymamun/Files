package com.example.httpsserver

/** Name a new ZIP after the current directory without changing its contents. */
internal object ZipNaming {
    fun suggest(folderName:String):String = ensureExtension(folderName.ifBlank { "Files" })
    fun ensureExtension(raw:String):String {
        val cleaned=raw.trim()
        require(cleaned.isNotBlank() && cleaned != "." && cleaned != ".." && !cleaned.contains('/') && !cleaned.contains('\\') && !cleaned.contains('\u0000')) { "Invalid ZIP name" }
        return if(cleaned.endsWith(".zip",ignoreCase=true)) cleaned else "$cleaned.zip"
    }
    fun alternative(name:String):String = ensureExtension(ensureExtension(name).dropLast(4) + " (1)")
}
