package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files
class ApkBackupTest{
 private fun run(block:(File,File)->Unit){val root=Files.createTempDirectory("apps-backup-test").toFile();val out=File(root,"backups").apply{mkdir()};try{block(root,out)}finally{Thread.interrupted();root.deleteRecursively()}}
 private fun snapshot(vararg files:File)=ApkBackup.Snapshot("test.player","Sample Player","1.2.3",123,files.map{ApkBackup.Source(it)})
 @Test fun singleApkIsExactAndNeverOverwrites()=run{r,out->val file=File(r,"base.apk").apply{writeBytes(ByteArray(9000){(it%251).toByte()})};val first=ApkBackup.write(snapshot(file),out);val second=ApkBackup.write(snapshot(file),out);assertEquals("apk",first.extension);assertNotEquals(first,second);assertArrayEquals(file.readBytes(),first.readBytes());assertArrayEquals(file.readBytes(),second.readBytes())}
 @Test fun allSplitsAndMetadataArePreserved()=run{r,out->
  val base=File(r,"base.apk").apply{writeText("BASE")};val a=File(r,"config.en.apk").apply{writeText("ENGLISH")};val b=File(r,"config.arm.apk").apply{writeText("ARM")}
  val backup=ApkBackup.write(snapshot(base,a,b),out);assertTrue(backup.isDirectory);val parts=ApkBackup.apkFiles(backup);assertEquals(3,parts.size);assertEquals(setOf("BASE","ENGLISH","ARM"),parts.map{it.readText()}.toSet());assertTrue(parts.all{it.extension=="apk"});assertTrue(File(backup,"backup.properties").readText().contains("apkCount=3"))
  val again=ApkBackup.write(snapshot(base,a,b),out);assertNotEquals(backup,again);assertEquals(3,ApkBackup.apkFiles(again).size);assertEquals(3,ApkBackup.apkFiles(backup).size)
 }
 @Test fun missingSplitRefusesIncompleteExport()=run{r,out->val base=File(r,"base.apk").apply{writeText("BASE")};assertThrows(IllegalStateException::class.java){ApkBackup.write(snapshot(base,File(r,"missing.apk")),out)};assertEquals(0,out.listFiles()!!.size)}
 @Test fun changedSnapshotIsRejected()=run{r,out->val base=File(r,"base.apk").apply{writeText("OLD")};val item=snapshot(base);base.writeText("new changed apk");assertThrows(IllegalStateException::class.java){ApkBackup.write(item,out)};assertEquals(0,out.listFiles()!!.size)}
 @Test fun labelCannotEscapeDestination()=run{r,out->val base=File(r,"base.apk").apply{writeText("BASE")};val item=snapshot(base).copy(label="../../bad\\name",version="../../v1");val output=ApkBackup.write(item,out);assertEquals(out,output.parentFile);assertFalse(output.name.contains('/'));assertFalse(output.name.startsWith('.'))}
 @Test fun interruptedExportLeavesNoPartialPackage()=run{r,out->val base=File(r,"base.apk").apply{writeBytes(ByteArray(1024))};Thread.currentThread().interrupt();assertThrows(java.io.IOException::class.java){ApkBackup.write(snapshot(base),out)};Thread.interrupted();assertEquals(0,out.listFiles()!!.size)}
 @Test fun androidCacheAliasCanExportSingleAndSplitPackages()=run{r,_->
  val realCache=File(r,"user0/cache").apply{mkdirs()};val alias=File(r,"data-data-cache");Files.createSymbolicLink(alias.toPath(),realCache.toPath())
  val out=ApkBackup.shareDirectory(alias);assertTrue(out.path.startsWith(realCache.canonicalPath+"/app-shares/"));assertEquals(out.canonicalFile,out.absoluteFile)
  val base=File(r,"base.apk").apply{writeText("BASE")};val split=File(r,"split.apk").apply{writeText("SPLIT")}
  assertEquals("BASE",ApkBackup.write(snapshot(base),out).readText());assertEquals(setOf("BASE","SPLIT"),ApkBackup.apkFiles(ApkBackup.write(snapshot(base,split),out)).map{it.readText()}.toSet())
 }
 @Test fun linksInsideCacheCannotRedirectExport()=run{r,_->
  val cache=File(r,"cache").apply{mkdir()};val outside=File(r,"outside").apply{mkdir()};Files.createSymbolicLink(File(cache,"app-shares").toPath(),outside.toPath())
  assertThrows(IllegalArgumentException::class.java){ApkBackup.shareDirectory(cache)};assertEquals(0,outside.list()!!.size)
  assertThrows(IllegalArgumentException::class.java){ApkBackup.write(snapshot(File(r,"base.apk").apply{writeText("APK")}),File(cache,"app-shares"))}
 }
 @Test fun interruptedSplitExportLeavesNoPartialFolder()=run{r,out->val base=File(r,"base.apk").apply{writeBytes(ByteArray(1024))};val split=File(r,"split.apk").apply{writeText("SPLIT")};Thread.currentThread().interrupt();assertThrows(java.io.IOException::class.java){ApkBackup.write(snapshot(base,split),out)};Thread.interrupted();assertEquals(0,out.listFiles()!!.size)}
}
