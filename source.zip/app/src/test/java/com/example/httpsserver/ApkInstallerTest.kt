package com.example.httpsserver
import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
import java.io.File
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24,34],shadows=[GrantedStorageEnvironment::class])
class ApkInstallerTest{
 @org.junit.Before @org.junit.After fun clearProviderCache(){
  // Robolectric gives each test a different storage root; AndroidX caches roots statically.
  val field=androidx.core.content.FileProvider::class.java.getDeclaredField("sCache").apply{isAccessible=true}
  (field.get(null) as MutableMap<*,*>).clear()
 }

 private fun fixture(block:(File,File)->Unit){val root=Environment.getExternalStorageDirectory().apply{mkdirs()};val folder=File(root,"InstallerTest").apply{mkdirs()};val apk=File(folder,"sample.APK").apply{writeText("test package data")};val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);try{block(root,apk)}finally{folder.deleteRecursively()}}
 private fun intent(root:File,file:File)=Intent(RuntimeEnvironment.getApplication(),ApkInstallerActivity::class.java).putExtra("root",root.path).putExtra("file",file.path)
 @Test fun apkDelegatesToSystemWithMimeAndReadOnlyGrant()=fixture{root,apk->
  shadowOf(RuntimeEnvironment.getApplication().packageManager).setCanRequestPackageInstalls(true)
  val c=Robolectric.buildActivity(ApkInstallerActivity::class.java,intent(root,apk)).setup();try{val started=shadowOf(c.get()).nextStartedActivityForResult.intent;assertEquals(Intent.ACTION_VIEW,started.action);assertEquals("application/vnd.android.package-archive",started.type);assertEquals("content",started.data!!.scheme);assertTrue(started.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION!=0);assertEquals(0,started.flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION);assertEquals(started.data,started.clipData!!.getItemAt(0).uri);assertEquals(ApkInstallerActivity.APK_MIME,FileDetails.mime(apk))}finally{c.pause().stop().destroy()}
 }
 @Test @Config(sdk=[34]) fun permissionSettingsReturnResumesRequestedApk()=fixture{root,apk->
  val pm=shadowOf(RuntimeEnvironment.getApplication().packageManager);pm.setCanRequestPackageInstalls(false)
  val c=Robolectric.buildActivity(ApkInstallerActivity::class.java,intent(root,apk)).setup();try{val a=c.get();assertNull(shadowOf(a).nextStartedActivityForResult);ShadowAlertDialog.getLatestAlertDialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();shadowOf(android.os.Looper.getMainLooper()).idle();val settings=shadowOf(a).nextStartedActivityForResult;assertEquals(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,settings.intent.action);assertEquals("package:${a.packageName}",settings.intent.dataString);pm.setCanRequestPackageInstalls(true);shadowOf(a).receiveResult(settings.intent,0,null);assertEquals(ApkInstallerActivity.APK_MIME,shadowOf(a).nextStartedActivityForResult.intent.type)}finally{c.pause().stop().destroy()}
 }
 @Test fun protectedApkNeverReachesInstaller()=fixture{root,apk->
  val blocked=File(root,"Android/private.apk");val c=Robolectric.buildActivity(ApkInstallerActivity::class.java,intent(root,blocked)).setup();try{assertNull(shadowOf(c.get()).nextStartedActivityForResult);assertNotNull(ShadowAlertDialog.getLatestAlertDialog())}finally{ShadowAlertDialog.getLatestAlertDialog()?.dismiss();c.pause().stop().destroy()}
 }
 @Test fun previewInstallAndOpenWithUseSameDelegate()=fixture{root,apk->
  val app=RuntimeEnvironment.getApplication();app.getSharedPreferences("files-preview",0).edit().putString("root",root.path).putString("file",apk.path).putString("siblings",org.json.JSONArray(listOf(apk.path)).toString()).commit()
  val c=Robolectric.buildActivity(FilesPreviewActivity::class.java).setup();try{
   fun find(v:View,label:String):View?{if(v is TextView && v.text.toString()==label)return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),label)}else null}
   for(label in listOf("Install","Open with")){find(c.get().window.decorView,label)!!.performClick();val started=shadowOf(c.get()).nextStartedActivity;assertEquals(ApkInstallerActivity::class.java.name,started.component!!.className);assertEquals(apk.path,started.getStringExtra("file"))}
  }finally{c.pause().stop().destroy()}
 }
}
