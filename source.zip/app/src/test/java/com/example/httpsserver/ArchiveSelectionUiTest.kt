package com.example.httpsserver
import android.Manifest
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
import org.robolectric.shadows.ShadowPopupMenu
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34],shadows=[GrantedStorageEnvironment::class])
class ArchiveSelectionUiTest{
 private fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
 private fun fixture(run:(FilesActivity,File,View)->Unit){val app=RuntimeEnvironment.getApplication();Shadows.shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().canonicalFile.apply{mkdirs()};val archive=File(root,"sample.zip");ZipOutputStream(archive.outputStream()).use{it.putNextEntry(ZipEntry("hello.txt"));it.write("Hello".toByteArray());it.closeEntry()};val c=Robolectric.buildActivity(FilesActivity::class.java).setup().visible();try{val a=c.get();val decor=a.window.decorView;find(decor){it.contentDescription=="Main storage"}!!.performClick();val end=System.nanoTime()+5000000000;while(find(decor){it is TextView && it.text.toString()=="sample.zip"}==null && System.nanoTime()<end){Thread.sleep(20);Shadows.shadowOf(Looper.getMainLooper()).idle()};assertNotNull(find(decor){it is TextView && it.text.toString()=="sample.zip"});run(a,root,decor)}finally{c.pause().stop().destroy();archive.delete();File(root,"hello.txt").delete();File(root,"sample").deleteRecursively()}}
 private fun select(a:FilesActivity,file:File){a.javaClass.getDeclaredMethod("toggle",File::class.java).apply{isAccessible=true}.invoke(a,file)}
 private fun selectionMoreLabels(decor:View):List<String>{
  // The five-action selection footer deliberately keeps archive extraction under More.
  // Distinguish it from the header overflow ("More options").
  val more=find(decor){it.contentDescription=="More"}
  assertNotNull("Selection More button must be visible",more)
  more!!.performClick()
  val menu=ShadowPopupMenu.getLatestPopupMenu().menu
  return (0 until menu.size()).map{menu.getItem(it).title.toString()}
 }
 private fun openSelectionExtract(decor:View){
  val more=find(decor){it.contentDescription=="More"}
  assertNotNull("Selection More button must be visible",more)
  more!!.performClick()
  val menu=ShadowPopupMenu.getLatestPopupMenu().menu
  val item=(0 until menu.size()).map{menu.getItem(it)}.firstOrNull{it.title=="Extract"}
  assertNotNull("Selected archives must expose Extract in More",item)
  menu.performIdentifierAction(item!!.itemId,0)
 }
 private fun dialogLabels():List<String>{val list=ShadowAlertDialog.getLatestAlertDialog().listView;return (0 until list.adapter.count).map{list.adapter.getItem(it).toString()}}
 @Test fun selectedArchiveShowsExtractAndActuallyExtractsHere()=fixture{a,root,decor->select(a,File(root,"sample.zip"));openSelectionExtract(decor);assertEquals(listOf("Extract here","Extract to \"sample/\"","Choose destination…"),dialogLabels());val d=ShadowAlertDialog.getLatestAlertDialog();d.listView.performItemClick(d.listView.adapter.getView(0,null,d.listView),0,0);Shadows.shadowOf(Looper.getMainLooper()).idle();ShadowAlertDialog.getLatestAlertDialog().getButton(-1).performClick();val end=System.nanoTime()+5000000000;while((!File(root,"hello.txt").exists() || File(root,"hello.txt").readText()!="Hello") && System.nanoTime()<end){Thread.sleep(20);Shadows.shadowOf(Looper.getMainLooper()).idle()};assertEquals("Hello",File(root,"hello.txt").readText());assertTrue(File(root,"sample.zip").exists())}
 @Test fun selectedArchiveAlsoHasExtractInTopOverflow()=fixture{a,root,decor->select(a,File(root,"sample.zip"));find(decor){it.contentDescription=="More options"}!!.performClick();val menu=ShadowPopupMenu.getLatestPopupMenu().menu;val item=(0 until menu.size()).map{menu.getItem(it)}.first{it.title=="Extract"};menu.performIdentifierAction(item.itemId,0);assertTrue("Extract here" in dialogLabels())}
 @Test fun multipleArchivesHaveExtractionButMixedSelectionDoesNot()=fixture{a,root,decor->val second=File(root,"second.rar").apply{writeText("fixture")};val other=File(root,"other.txt").apply{writeText("text")};try{select(a,File(root,"sample.zip"));select(a,second);openSelectionExtract(decor);assertTrue("Extract each to archive-name folder" in dialogLabels());ShadowAlertDialog.getLatestAlertDialog().dismiss();select(a,other);val labels=selectionMoreLabels(decor);assertFalse("Extract" in labels)}finally{second.delete();other.delete()}}
 @Test fun checkboxSelectionAndRowTintAgreeInListAndGrid()=fixture{a,root,decor->
  assertTrue(find(decor){it.contentDescription=="Up one folder"} is ImageButton)
  assertNull(find(decor){it is Button && it.text.toString()=="Up"})
  val file=File(root,"sample.zip")
  for(grid in listOf(false,true)){
   a.javaClass.getDeclaredField("grid").apply{isAccessible=true}.setBoolean(a,grid)
   a.javaClass.getDeclaredMethod("bindList").apply{isAccessible=true}.invoke(a)
   val list=find(decor){it is AbsListView} as AbsListView
   val position=(0 until list.adapter.count).first{list.adapter.getItem(it)==file}
   fun bound()=list.adapter.getView(position,null,list)
   fun checked(row:View)=(find(row){it is CheckBox} as CheckBox)
   val initial=bound();assertFalse(checked(initial).isChecked)
   assertEquals(android.graphics.Color.WHITE,(initial.background as android.graphics.drawable.ColorDrawable).color)
   checked(initial).performClick()
   val selected=bound();assertTrue(checked(selected).isChecked)
   assertEquals(android.graphics.Color.rgb(215,239,234),(selected.background as android.graphics.drawable.ColorDrawable).color)
   checked(selected).performClick()
   val cleared=bound();assertFalse(checked(cleared).isChecked)
   assertEquals(android.graphics.Color.WHITE,(cleared.background as android.graphics.drawable.ColorDrawable).color)
   // AbsListView retains its last position after opening/dismissing an archive menu.
   // Neither an idle nor a selected-position state may paint a selection overlay.
   for(state in arrayOf(intArrayOf(),intArrayOf(android.R.attr.state_enabled,android.R.attr.state_selected))){
    list.selector.state=state
    assertEquals(android.graphics.Color.TRANSPARENT,(list.selector.current as android.graphics.drawable.ColorDrawable).color)
   }
   list.selector.state=intArrayOf(android.R.attr.state_pressed)
   assertEquals(android.graphics.Color.argb(22,0,0,0),(list.selector.current as android.graphics.drawable.ColorDrawable).color)
   list.selector.state=intArrayOf(android.R.attr.state_focused)
   assertEquals(android.graphics.Color.TRANSPARENT,(list.selector.current as android.graphics.drawable.GradientDrawable).color!!.defaultColor)
   list.selector.state=intArrayOf()
   assertEquals(android.graphics.Color.TRANSPARENT,(list.selector.current as android.graphics.drawable.ColorDrawable).color)
  }
 }
}
