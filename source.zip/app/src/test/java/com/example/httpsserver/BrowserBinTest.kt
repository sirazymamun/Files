package com.example.httpsserver
import android.Manifest
import android.os.Environment
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24],shadows=[GrantedStorageEnvironment::class])
class BrowserBinTest{
 @Test fun browserDeleteRestorePurgeRequireSessionAndCsrfHeader(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE)
  val root=Environment.getExternalStorageDirectory().canonicalFile;root.mkdirs();val folder=File(root,"BrowserFixture").apply{mkdir()};val file=File(folder,"sample.txt").apply{writeText("recover me")}
  val server=HttpsServer(0,app,root,true);server.start(NanoHTTPD.SOCKET_READ_TIMEOUT,false);var cookie=""
  fun request(path:String,fields:Map<String,String>?=null,csrf:Boolean=true):Pair<Int,String>{val c=URL("http://127.0.0.1:${server.listeningPort}$path").openConnection() as HttpURLConnection;c.instanceFollowRedirects=false;c.connectTimeout=5000;c.readTimeout=5000;if(cookie.isNotEmpty())c.setRequestProperty("Cookie",cookie);if(fields!=null){c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");if(csrf)c.setRequestProperty("X-Requested-With","tv2u");c.outputStream.use{it.write(fields.entries.joinToString("&"){(k,v)->URLEncoder.encode(k,"UTF-8")+"="+URLEncoder.encode(v,"UTF-8")}.toByteArray())}};val code=c.responseCode;c.getHeaderField("Set-Cookie")?.let{cookie=it.substringBefore(';')};val text=(if(code>=400)c.errorStream else c.inputStream)?.bufferedReader()?.use{it.readText()} ?: "";c.disconnect();return code to text}
  try{
   assertTrue(request("/trash").second.contains("Unlock files"));assertEquals(303,request("/login",mapOf("password" to Auth.password(app))).first)
   val fields=mapOf("folder" to "/BrowserFixture","path" to "/BrowserFixture/sample.txt","confirm" to "delete")
   assertEquals(403,request("/delete",fields,false).first)
   val deleteResponse=request("/delete",fields);assertEquals(deleteResponse.second,200,deleteResponse.first);val removed=JSONObject(deleteResponse.second);assertTrue(removed.getJSONArray("results").getJSONObject(0).getBoolean("deleted"));assertFalse(file.exists())
   val entries=JSONObject(request("/trash").second).getJSONArray("entries");assertEquals(1,entries.length());val id=entries.getJSONObject(0).getString("id")
   assertEquals(403,request("/open?path=/.FilesTrash").first)
   assertTrue(JSONObject(request("/trash",mapOf("id" to id,"action" to "restore")).second).getJSONArray("results").getJSONObject(0).getBoolean("ok"));assertEquals("recover me",file.readText())
   val props=JSONObject(request("/properties?path=/BrowserFixture/sample.txt").second);assertTrue(props.getString("Modified").matches(Regex("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}")))
   request("/delete",fields);val next=JSONObject(request("/trash").second).getJSONArray("entries").getJSONObject(0).getString("id")
   assertTrue(JSONObject(request("/trash",mapOf("id" to next,"action" to "purge")).second).getJSONArray("results").getJSONObject(0).getBoolean("ok"));assertEquals(0,TrashStore(root).entries().size)
  }finally{server.stop();folder.deleteRecursively()}
 }
}
