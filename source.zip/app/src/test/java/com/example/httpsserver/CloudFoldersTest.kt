package com.example.httpsserver
import android.app.Application
import android.content.Context
import android.content.pm.ProviderInfo
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.DocumentsProvider
import androidx.documentfile.provider.DocumentFile
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowContentResolver
import java.io.File
import java.nio.file.Files
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24])
class CloudFoldersTest {
 @Test fun documentProviderSyncKeepsConflictsAndSkipsIdentical(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions("android.permission.MANAGE_DOCUMENTS")
  val local=Files.createTempDirectory("files-sync-local").toFile();val remote=Files.createTempDirectory("files-sync-remote").toFile()
  val provider=FixtureProvider(remote);provider.attachInfo(app,ProviderInfo().apply{authority="files.sync.test";exported=true;grantUriPermissions=true;readPermission="android.permission.MANAGE_DOCUMENTS";writePermission=readPermission});provider.onCreate();ShadowContentResolver.registerProviderInternal("files.sync.test",provider)
  val tree=DocumentFile.fromTreeUri(app,DocumentsContract.buildTreeDocumentUri("files.sync.test","root"))!!
  try{
   File(local,"a.txt").writeText("first");assertEquals(1,CloudFolders.sync(app,local,local,tree,true).added)
   assertEquals("first",File(remote,"a.txt").readText());assertEquals(1,CloudFolders.sync(app,local,local,tree,true).same)
   File(local,"a.txt").writeText("changed");assertEquals(1,CloudFolders.sync(app,local,local,tree,true).added);assertEquals("first",File(remote,"a.txt").readText());assertEquals("changed",File(remote,"a (copy 1).txt").readText())
   File(remote,"b.txt").writeText("download");val result=CloudFolders.sync(app,local,local,tree,false);assertTrue(result.added>0);assertEquals("changed",File(local,"a.txt").readText());assertEquals("download",File(local,"b.txt").readText())
  }finally{local.deleteRecursively();remote.deleteRecursively()}
 }
 private class FixtureProvider(val base:File):DocumentsProvider(){
  private val cols=arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_FLAGS,DocumentsContract.Document.COLUMN_SIZE,DocumentsContract.Document.COLUMN_LAST_MODIFIED)
  private fun file(id:String)=if(id=="root")base else File(base,id.removePrefix("root:"))
  private fun id(file:File)=if(file==base)"root" else "root:"+file.relativeTo(base).path
  private fun cursor(files:List<File>,projection:Array<out String>?):Cursor{val columns=projection ?: cols;val c=MatrixCursor(columns);for(f in files){val values=mapOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID to id(f),DocumentsContract.Document.COLUMN_DISPLAY_NAME to f.name,DocumentsContract.Document.COLUMN_MIME_TYPE to if(f.isDirectory)DocumentsContract.Document.MIME_TYPE_DIR else "text/plain",DocumentsContract.Document.COLUMN_FLAGS to (DocumentsContract.Document.FLAG_SUPPORTS_WRITE or DocumentsContract.Document.FLAG_SUPPORTS_DELETE or if(f.isDirectory)DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE else 0),DocumentsContract.Document.COLUMN_SIZE to f.length(),DocumentsContract.Document.COLUMN_LAST_MODIFIED to f.lastModified());c.addRow(columns.map{values[it]}.toTypedArray())};return c}
  override fun onCreate()=true
  override fun queryRoots(projection:Array<out String>?)=MatrixCursor(projection ?: arrayOf(DocumentsContract.Root.COLUMN_ROOT_ID))
  override fun queryDocument(documentId:String,projection:Array<out String>?)=cursor(listOf(file(documentId)),projection)
  override fun queryChildDocuments(parentDocumentId:String,projection:Array<out String>?,sortOrder:String?)=cursor(file(parentDocumentId).listFiles()?.toList() ?: emptyList(),projection)
  override fun openDocument(documentId:String,mode:String,signal:android.os.CancellationSignal?)=ParcelFileDescriptor.open(file(documentId),ParcelFileDescriptor.parseMode(mode))
  override fun createDocument(parentDocumentId:String,mimeType:String,displayName:String):String{val f=File(file(parentDocumentId),displayName);check(if(mimeType==DocumentsContract.Document.MIME_TYPE_DIR)f.mkdir()else f.createNewFile());return id(f)}
  override fun deleteDocument(documentId:String){check(file(documentId).delete())}
  override fun isChildDocument(parentDocumentId:String,documentId:String)=file(documentId).path.startsWith(file(parentDocumentId).path+"/")
 }
}
