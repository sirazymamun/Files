package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test
import java.io.File

/** Contract checks: source-to-destination functionality must not regress to Drive-only actions. */
class DriveLocalActionsSourceTest {
 @Test fun storageTransferFolderPickerAndPasteChoicesExist() {
  val source = File("src/main/java/com/example/httpsserver/GoogleDriveActivity.kt").readText()
  assertTrue(source.contains("Phone / Internal Storage folder"))
  assertTrue(source.contains("Paste here"))
  assertTrue(source.contains("Move here"))
  assertTrue(source.contains("Paste into Drive folder"))
  assertTrue(source.contains("DriveTransfers(api,root,hidden()"))
 }
 @Test fun cutNeverTrashesBeforeVerifiedDownload() {
  val source = File("src/main/java/com/example/httpsserver/GoogleDriveActivity.kt").readText()
  val start = source.indexOf("private fun localTransfer(")
  val end = source.indexOf("private fun copySelected()", start)
  assertTrue(start>0 && end>start)
  val cut=source.substring(start,end)
  val download=cut.indexOf(".download(listOf(item),destination)")
  val verify=cut.indexOf("require(current.skipped==0)")
  val trash=cut.indexOf("api.trash(item)")
  assertTrue(download>=0 && verify>download && trash>verify)
 }
}
