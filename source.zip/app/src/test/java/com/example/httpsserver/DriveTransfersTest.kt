package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.*
import java.nio.file.Files
import java.security.MessageDigest
@org.junit.runner.RunWith(org.robolectric.RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk=[24,34])
class DriveTransfersTest{
 private class Fake:DriveRemote{
  val children=mutableMapOf<String,MutableList<DriveItem>>();val bytes=mutableMapOf<String,ByteArray>();var fail=false
  private fun hash(b:ByteArray)=MessageDigest.getInstance("MD5").digest(b).joinToString(""){"%02x".format(it.toInt() and 255)}
  fun put(parent:String,name:String,b:ByteArray,mime:String="application/octet-stream"):DriveItem{val id="id"+(bytes.size+children.values.sumOf{it.size});val item=DriveItem(id,name,mime,b.size.toLong(),if(mime.startsWith("application/vnd.google-apps."))null else hash(b));children.getOrPut(parent){mutableListOf()}.add(item);bytes[id]=b;return item}
  override fun list(parent:String)=children[parent]?.toList() ?: emptyList()
  override fun mkdir(parent:String,name:String):DriveItem{val id="folder"+children.values.sumOf{it.size};val item=DriveItem(id,name,"application/vnd.google-apps.folder");children.getOrPut(parent){mutableListOf()}.add(item);children[id]=mutableListOf();return item}
  override fun upload(parent:String,name:String,file:File,mime:String,check:()->Unit,progress:(Long)->Unit):DriveItem{check();val data=file.readBytes();progress(data.size.toLong());return put(parent,name,data,mime)}
  override fun download(item:DriveItem,out:OutputStream,check:(Int)->Unit){val b=bytes.getValue(item.id);check(b.size);out.write(b);if(fail)throw IOException("connection lost")}
 }
 private fun fixture(run:(File,Fake)->Unit){val root=Files.createTempDirectory("drive-transfers").toFile();try{run(root,Fake())}finally{root.deleteRecursively()}}
 @Test fun foldersUploadRecursivelyAndRepeatedFilesAreSkipped()=fixture{root,remote->val folder=File(root,"বাংলা").apply{mkdir()};File(folder,"note.txt").writeText("hello");val first=DriveTransfers(remote,root).upload(listOf(folder),"root");assertEquals(1,first.copied);val again=DriveTransfers(remote,root).upload(listOf(folder),"root");assertEquals(1,again.same);assertEquals(1,remote.list("root").size)}
 @Test fun uploadCollisionKeepsBothCopies()=fixture{root,remote->val f=File(root,"a.txt").apply{writeText("local")};remote.put("root","a.txt","old".toByteArray());DriveTransfers(remote,root).upload(listOf(f),"root");assertEquals(listOf("a.txt","a (copy 1).txt"),remote.list("root").map{it.name});assertEquals("old",String(remote.bytes.getValue(remote.list("root")[0].id)))}
 @Test fun downloadsKeepDifferentLocalFilesAndValidateHash()=fixture{root,remote->val item=remote.put("root","a.txt","cloud".toByteArray());File(root,"a.txt").writeText("keep");DriveTransfers(remote,root).download(listOf(item),root);assertEquals("keep",File(root,"a.txt").readText());assertEquals("cloud",File(root,"a (copy 1).txt").readText());assertFalse(root.list()!!.any{it.endsWith(".part")})}
 @Test fun failedDownloadLeavesNoFinalOrPartialFile()=fixture{root,remote->val item=remote.put("root","fail.bin",byteArrayOf(1,2,3));remote.fail=true;assertThrows(IOException::class.java){DriveTransfers(remote,root).download(listOf(item),root)};assertEquals(0,root.list()!!.size)}
 @Test fun maliciousNamesAndPrivateTreesAreNeverTransferred()=fixture{root,remote->val bad=remote.put("root","../escape","bad".toByteArray());assertEquals(1,DriveTransfers(remote,root).download(listOf(bad),root).skipped);val folder=File(root,"share").apply{mkdir()};File(folder,".hidden").writeText("secret");File(folder,"a.txt").writeText("public");Files.createSymbolicLink(File(folder,"link").toPath(),File(folder,"a.txt").toPath());val r=DriveTransfers(remote,root).upload(listOf(folder),"root");assertEquals(1,r.copied);assertEquals(2,r.skipped);val privateFile=File(root,"Android/data/x").apply{parentFile!!.mkdirs();writeText("no")};assertThrows(IllegalArgumentException::class.java){DriveTransfers(remote,root).upload(listOf(privateFile),"root")}}
 @Test fun nestedDownloadsAndGoogleDocumentExportUseRealExtensions()=fixture{root,remote->val folder=remote.mkdir("root","Folder");val doc=remote.put(folder.id,"Report","document".toByteArray(),"application/vnd.google-apps.document");DriveTransfers(remote,root).download(listOf(folder),root);assertEquals("document",File(root,"Folder/Report.docx").readText());assertTrue(doc.workspace)}
 @Test fun cancelledTransfersDoNotCreateDestinationFiles()=fixture{root,remote->val item=remote.put("root","a",byteArrayOf(1));assertThrows(java.util.concurrent.CancellationException::class.java){DriveTransfers(remote,root,cancelled={true}).download(listOf(item),root)};assertTrue(root.list()!!.isEmpty())}
 @Test fun corruptRemoteContentFailsIntegrityCheck()=fixture{root,remote->val item=remote.put("root","a.bin",byteArrayOf(1,2));remote.bytes[item.id]=byteArrayOf(3,4);assertThrows(IllegalArgumentException::class.java){DriveTransfers(remote,root).download(listOf(item),root)};assertTrue(root.list()!!.isEmpty())}
}
