package com.example.httpsserver

import java.io.File
import java.nio.file.Files
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class EmptyFolderVisibilityTest {
    @get:Rule val tmp = TemporaryFolder()
    @Test fun physicallyEmptyDirectoryIsHiddenButNotDeleted() {
        val root=tmp.newFolder("storage");val dir=File(root,"Alarms").apply {mkdir()}
        assertFalse(SharedFiles(root).visibleInListing(dir));assertTrue(dir.exists())
    }
    @Test fun zeroByteFileAndDirectoryContainingItRemainVisible() {
        val root=tmp.newFolder("storage");val dir=File(root,"Documents").apply {mkdir()}
        val emptyFile=File(dir,"empty.txt").apply {writeBytes(byteArrayOf())}
        val shared=SharedFiles(root)
        assertTrue(shared.visibleInListing(dir));assertTrue(shared.visibleInListing(emptyFile))
    }
    @Test fun directoryWithAnImmediateSubdirectoryIsNotEmpty() {
        val root=tmp.newFolder("storage");val parent=File(root,"Parent").apply {mkdir()}
        val child=File(parent,"Empty child").apply {mkdir()}
        val shared=SharedFiles(root)
        assertTrue(shared.visibleInListing(parent));assertFalse(shared.visibleInListing(child))
    }
    @Test fun hiddenSystemOrUnsafeChildrenDoNotMakeFolderVisible() {
        val root=tmp.newFolder("storage");val dir=File(root,"Only metadata").apply {mkdir()}
        File(dir,".nomedia").writeText("metadata");File(dir,"Android/media").mkdirs()
        val outside=tmp.newFolder("outside");File(outside,"private.txt").writeText("private")
        Files.createSymbolicLink(File(dir,"outside-link").toPath(),outside.toPath())
        assertFalse(SharedFiles(root).visibleInListing(dir))
        assertTrue(File(dir,".nomedia").exists())
    }
    @Test fun folderReturnsToListingWhenAFileIsAdded() {
        val root=tmp.newFolder("storage");val dir=File(root,"New folder").apply {mkdir()};val shared=SharedFiles(root)
        assertFalse(shared.visibleInListing(dir));File(dir,"note.txt").writeText("hello");assertTrue(shared.visibleInListing(dir))
    }
    @Test fun unreadableFolderIsNotMistakenForAnEmptyFolder() {
        val root=tmp.newFolder("storage");File(root,"Unreadable").mkdir()
        val unreadable=object : File(root,"Unreadable") { override fun list(): Array<String>? = null }
        assertTrue(SharedFiles(root).visibleInListing(unreadable))
    }

}
