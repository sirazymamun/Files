package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.EncryptionMethod
class ExtractIntoTest{
 private fun fixture(run:(File)->Unit){val root=Files.createTempDirectory("extract-options").toFile();try{run(root)}finally{root.deleteRecursively()}}
 private fun zip(root:File,name:String,items:Map<String,String>):File=File(root,name).also{file->ZipOutputStream(file.outputStream()).use{out->items.forEach{(path,text)->out.putNextEntry(ZipEntry(path));out.write(text.toByteArray());out.closeEntry()}}}
 @Test fun hereKeepsExistingFilesMergesDirectoriesAndPreservesArchive()=fixture{r->val archive=zip(r,"data.zip",mapOf("a.txt" to "new","folder/item.txt" to "child","data.zip" to "payload"));val original=archive.readBytes();File(r,"a.txt").writeText("old");File(r,"folder").mkdir();File(r,"folder/kept.txt").writeText("keep");val result=LocalArchives.extractInto(r,archive,r);assertEquals(3,result.files);assertEquals(2,result.renamed);assertEquals("old",File(r,"a.txt").readText());assertEquals("new",File(r,"a (extracted 1).txt").readText());assertEquals("child",File(r,"folder/item.txt").readText());assertEquals("keep",File(r,"folder/kept.txt").readText());assertArrayEquals(original,archive.readBytes());assertEquals("payload",File(r,"data (extracted 1).zip").readText());assertFalse(r.list()!!.any{it.startsWith(".Files-extract-")})}
 @Test fun fileAndFolderNameConflictsGetSeparateIncomingNames()=fixture{r->val archive=zip(r,"data.zip",mapOf("folder/child.txt" to "child","directory" to "file"));File(r,"folder").writeText("keep file");File(r,"directory").mkdir();LocalArchives.extractInto(r,archive,r);assertEquals("keep file",File(r,"folder").readText());assertEquals("child",File(r,"folder (extracted 1)/child.txt").readText());assertTrue(File(r,"directory").isDirectory);assertEquals("file",File(r,"directory (extracted 1)").readText())}
 @Test fun dotfilesArePreservedEvenWithHiddenDisplayOff()=fixture{r->val archive=zip(r,"project.zip",mapOf(".github/workflows/app-debug.yml" to "name: test",".gitignore" to "build/"));LocalArchives.extractInto(r,archive,r);assertEquals("name: test",File(r,".github/workflows/app-debug.yml").readText());assertEquals("build/",File(r,".gitignore").readText())}
 @Test fun encryptedFailureKeepsDestinationAndCleansTemporaryData()=fixture{r->val source=File(r,"secret.txt").apply{writeText("secret")};val archive=File(r,"encrypted.zip");ZipFile(archive,"correct".toCharArray()).use{it.addFile(source,ZipParameters().apply{isEncryptFiles=true;encryptionMethod=EncryptionMethod.AES})};source.writeText("old");assertThrows(java.io.IOException::class.java){LocalArchives.extractInto(r,archive,r,"wrong")};assertEquals("old",source.readText());assertFalse(r.list()!!.any{it.startsWith(".Files-extract-")});LocalArchives.extractInto(r,archive,r,"correct");assertEquals("secret",File(r,"secret (extracted 1).txt").readText())}
 @Test fun maliciousArchiveCannotEscapeOrChangeAnExistingDestination()=fixture{r->val archive=zip(r,"bad.zip",mapOf("safe.txt" to "new","../outside.txt" to "bad"));File(r,"safe.txt").writeText("keep");assertThrows(IllegalArgumentException::class.java){LocalArchives.extractInto(r,archive,r)};assertEquals("keep",File(r,"safe.txt").readText());assertFalse(File(r.parentFile,"outside.txt").exists());assertFalse(r.list()!!.any{it.startsWith(".Files-extract-")})}
 @Test fun separateDestinationVolumeAndNamedFolderAreSupported()=fixture{r->val source=File(r,"source").apply{mkdir()};val target=File(r,"sd").apply{mkdir()};val archive=zip(source,"data.zip",mapOf("a.txt" to "A"));LocalArchives.extractInto(source,archive,target,destinationRoot=target);assertEquals("A",File(target,"a.txt").readText());val named=LocalArchives.availableFolder(target,target,"data");LocalArchives.extract(source,archive,named,destinationRoot=target);assertEquals("A",File(named,"a.txt").readText());assertEquals("data (1)",LocalArchives.availableFolder(target,target,"data").name)}
 @Test fun destinationLinksDoNotExposeOutsideFiles()=fixture{r->val archive=zip(r,"data.zip",mapOf("linked/x.txt" to "new"));val outside=Files.createTempDirectory("extract-outside").toFile();val link=File(r,"linked");try{File(outside,"x.txt").writeText("keep");Files.createSymbolicLink(link.toPath(),outside.toPath());assertThrows(IllegalArgumentException::class.java){LocalArchives.extractInto(r,archive,r)};assertEquals("keep",File(outside,"x.txt").readText());assertFalse(r.list()!!.any{it.startsWith(".Files-extract-")})}finally{link.delete();outside.deleteRecursively()}}
 @Test fun rarCanAlsoExtractIntoAnExistingDirectory()=fixture{r->val rar=File(r,"sample.rar");javaClass.getResourceAsStream("/archives/rar5.rar")!!.use{input->rar.outputStream().use{input.copyTo(it)}};assertTrue(LocalArchives.extractInto(r,rar,r).files>0);assertTrue(rar.isFile)}
 @Test fun windowsMetadataIsAllowedWhenExtractedIntoDownloads()=fixture{r->
  val downloads=File(r,"Download").apply{mkdir()}
  val archive=zip(downloads,"runtime.zip",mapOf("package/desktop.ini" to "metadata","package/Android/asset.txt" to "asset","package/Thumbs.db" to "thumb"))
  val result=LocalArchives.extractInto(r,archive,downloads)
  assertEquals(3,result.files)
  assertEquals("metadata",File(downloads,"package/desktop.ini").readText())
  assertEquals("asset",File(downloads,"package/Android/asset.txt").readText())
 }

}
