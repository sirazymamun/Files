package com.example.httpsserver

import java.io.File
import java.nio.file.Files
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FileAccessTest {
    @get:Rule val tmp = TemporaryFolder()

    @Test fun userFilesAndBengaliNamesAreAllowed() {
        val root = tmp.newFolder("phone")
        val shared = SharedFiles(root)
        assertEquals(File(root, "Download/আমার ছবি.jpg"), shared.resolve("/Download/আমার ছবি.jpg"))
        assertTrue(shared.validName("আমার ফাইল #1 + 100%.txt"))
        assertEquals(root, shared.resolve(""))
        assertNull(shared.resolve(".secret"))
        assertNull(shared.resolve("DCIM/.thumbnails/a"))
        assertEquals(File(root,"Android/media/app/file.mp4"),shared.resolve("Android/media/app/file.mp4"))
        assertFalse(shared.validName(".hidden.txt"))
    }

    @Test fun hiddenAndSystemNamesCannotBeBrowsedOrAccessedByDirectPath() {
        val root = tmp.newFolder("storage")
        val shared = SharedFiles(root)
        for (path in listOf(".gs", ".gs_fs0", ".nomedia", "DCIM/.thumbnails/pic.jpg", "Pictures/.cache/x", "LOST.DIR", "desktop.ini", "Thumbs.db", "sub/.secret.txt")) {
            assertNull(path, shared.resolve(path))
        }
        for (path in listOf("DCIM/Camera/photo.jpg", "Pictures/ছবি.png", "Download/version1.2.txt", "ChatGPT/notes.txt", "Android/media/app/photo.jpg")) assertNotNull(path, shared.resolve(path))
        val hidden = File(root, ".gs").apply { mkdir() }
        Files.createSymbolicLink(File(root, "ordinary-name").toPath(), hidden.toPath())
        assertNull(shared.resolve("ordinary-name/file.txt"))
    }

    @Test fun privateAndroidAndTraversalPathsAreBlocked() {
        val shared = SharedFiles(tmp.newFolder("phone"))
        for (path in listOf("Android/data/a", "Android/obb/a", "LOST.DIR", "../outside", "Download/../../outside", "a\\b", "bad\u0000name")) {
            assertNull(path, shared.resolve(path))
        }
        for (name in listOf("LOST.DIR", "System Volume Information", "a/b", "..", " ")) {
            assertFalse(name, shared.validName(name))
        }
    }

    @Test fun symlinksCannotExposePrivateOrOutsideFiles() {
        val root = tmp.newFolder("phone")
        val outside = tmp.newFolder("outside")
        File(root, "Android/data").mkdirs()
        Files.createSymbolicLink(File(root, "alias").toPath(), File(root, "Android/data").toPath())
        Files.createSymbolicLink(File(root, "escape").toPath(), outside.toPath())
        val shared = SharedFiles(root)
        assertNull(shared.resolve("alias/file.txt"))
        assertNull(shared.resolve("escape/file.txt"))
    }

    @Test fun validRenameKeepsContentsAndConflictCanBeDetected() {
        val root = tmp.newFolder("phone")
        val shared = SharedFiles(root)
        File(root, "old.txt").writeText("unchanged contents")
        val target = shared.resolve("নতুন.txt")!!
        assertFalse(target.exists())
        assertTrue(shared.resolve("old.txt")!!.renameTo(target))
        assertEquals("unchanged contents", target.readText())
        assertFalse(File(root, "old.txt").exists())
        assertTrue(shared.resolve("নতুন.txt")!!.exists())
    }

    @Test fun mediaRangesSupportSeekingAndRejectInvalidRequests() {
        assertEquals(ByteRange(0, 99), ByteRange.parse("bytes=0-99", 1000))
        assertEquals(ByteRange(900, 999), ByteRange.parse("bytes=900-", 1000))
        assertEquals(ByteRange(900, 999), ByteRange.parse("bytes=-100", 1000))
        assertEquals(ByteRange(0, 999), ByteRange.parse("bytes=-2000", 1000))
        assertEquals(ByteRange(500, 999), ByteRange.parse("bytes=500-99999", 1000))
        for (range in listOf("bytes=1000-", "bytes=20-10", "bytes=-0", "bytes=-", "bytes=0-5,10-15", "bytes=999999999999999999999-", "bad")) assertNull(range, ByteRange.parse(range, 1000))
        assertNull(ByteRange.parse("bytes=0-0", 0))
    }
}
