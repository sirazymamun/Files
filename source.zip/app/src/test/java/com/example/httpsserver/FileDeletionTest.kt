package com.example.httpsserver

import java.io.File
import java.nio.file.Files
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FileDeletionTest {
    @get:Rule val tmp = TemporaryFolder()
    @Test fun singleFileRemovedAndNeighbourUnchanged() {
        val root=tmp.newFolder();File(root,"one.txt").writeText("one");File(root,"keep.txt").writeText("keep")
        val result=FileDeletion(root).delete("",listOf("/one.txt"))
        assertTrue(result.single().deleted);assertFalse(File(root,"one.txt").exists());assertEquals("keep",File(root,"keep.txt").readText())
    }
    @Test fun hiddenFileIsNotExposedToDeletion() {
        val root=tmp.newFolder();File(root,".user-note.txt").writeText("hidden")
        assertFalse(FileDeletion(root).delete("",listOf("/.user-note.txt")).single().deleted)
        assertTrue(File(root,".user-note.txt").exists())
    }
    @Test fun multipleUnicodeAndSpecialNamesDeleted() {
        val root=tmp.newFolder();val dir=File(root,"Documents").apply{mkdir()}
        val names=listOf("বাংলা ছবি + #%.png","a&'\".txt","empty.txt")
        names.forEach{File(dir,it).writeText("data")}
        val results=FileDeletion(root).delete("/Documents",names.map{"/Documents/$it"})
        assertEquals(3,results.count{it.deleted});assertTrue(dir.isDirectory);assertEquals(0,dir.listFiles()!!.size)
    }
    @Test fun rootNeverDeletedButSelectedFolderCanBeDeleted() {
        val root=tmp.newFolder();val dir=File(root,"selected").apply{mkdir()};File(dir,"child.txt").writeText("data")
        val results=FileDeletion(root).delete("",listOf("", "/", "/selected"))
        assertFalse(results[0].deleted);assertFalse(results[1].deleted);assertTrue(results[2].deleted)
        assertTrue(root.isDirectory);assertFalse(dir.exists())
    }
    @Test fun deletesMultipleNestedFoldersAndFilesButKeepsNeighbours() {
        val root=tmp.newFolder()
        for(name in listOf("প্রথম folder/sub/a.txt","Second/b.txt","standalone.txt","keep/untouched.txt")) File(root,name).apply{parentFile!!.mkdirs();writeText("data")}
        val results=FileDeletion(root).delete("",listOf("/প্রথম folder","/Second","/standalone.txt"))
        assertEquals(3,results.count{it.deleted});assertFalse(File(root,"প্রথম folder").exists());assertFalse(File(root,"Second").exists());assertTrue(File(root,"keep/untouched.txt").exists())
    }
    @Test fun folderWithProtectedContentsIsRejectedBeforeAnyDeletion() {
        val root=tmp.newFolder();val folder=File(root,"Photos").apply{mkdir()}
        File(folder,"visible.txt").writeText("keep")
        File(folder,".thumbnails/private.txt").apply{parentFile!!.mkdirs();writeText("keep")}
        val result=FileDeletion(root).delete("",listOf("/Photos")).single()
        assertFalse(result.deleted);assertTrue(File(folder,"visible.txt").exists());assertTrue(File(folder,".thumbnails/private.txt").exists())
    }
    @Test fun folderWithSymlinkDoesNotDeleteOutsideOrVisibleContent() {
        val root=tmp.newFolder();val folder=File(root,"Shared").apply{mkdir()};File(folder,"keep.txt").writeText("keep")
        val outside=tmp.newFolder();File(outside,"private.txt").writeText("keep")
        Files.createSymbolicLink(File(folder,"link").toPath(),outside.toPath())
        assertFalse(FileDeletion(root).delete("",listOf("/Shared")).single().deleted)
        assertTrue(File(folder,"keep.txt").exists());assertTrue(File(outside,"private.txt").exists())
    }
    @Test fun oversizedFolderIsRejectedWithoutPartialDeletion() {
        val root=tmp.newFolder();val folder=File(root,"Many").apply{mkdir()}
        repeat(3){File(folder,"$it.txt").writeText("keep")}
        assertFalse(FileDeletion(root,maxEntries=2).delete("",listOf("/Many")).single().deleted)
        assertEquals(3,folder.listFiles()!!.size)
    }
    @Test fun protectedAndroidAndTraversalRejected() {
        val root=tmp.newFolder();File(root,".secret").writeText("safe");File(root,"Android/data").mkdirs();File(root,"Android/data/private.txt").writeText("safe")
        val results=FileDeletion(root).delete("",listOf("/Android/data/private.txt","../outside.txt","/bad\\name"))
        assertTrue(results.none{it.deleted});assertTrue(File(root,".secret").exists());assertTrue(File(root,"Android/data/private.txt").exists())
    }
    @Test fun symlinkFileAndSymlinkParentDoNotDeleteTargets() {
        val root=tmp.newFolder();val folder=File(root,"real").apply{mkdir()};val file=File(folder,"safe.txt").apply{writeText("safe")}
        Files.createSymbolicLink(File(root,"link.txt").toPath(),file.toPath());Files.createSymbolicLink(File(root,"alias").toPath(),folder.toPath())
        assertFalse(FileDeletion(root).delete("",listOf("/link.txt")).single().deleted)
        assertFalse(FileDeletion(root).delete("/real",listOf("/alias/safe.txt")).single().deleted)
        assertEquals("safe",file.readText())
    }
    @Test fun batchReportsPartialResultsAndDeduplicates() {
        val root=tmp.newFolder();File(root,"ok.txt").writeText("ok");File(root,"folder").mkdir()
        val results=FileDeletion(root).delete("",listOf("/ok.txt","/missing.txt","/folder","/ok.txt"))
        assertEquals(3,results.size);assertEquals(2,results.count{it.deleted});assertEquals(1,results.count{!it.deleted})
    }
    @Test fun filesOutsideCurrentDirectoryRejected() {
        val root=tmp.newFolder();File(root,"sub").mkdir();File(root,"keep.txt").writeText("safe")
        assertFalse(FileDeletion(root).delete("/sub",listOf("/keep.txt")).single().deleted);assertTrue(File(root,"keep.txt").exists())
    }
    @Test fun selectionLimitAndInvalidFolderCauseNoDeletion() {
        val root=tmp.newFolder();val file=File(root,"keep.txt").apply{writeText("safe")};val deletion=FileDeletion(root)
        for(paths in listOf(emptyList(),List(201){"/keep.txt"}))try{deletion.delete("",paths);fail()}catch(expected:IllegalArgumentException){}
        try{deletion.delete("/missing",listOf("/keep.txt"));fail()}catch(expected:IllegalArgumentException){}
        assertEquals("safe",file.readText())
    }
}
