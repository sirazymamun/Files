package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files
class FileManagerOpsTest {
 private fun sandbox(block:(File)->Unit){val root=Files.createTempDirectory("files-ops").toFile();try{block(root)}finally{root.deleteRecursively()}}
 @Test fun copyFolderAndZeroByteFile()=sandbox{r->val src=File(r,"Photos").apply{mkdir()};File(src,"zero.txt").writeBytes(byteArrayOf());File(src,"x.txt").writeText("hello");val dst=File(r,"Destination").apply{mkdir()};FileManagerOps(r).transfer(src,dst,false);assertEquals("hello",File(dst,"Photos/x.txt").readText());assertTrue(File(dst,"Photos/zero.txt").isFile);assertTrue(src.exists())}
 @Test fun moveFolderSameVolume()=sandbox{r->val src=File(r,"A").apply{mkdir()};File(src,"x.txt").writeText("x");val dst=File(r,"B").apply{mkdir()};FileManagerOps(r).transfer(src,dst,true);assertFalse(src.exists());assertEquals("x",File(dst,"A/x.txt").readText())}
 @Test fun copyAcrossRoots()=sandbox{r->sandbox{other->val src=File(r,"x.txt").apply{writeText("sample")};FileManagerOps(r).transfer(src,other,false,other);assertEquals("sample",File(other,"x.txt").readText());assertTrue(src.exists())}}
 @Test fun destinationCollisionNeverOverwrites()=sandbox{r->val src=File(r,"a.txt").apply{writeText("new")};val dst=File(r,"D").apply{mkdir()};File(dst,"a.txt").writeText("old");assertThrows(IllegalArgumentException::class.java){FileManagerOps(r).transfer(src,dst,false)};assertEquals("old",File(dst,"a.txt").readText())}
 @Test fun protectedDescendantRefusesWholeCopy()=sandbox{r->val src=File(r,"Folder").apply{mkdir()};File(src,".private").writeText("hidden");val dst=File(r,"To").apply{mkdir()};assertThrows(IllegalArgumentException::class.java){FileManagerOps(r).transfer(src,dst,false)};assertFalse(File(dst,"Folder").exists());assertTrue(File(src,".private").exists())}
 @Test fun folderCannotCopyIntoItself()=sandbox{r->val src=File(r,"Folder").apply{mkdir()};val child=File(src,"Sub").apply{mkdir()};assertThrows(IllegalArgumentException::class.java){FileManagerOps(r).transfer(src,child,false)};assertFalse(File(child,"Folder").exists())}
 @Test fun linkAndTraversalRefused()=sandbox{r->val target=File(r,"target.txt").apply{writeText("safe")};val link=File(r,"link.txt");Files.createSymbolicLink(link.toPath(),target.toPath());assertThrows(IllegalArgumentException::class.java){FileManagerOps(r).checked(link)};assertThrows(IllegalArgumentException::class.java){FileManagerOps(r).child(r,"../outside")};assertThrows(IllegalArgumentException::class.java){FileManagerOps(r).rename(target,"Android")}}
 @Test fun renameAndCategories()=sandbox{r->val f=File(r,"one.txt").apply{writeText("x")};FileManagerOps(r).rename(f,"বাংলা.txt");assertEquals("x",File(r,"বাংলা.txt").readText());assertEquals("Images",FileManagerOps.category(File("PHOTO.JPG")));assertEquals("Audio",FileManagerOps.category(File("song.flac")));assertEquals("0 B",FileManagerOps.formatBytes(0));assertEquals("1.0 KB",FileManagerOps.formatBytes(1024))}
}
