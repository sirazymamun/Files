package com.example.httpsserver

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.Random
import java.util.zip.ZipInputStream
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FolderArchiveTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun entries(bytes: ByteArray): Map<String, ByteArray> {
        val out = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes), Charsets.UTF_8).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                assertFalse(entry.name.startsWith("/"))
                assertFalse(entry.name.split('/').contains(".."))
                out[entry.name] = zip.readBytes()
                zip.closeEntry()
            }
        }
        return out
    }

    @Test fun nestedFilesBengaliNamesAndEmptyFoldersRoundTrip() {
        val root = tmp.newFolder("phone")
        val dir = File(root, "আমার ফোল্ডার + 100%").apply { mkdirs() }
        File(dir, "খালি ফোল্ডার").mkdir()
        File(dir, "sub").mkdir()
        File(dir, "sub/নোট.txt").writeText("বাংলা লেখা")
        File(dir, "photo.bin").writeBytes(byteArrayOf(0, 1, 2, -1))
        val out = ByteArrayOutputStream()
        FolderArchive.write(root, dir, out)
        val zip = entries(out.toByteArray())
        assertTrue(zip.containsKey("${dir.name}/"))
        assertTrue(zip.containsKey("${dir.name}/খালি ফোল্ডার/"))
        assertArrayEquals("বাংলা লেখা".toByteArray(), zip["${dir.name}/sub/নোট.txt"])
        assertArrayEquals(byteArrayOf(0, 1, 2, -1), zip["${dir.name}/photo.bin"])
    }

    @Test fun omitsAllHiddenAndSystemItems() {
        val root = tmp.newFolder("phone")
        val dir = File(root, "Shared").apply { mkdir() }
        for (name in listOf("Android", "LOST.DIR", "System Volume Information", ".cache", "sub/ANDROID")) {
            val folder = File(dir, name).apply { mkdirs() }
            File(folder, "secret.txt").writeText("not shared")
        }
        File(dir, ".nomedia").writeText("hidden")
        File(dir, "sub/visible.txt").writeText("keep")
        val out = ByteArrayOutputStream()
        FolderArchive.write(root, dir, out)
        val zip = entries(out.toByteArray())
        assertFalse(zip.containsKey("Shared/.nomedia"))
        assertFalse(zip.containsKey("Shared/.cache/secret.txt"))
        assertFalse(zip.containsKey("Shared/Android/secret.txt"))
        assertFalse(zip.containsKey("Shared/sub/ANDROID/secret.txt"))
        assertFalse(zip.keys.any { it.contains("LOST.DIR") || it.contains("System Volume Information") })
    }

    @Test fun androidSystemDirectoryIsNotDownloadableAsAnArchive() {
        val root=tmp.newFolder("storage")
        val android=File(root,"Android").apply {mkdir()}
        File(android,"media/photo.jpg").apply {parentFile!!.mkdirs();writeText("media")}
        try {FolderArchive.write(root,android,ByteArrayOutputStream());fail("Android directory exposed")}
        catch (_: IllegalArgumentException) { }
    }

    @Test fun skipsSymlinksAndCycles() {
        val root = tmp.newFolder("phone")
        val outside = tmp.newFolder("outside")
        File(outside, "private.txt").writeText("private")
        val dir = File(root, "Shared").apply { mkdir() }
        File(dir, "ok.txt").writeText("ok")
        Files.createSymbolicLink(File(dir, "loop").toPath(), dir.toPath())
        Files.createSymbolicLink(File(dir, "escape").toPath(), outside.toPath())
        val out = ByteArrayOutputStream()
        FolderArchive.write(root, dir, out)
        assertEquals(setOf("Shared/", "Shared/ok.txt"), entries(out.toByteArray()).keys)
    }

    @Test fun rejectsRootOutsideAndReservedFolder() {
        val root = tmp.newFolder("phone")
        val blocked = File(root, "Android/data").apply { mkdirs() }
        for (selected in listOf(root, tmp.newFolder("outside"), blocked)) {
            try {
                FolderArchive.write(root, selected, ByteArrayOutputStream())
                fail("Not allowed: $selected")
            } catch (_: IllegalArgumentException) { }
        }
    }

    @Test fun streamProducesAReadableArchive() {
        val root = tmp.newFolder("phone")
        val dir = File(root, "Download").apply { mkdir() }
        File(dir, "file.txt").writeText("streamed")
        val data = FolderArchive.stream(root, dir)!!.use { it.readBytes() }
        assertEquals("streamed", String(entries(data).getValue("Download/file.txt")))
    }

    @Test(timeout = 5000) fun cancellationReleasesBothDownloadSlots() {
        val root = tmp.newFolder("phone")
        val dir = File(root, "Download").apply { mkdir() }
        val data = ByteArray(512 * 1024).also { Random(42).nextBytes(it) }
        File(dir, "random.bin").writeBytes(data)
        val first = FolderArchive.stream(root, dir)!!
        val second = FolderArchive.stream(root, dir)!!
        try { assertNull(FolderArchive.stream(root, dir)) } finally { first.close(); second.close() }
        var next: java.io.InputStream? = null
        while (next == null) { Thread.sleep(10); next = FolderArchive.stream(root, dir) }
        val zip = entries(next.use { it.readBytes() })
        assertArrayEquals(data, zip["Download/random.bin"])
    }
}
