package com.example.httpsserver

import java.io.File
import java.io.IOException
import java.nio.file.Files
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FolderSizeTest {
    @get:Rule val tmp = TemporaryFolder()
    @Test fun countsNestedVisibleContentAndEmptyFiles() {
        val root=tmp.newFolder("storage");val dir=File(root,"Pictures").apply {mkdir()}
        File(dir,"photo.jpg").writeBytes(ByteArray(1024));File(dir,"sub").mkdir()
        File(dir,"sub/বাংলা.txt").writeBytes(ByteArray(3072));File(dir,"empty.txt").writeBytes(byteArrayOf())
        assertEquals(FolderSize.Result(4096,3),FolderSize.measure(root,dir))
        assertEquals(FolderSize.Result(0,0),FolderSize.measure(root,File(dir,"empty-folder").apply {mkdir()}))
    }
    @Test fun excludesHiddenAndSystemContentFromTotals() {
        val root=tmp.newFolder("storage");val dir=File(root,"Download").apply {mkdir()}
        File(dir,"keep.txt").writeBytes(ByteArray(17))
        for (name in listOf(".gs", ".gs_fs0", ".thumbnails", "Android", "LOST.DIR")) File(dir,"$name/secret.bin").apply {parentFile!!.mkdirs();writeBytes(ByteArray(4096))}
        File(dir,"desktop.ini").writeText("metadata")
        assertEquals(FolderSize.Result(17,1),FolderSize.measure(root,dir))
    }
    @Test fun skipsSymlinksAndRejectsProtectedRoots() {
        val root=tmp.newFolder("storage");val dir=File(root,"Shared").apply {mkdir()}
        File(dir,"keep.txt").writeText("abc")
        val outside=tmp.newFolder("outside");File(outside,"private").writeText("private")
        Files.createSymbolicLink(File(dir,"alias").toPath(),outside.toPath())
        Files.createSymbolicLink(File(dir,"cycle").toPath(),dir.toPath())
        assertEquals(FolderSize.Result(3,1),FolderSize.measure(root,dir))
        val hidden=File(root,".gs").apply {mkdir()}
        for (blocked in listOf(hidden,outside)) {
            try {FolderSize.measure(root,blocked);fail("Not shared")}
            catch (_: IllegalArgumentException) { }
        }
    }
    @Test fun boundedScanDoesNotReturnAPartialZero() {
        val root=tmp.newFolder("storage");val dir=File(root,"Large").apply {mkdir()}
        File(dir,"a.txt").writeText("data")
        try {FolderSize.measure(root,dir,maxEntries=1);fail("Should report incomplete")}
        catch (_: IOException) { }
    }
}
