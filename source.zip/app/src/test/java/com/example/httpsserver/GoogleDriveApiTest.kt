package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.*
import java.nio.file.Files
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34])
class GoogleDriveApiTest{
 private class Wire:DriveTransport{
  data class Request(val method:String,val url:String,val headers:Map<String,String>,val data:ByteArray?)
  val requests=mutableListOf<Request>();val replies=java.util.ArrayDeque<DriveReply>();var streamUrl="";var failOnRequest=0
  fun add(code:Int,text:String="",headers:Map<String,String> = emptyMap()){replies.add(DriveReply(code,text.toByteArray(),headers))}
  override fun request(method:String,url:String,headers:Map<String,String>,body:ByteArray?):DriveReply{requests.add(Request(method,url,headers,body));if(requests.size==failOnRequest)throw IOException("network dropped");return replies.removeFirst()}
  override fun stream(url:String,headers:Map<String,String>,out:OutputStream,check:(Int)->Unit){streamUrl=url;assertEquals("Bearer test-only",headers["Authorization"]);check(3);out.write(byteArrayOf(1,2,3))}
 }
 @Test fun paginatedListingIncludesFoldersAndEscapesPageToken(){val w=Wire();w.add(200,"""{"files":[{"id":"a","name":"z.txt","mimeType":"text/plain","size":"4"}],"nextPageToken":"next +/"}""");w.add(200,"""{"files":[{"id":"folder","name":"A","mimeType":"application/vnd.google-apps.folder"}]}""");val items=GoogleDriveApi("test-only",w).list("root");assertTrue(items.first().folder);assertEquals(2,w.requests.size);assertTrue(w.requests[1].url.contains("pageToken=next+%2B%2F"));assertEquals("Bearer test-only",w.requests[0].headers["Authorization"])}
 @Test fun resumableUploadRecoversOffsetAfterLostConnection(){val w=Wire();w.failOnRequest=2;w.add(200,"",mapOf("location" to "https://www.googleapis.com/upload/session"));w.add(308,"",mapOf("range" to "bytes=0-1"));w.add(200,"""{"id":"done","name":"a.txt","mimeType":"text/plain","size":"4"}""");val f=Files.createTempFile("drive-api",".txt").toFile();try{f.writeText("abcd");val item=GoogleDriveApi("test-only",w).upload("root","a.txt",f,"text/plain",{},{});assertEquals("done",item.id);assertEquals("bytes 2-3/4",w.requests.last().headers["Content-Range"]);assertEquals("cd",String(w.requests.last().data!!))}finally{f.delete()}}
 @Test fun untrustedUploadLocationIsRejectedBeforeSendingCredentials(){val w=Wire();w.add(200,"",mapOf("location" to "https://evil.example/upload"));val f=Files.createTempFile("drive-api",".txt").toFile();try{assertThrows(IllegalArgumentException::class.java){GoogleDriveApi("test-only",w).upload("root","a",f,"text/plain",{},{})};assertEquals(1,w.requests.size)}finally{f.delete()};assertFalse(DriveHttps.trusted("http://www.googleapis.com/a"));assertFalse(DriveHttps.trusted("https://www.googleapis.com.evil.example/a"))}
 @Test fun authorizationErrorsAreReadableAndDoNotExposeToken(){val w=Wire();w.add(401,"secret server body");val e=assertThrows(DriveFailure::class.java){GoogleDriveApi("test-only",w).list("root")};assertEquals(401,e.status);assertFalse(e.message!!.contains("test-only"));assertTrue(e.message!!.contains("expired"))}
 @Test fun googleWorkspaceExportDoesNotDownloadRawMetadata(){val w=Wire();val out=ByteArrayOutputStream();GoogleDriveApi("test-only",w).download(DriveItem("sheet","Budget","application/vnd.google-apps.spreadsheet"),out){};assertTrue(w.streamUrl.contains("/export?mimeType="));assertTrue(w.streamUrl.contains("spreadsheetml"));assertEquals(3,out.size())}
 @Test fun notesRemoteUsesAppDataSpaceAndWritesOnlyAppSpecificRevisions(){val w=Wire();w.add(200,"{\"files\":[]}");val remote=DriveNotesRemote("test-only",w);assertTrue(remote.read().isEmpty());assertTrue(w.requests.single().url.contains("spaces=appDataFolder"));w.add(200,"{\"id\":\"revision\"}");remote.write(NoteEvent("note-id","revision-id",emptyList(),"বাংলা","saved text",false));val sent=String(w.requests.last().data!!,Charsets.UTF_8);assertTrue(sent.contains("appDataFolder"));assertTrue(sent.contains("saved text"));assertFalse(sent.contains("refresh_token"))}

}
