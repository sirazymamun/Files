package com.example.httpsserver
import android.app.Activity
import android.content.Intent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Status
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowAlertDialog
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34])
class GoogleDriveAuthResultTest {
 private fun reply(activity:GoogleDriveActivity,result:Int,data:Intent?){GoogleDriveActivity::class.java.getDeclaredMethod("onActivityResult",Int::class.javaPrimitiveType,Int::class.javaPrimitiveType,Intent::class.java).apply{isAccessible=true}.invoke(activity,51,result,data)}
 private fun text(v:View):String = (if(v is TextView)v.text.toString()+"\n" else "")+(if(v is ViewGroup)(0 until v.childCount).joinToString(""){text(v.getChildAt(it))}else "")
 @Test fun cancelledActivityStillDecodesGoogleDeveloperError(){val c=Robolectric.buildActivity(GoogleDriveActivity::class.java).setup();try{var decoded=false;c.get().authorizationResultParser={decoded=true;throw ApiException(Status(10))};reply(c.get(),Activity.RESULT_CANCELED,Intent());assertTrue(decoded);val view=text(c.get().window.decorView);assertTrue(view.contains("Error 10"));assertFalse(view.contains("Connection cancelled"));val dialog=text(ShadowAlertDialog.getLatestAlertDialog().window!!.decorView);assertTrue(dialog.contains("OAuth configuration"));assertTrue(dialog.contains("SHA-1"))}finally{c.pause().stop().destroy()}}
 @Test fun missingReplyDoesNotBlameUserForCancellation(){val c=Robolectric.buildActivity(GoogleDriveActivity::class.java).setup();try{reply(c.get(),Activity.RESULT_CANCELED,null);val view=text(c.get().window.decorView);assertTrue(view.contains("did not complete"));assertFalse(view.contains("Connection cancelled"));val dialog=text(ShadowAlertDialog.getLatestAlertDialog().window!!.decorView);assertTrue(dialog.contains("exact cause is unavailable"));assertTrue(dialog.contains("Retry"))}finally{c.pause().stop().destroy()}}
 @Test fun successfulActivityWithGoogleFailureShowsSpecificNetworkError(){val c=Robolectric.buildActivity(GoogleDriveActivity::class.java).setup();try{c.get().authorizationResultParser={throw ApiException(Status(7))};reply(c.get(),Activity.RESULT_OK,Intent());assertTrue(text(ShadowAlertDialog.getLatestAlertDialog().window!!.decorView).contains("network error"))}finally{c.pause().stop().destroy()}}
}
