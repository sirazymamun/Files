package com.example.httpsserver
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.*
import java.io.File
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34])
class GoogleDriveUiTest{
 private fun find(v:View,text:String):View?{if(v is TextView && v.text.toString()==text)return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),text)}else null}
 @Test fun driveStartsWithExplicitConnectAndDoesNotAuthorizeByItself(){val c=Robolectric.buildActivity(GoogleDriveActivity::class.java).setup().visible();try{val decor=c.get().window.decorView;assertNotNull(find(decor,"Connect Google Drive"));assertNull(find(decor,"Upload files"));assertNotNull(find(decor,"My Drive"))}finally{c.pause().stop().destroy()}}
 @Test @Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi") @GraphicsMode(GraphicsMode.Mode.NATIVE)
 fun driveRowsRenderWithSelectionsFoldersAndFileTypes(){val c=Robolectric.buildActivity(GoogleDriveActivity::class.java).setup().visible();val a=c.get();try{a.getSharedPreferences("google-drive",0).edit().putString("account","demo@example.test").apply();val field=a.javaClass.getDeclaredField("items").apply{isAccessible=true};(a.javaClass.getDeclaredField("status").apply{isAccessible=true}.get(a) as TextView).text="Sample Drive · 3 items";field.set(a,listOf(DriveItem("f","Family photos","application/vnd.google-apps.folder"),DriveItem("p","Report.pdf","application/pdf",8192),DriveItem("s","Budget","application/vnd.google-apps.spreadsheet")));a.javaClass.getDeclaredMethod("bind").apply{isAccessible=true}.invoke(a);a.javaClass.getDeclaredMethod("controls").apply{isAccessible=true}.invoke(a);shadowOf(Looper.getMainLooper()).idle();val decor=a.window.decorView;assertNull(find(decor,"Upload files"));assertNull(find(decor,"Upload folder"));assertNull(find(decor,"Download"));decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480);assertNotNull(find(decor,"Report.pdf"));val out=File("build/interface-preview/Files-google-drive.png");out.parentFile!!.mkdirs();val b=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(b));out.outputStream().use{b.compress(Bitmap.CompressFormat.PNG,100,it)}}finally{a.getSharedPreferences("google-drive",0).edit().clear().apply();c.pause().stop().destroy()}}
}
