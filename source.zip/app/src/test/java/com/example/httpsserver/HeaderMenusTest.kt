package com.example.httpsserver
import android.Manifest
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowPopupMenu
import java.io.File
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34],shadows=[GrantedStorageEnvironment::class])
class HeaderMenusTest{
 @Test fun filesOverflowAccessibleNameMatchesArchiveAndHiddenSettingsTests(){
  storage()
  val c=Robolectric.buildActivity(FilesActivity::class.java).setup().visible()
  try {
   val more=find(c.get().window.decorView){it.contentDescription?.toString()=="More options"}
   assertNotNull("Files overflow must remain discoverable as More options",more)
   assertTrue(more is ImageButton)
   assertTrue(more!!.minimumWidth>=48*c.get().resources.displayMetrics.density)
   more.performClick()
   assertTrue(titles().contains("Display settings"))
  } finally { c.pause().stop().destroy() }
 }
 private fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
 private fun titles():List<String>{val menu=ShadowPopupMenu.getLatestPopupMenu().menu;return (0 until menu.size()).map{menu.getItem(it).title.toString()}}
 private fun storage():File{val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);return Environment.getExternalStorageDirectory().canonicalFile.apply{mkdirs()}}
 @Test fun driveUsesLargeOverflowIconAndOnlyRelevantConnectionActions(){val c=Robolectric.buildActivity(GoogleDriveActivity::class.java).setup().visible();val a=c.get();try{val more=find(a.window.decorView){it.contentDescription=="More options"}!!;assertTrue(more is ImageButton);assertTrue(more.minimumWidth>=48*a.resources.displayMetrics.density);more.performClick();assertEquals(listOf("Connect Google Drive"),titles());ShadowPopupMenu.getLatestPopupMenu().dismiss();a.getSharedPreferences("google-drive",0).edit().putString("account","sample@example.test").apply();more.performClick();assertEquals(listOf("Upload files / folders","Refresh","New Drive folder","Change account","Disconnect"),titles())}finally{a.getSharedPreferences("google-drive",0).edit().clear().apply();c.pause().stop().destroy()}}
 @Test fun notesOverflowOpensNewNoteAndChangesToEditorActions(){storage();val c=Robolectric.buildActivity(NotesActivity::class.java).setup().visible();try{val a=c.get();val more=find(a.window.decorView){it.contentDescription=="Notes options"}!!;assertTrue(more is ImageButton);more.performClick();assertEquals(listOf("New note","Refresh","Google Drive sync"),titles());ShadowPopupMenu.getLatestPopupMenu().menu.performIdentifierAction(0,0);shadowOf(Looper.getMainLooper()).idle();assertNotNull(find(a.window.decorView){it is EditText && it.hint=="Write your note…"});more.performClick();assertEquals(listOf("Share","Copy text","Save a copy","Google Drive sync"),titles())}finally{c.pause().stop().destroy()}}
 @Test fun filePreviewOverflowKeepsItsFileActions(){val root=storage();val f=File(root,"menu-preview.txt").apply{writeText("sample")};val app=RuntimeEnvironment.getApplication();app.getSharedPreferences("files-preview",0).edit().putString("root",root.path).putString("file",f.path).putString("siblings",JSONArray().put(f.path).toString()).apply();val c=Robolectric.buildActivity(FilesPreviewActivity::class.java).setup().visible();try{find(c.get().window.decorView){it.contentDescription=="More options"}!!.performClick();assertEquals(listOf("Properties","Share","Open with","Delete"),titles())}finally{c.pause().stop().destroy();f.delete()}}
}
