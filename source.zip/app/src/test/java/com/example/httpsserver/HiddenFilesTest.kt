package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files
class HiddenFilesTest{
 private fun fixture(block:(File)->Unit){val root=Files.createTempDirectory("hidden-files").toFile();try{block(root)}finally{root.deleteRecursively()}}
 @Test fun hiddenOptInDoesNotExposeSystemOrBin()=fixture{root->
  val hidden=File(root,".github/workflows/app-debug.yml").apply{parentFile!!.mkdirs();writeText("workflow")}
  assertNull(SharedFiles(root).resolve("/.github/workflows/app-debug.yml"));assertEquals(hidden,SharedFiles(root,true).resolve("/.github/workflows/app-debug.yml"));assertTrue(SharedFiles(root,true).visibleInListing(File(root,".github")))
  for(path in listOf("/Android/data","/.FilesTrash/payload","/LOST.DIR","/../outside"))assertNull(path,SharedFiles(root,true).resolve(path))
 }
 @Test fun nativeHiddenCopyZipAndRecycleRemainComplete()=fixture{root->
  val folder=File(root,".github").apply{mkdir()};File(folder,"workflow.yml").writeText("workflow");val dest=File(root,"Copy").apply{mkdir()};FileManagerOps(root,true).transfer(folder,dest,false);assertEquals("workflow",File(dest,".github/workflow.yml").readText())
  val zip=File(root,"github.zip");LocalArchives.compress(root,listOf(folder),zip,true);val out=File(root,"Extracted");LocalArchives.extract(root,zip,out,includeHidden=true);assertEquals("workflow",File(out,".github/workflow.yml").readText())
  val bin=TrashStore(root,true);val entry=bin.put(folder);assertFalse(folder.exists());assertTrue(bin.entries().any{it.id==entry.id});assertTrue(TrashStore(root).entries().none{it.id==entry.id});assertEquals(folder,bin.restore(entry));assertEquals("workflow",File(folder,"workflow.yml").readText())
 }
}
