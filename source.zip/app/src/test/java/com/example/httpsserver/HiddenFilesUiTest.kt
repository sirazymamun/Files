package com.example.httpsserver
import android.Manifest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.*
import org.robolectric.shadows.ShadowPopupMenu
import org.robolectric.shadows.ShadowAlertDialog
import java.io.File
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi",shadows=[GrantedStorageEnvironment::class])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class HiddenFilesUiTest{
 @Test fun displaySettingShowsGitHubAndHidingAgainReturnsToAllowedParent(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().apply{mkdirs()};val github=File(root,".github");File(github,"workflows/app-debug.yml").apply{parentFile!!.mkdirs();writeText("name: Build")}
  val c=Robolectric.buildActivity(FilesActivity::class.java).setup().visible();val decor=c.get().window.decorView
  fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
  fun pump(){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
  fun waitFor(label:String){val end=System.nanoTime()+5000000000;while(find(decor){it is TextView && it.text.toString()==label}==null && System.nanoTime()<end)pump();assertNotNull(label,find(decor){it is TextView && it.text.toString()==label})}
  fun toggle(){find(decor){it.contentDescription?.toString()=="More options"}!!.performClick();val menu=ShadowPopupMenu.getLatestPopupMenu().menu;val item=(0 until menu.size()).map{menu.getItem(it)}.first{it.title.toString()=="Display settings"};menu.performIdentifierAction(item.itemId,0);shadowOf(Looper.getMainLooper()).idle();val dialog=ShadowAlertDialog.getLatestAlertDialog();val list=dialog.listView;list.performItemClick(list.adapter.getView(1,null,list),1,1);dialog.getButton(-1).performClick();shadowOf(Looper.getMainLooper()).idle()}
  fun open(name:String){val list=find(decor){it is android.widget.ListView} as android.widget.ListView;val pos=(0 until list.adapter.count).first{(list.adapter.getItem(it) as File).name==name};list.onItemClickListener!!.onItemClick(list,list.getChildAt(pos),pos,pos.toLong())}
  try{var tile=find(decor){it.contentDescription?.toString()=="Main storage"}!!;while(!tile.hasOnClickListeners())tile=tile.parent as View;tile.performClick();waitFor("0 items");assertNull(find(decor){it is TextView && it.text.toString()==".github"});toggle();waitFor(".github");assertTrue(app.getSharedPreferences("files-manager",0).getBoolean("showHidden",false))
   val out=File("build/interface-preview/Files-hidden-github.png");out.parentFile!!.mkdirs();val bitmap=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(bitmap));out.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
   open(".github");waitFor("workflows");open("workflows");waitFor("app-debug.yml");toggle();waitFor("Main storage");waitFor("0 items");assertFalse(app.getSharedPreferences("files-manager",0).getBoolean("showHidden",true))
  }finally{c.pause().stop().destroy();github.deleteRecursively()}
 }
}
