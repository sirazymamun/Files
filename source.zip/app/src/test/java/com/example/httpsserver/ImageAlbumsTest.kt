package com.example.httpsserver
import android.content.ContentProvider
import android.content.ContentValues
import android.content.pm.ProviderInfo
import android.database.MatrixCursor
import android.net.Uri
import android.os.Build
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowContentResolver
import java.io.File
import java.nio.file.Files
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24,34])
class ImageAlbumsTest {
 data class Row(val file:File,val added:Long=1700000500,val pending:Int=0,val trashed:Int=0)
 class IndexProvider(val rows:List<Row>,val broken:Boolean=false):ContentProvider(){
  override fun onCreate()=true
  override fun query(uri:Uri,projection:Array<out String>?,selection:String?,args:Array<out String>?,order:String?):android.database.Cursor{
   if(broken)throw SecurityException("Test index unavailable")
   val cols=projection ?: arrayOf("_data","date_added","date_modified");return MatrixCursor(cols).apply{for(r in rows)addRow(cols.map{when(it){"_data"->r.file.path;"date_added"->r.added;"date_modified"->1700000000L;"is_pending"->r.pending;"is_trashed"->r.trashed;else->null}}.toTypedArray())}
  }
  override fun getType(uri:Uri)="image/png"
  override fun insert(uri:Uri,values:ContentValues?):Uri?=null
  override fun delete(uri:Uri,selection:String?,args:Array<out String>?)=0
  override fun update(uri:Uri,values:ContentValues?,selection:String?,args:Array<out String>?)=0
 }
 private fun install(rows:List<Row>,broken:Boolean=false){val app=RuntimeEnvironment.getApplication();val provider=IndexProvider(rows,broken);provider.attachInfo(app,ProviderInfo().apply{authority="media";exported=true});ShadowContentResolver.registerProviderInternal("media",provider)}
 private fun image(root:File,path:String,time:Long=1700000000000)=File(root,path).apply{parentFile!!.mkdirs();writeText("image bytes");setLastModified(time)}
 @Test fun indexAndUnindexedScreenshotsMergeAcrossSharedStorage(){
  val root=Files.createTempDirectory("photo-primary").toFile();val sd=Files.createTempDirectory("photo-sd").toFile()
  try{
   val old=image(root,"Pictures/Screenshots/old.png");val newest=image(root,"Pictures/Screenshots/new.png",1700001000000)
   image(root,"DCIM/Camera/photo.jpg");image(sd,"DCIM/Camera/other.jpg");val whatsapp=image(root,"Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/photo.webp");image(root,"Snapseed/edit.jpg");image(root,"Android/data/private/no.jpg");image(root,"Android/obb/private/no.jpg");image(root,".FilesTrash/no.jpg");image(root,"Pictures/.hidden/no.jpg")
   val pending=image(root,"Pictures/Pending/unfinished.png");install(listOf(Row(old),Row(whatsapp),Row(pending,pending=1)))
   var initial:ImageAlbums.Result?=null;val result=ImageAlbums.scan(RuntimeEnvironment.getApplication(),listOf(root,sd),false,indexed={initial=it})
   assertNotNull(initial);assertTrue(initial!!.photos>=2);val shots=result.albums.first{it.name=="Screenshots"};assertEquals(listOf(newest,old),shots.photos.map{it.file});assertEquals(2,result.albums.count{it.name=="Camera"});assertTrue(result.albums.any{it.name=="WhatsApp Images"});assertTrue(result.albums.any{it.name=="Snapseed"});assertEquals(if(Build.VERSION.SDK_INT>=29)6 else 7,result.photos);assertFalse(result.albums.flatMap{it.photos}.any{it.file.path.contains("/Android/data/") || it.file.path.contains("/.FilesTrash/") || it.file.path.contains("/.hidden/")});assertFalse(result.partial)
   assertEquals(2,ImageAlbums.albumPhotos(root,shots.folder,false,shots.photos).size)
  }finally{root.deleteRecursively();sd.deleteRecursively()}
 }
 @Test fun unavailableIndexFallsBackAndRecentAlbumRefreshes(){
  val root=Files.createTempDirectory("photo-fallback").toFile();try{install(emptyList(),true);val first=image(root,"DCIM/Screenshots/first.jpg");val result=ImageAlbums.scan(RuntimeEnvironment.getApplication(),listOf(root),false);assertEquals(1,result.photos);val recent=image(root,"DCIM/Screenshots/latest.png",1700001000000);assertEquals(listOf(recent,first),ImageAlbums.albumPhotos(root,first.parentFile!!,false).map{it.file});val empty=ImageAlbums.scan(RuntimeEnvironment.getApplication(),listOf(root),false,cancelled={true});assertEquals(0,empty.photos)}finally{root.deleteRecursively()}
 }
 @Test fun sharedAppMediaSupportsPreviewOperationsWithoutPrivateAccess(){
  val root=Files.createTempDirectory("app-media").toFile();try{val file=image(root,"Android/media/org.example/Photos/photo.jpg");assertEquals(file,FileManagerOps(root).checked(file));assertNull(SharedFiles(root).resolve("Android"));assertFalse(SharedFiles(root).allowedPart("Android"));assertNull(SharedFiles(root).resolve("Android/data/org.example/private.jpg"));val bin=TrashStore(root);val entry=bin.put(file);assertFalse(file.exists());assertEquals(file,bin.restore(entry));val zip=File(root,"photos.zip");LocalArchives.compress(root,listOf(file.parentFile!!),zip);assertTrue(zip.length()>0)}finally{root.deleteRecursively()}
 }
}
