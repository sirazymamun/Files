package com.example.httpsserver
import android.Manifest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.*
import java.io.File
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi",shadows=[GrantedStorageEnvironment::class])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ImageAlbumsUiTest {
 @Test fun albumsShowPublicAppPhotosRecentScreenshotsAndDocumentTypes(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().apply{mkdirs()}
  fun photo(path:String,color:Int,time:Long):File=File(root,path).apply{parentFile!!.mkdirs();outputStream().use{out->Bitmap.createBitmap(120,80,Bitmap.Config.ARGB_8888).apply{eraseColor(color)}.compress(Bitmap.CompressFormat.PNG,100,out)};setLastModified(time)}
  val old=photo("Pictures/Screenshots/old.png",Color.BLUE,1700000000000);val latest=photo("Pictures/Screenshots/latest.png",Color.GREEN,1700001000000);val camera=photo("DCIM/Camera/camera.jpg",Color.rgb(225,150,80),1700000000000);val whatsapp=photo("Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/chat.png",Color.rgb(30,140,145),1700000500000)
  val documents=File(root,"Documents").apply{mkdirs()};for(name in listOf("Document.docx","Report.pdf","Sheet.xlsx","Slides.pptx","Notes.txt"))File(documents,name).writeText("fixture document")
  val c=Robolectric.buildActivity(FilesActivity::class.java).setup().visible();val a=c.get();val decor=a.window.decorView
  fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
  fun pump(){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
  fun waitText(value:String){val end=System.nanoTime()+5000000000;while(find(decor){it is TextView && it.text.toString()==value}==null && System.nanoTime()<end)pump();assertNotNull(value,find(decor){it is TextView && it.text.toString()==value})}
  fun tile(name:String){var v=find(decor){it.contentDescription?.toString()==name}!!;while(!v.hasOnClickListeners())v=v.parent as View;v.performClick()}
  fun save(name:String){pump();val bitmap=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(bitmap));val out=File("build/interface-preview/$name.png");out.parentFile!!.mkdirs();out.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}}
  var added:File?=null
  try{
   tile("Images");waitText("Screenshots (2)");waitText("WhatsApp Images (1)");waitText("Camera (1)");assertNull(find(decor){it is android.widget.CheckBox})
   val grid=find(decor){it is android.widget.GridView} as android.widget.GridView;val position=(0 until grid.adapter.count).first{(grid.adapter.getItem(it) as ImageAlbums.Album).name=="Screenshots"};grid.onItemClickListener!!.onItemClick(grid,grid.getChildAt(position),position,position.toLong());waitText("latest.png")
   var list=find(decor){it is android.widget.ListView} as android.widget.ListView;assertEquals(latest,list.adapter.getItem(0))
   added=photo("Pictures/Screenshots/just-taken.png",Color.MAGENTA,System.currentTimeMillis());c.pause().resume().visible();waitText("just-taken.png");list=find(decor){it is android.widget.ListView} as android.widget.ListView;assertEquals(added,list.adapter.getItem(0))
   a.onBackPressed();waitText("Screenshots (3)");save("Files-image-albums")
   a.onBackPressed();waitText("Files");tile("Documents");waitText("Report.pdf");waitText("Sheet.xlsx");save("Files-document-types")
   val icon=find(decor){it is android.widget.ImageView && it.contentDescription?.toString()=="Documents"};assertNotNull(icon)
  }finally{c.pause().stop().destroy();old.parentFile!!.deleteRecursively();camera.parentFile!!.deleteRecursively();File(root,"Android/media/com.whatsapp").deleteRecursively();documents.deleteRecursively();added?.delete()}
 }
}
