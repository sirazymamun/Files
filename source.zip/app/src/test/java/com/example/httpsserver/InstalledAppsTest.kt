package com.example.httpsserver
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.nio.file.Files
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24,34])
class InstalledAppsTest{
 @org.junit.Before @org.junit.After fun clearProviderCache(){val f=androidx.core.content.FileProvider::class.java.getDeclaredField("sCache").apply{isAccessible=true};(f.get(null) as MutableMap<*,*>).clear()}

 @Suppress("DEPRECATION") private fun fixture(root:File,pkg:String,name:String,system:Boolean=false,updated:Boolean=false,split:Boolean=false):PackageInfo{
  val base=File(root,pkg+".apk").apply{writeText("APK sample data for $name")};val extra=if(split)File(root,pkg+".split.apk").apply{writeText("SPLIT config data")}else null
  return PackageInfo().apply{packageName=pkg;versionName="2.4.0";versionCode=24;firstInstallTime=1700000000000;lastUpdateTime=1700005000000;applicationInfo=ApplicationInfo().apply{packageName=pkg;nonLocalizedLabel=name;sourceDir=base.path;publicSourceDir=base.path;splitSourceDirs=extra?.let{arrayOf(it.path)};flags=(if(system)ApplicationInfo.FLAG_SYSTEM else 0) or (if(updated)ApplicationInfo.FLAG_UPDATED_SYSTEM_APP else 0);enabled=true;icon=R.mipmap.ic_launcher}}
 }
 private fun find(view:View,predicate:(View)->Boolean):View?{if(predicate(view))return view;return if(view is ViewGroup)(0 until view.childCount).firstNotNullOfOrNull{find(view.getChildAt(it),predicate)}else null}
 @Test fun downloadedAndAllHaveCorrectAppTypes(){val root=Files.createTempDirectory("installed-apps").toFile();val app=RuntimeEnvironment.getApplication();try{val packages=listOf(fixture(root,"fixture.player","Sample Player",split=true),fixture(root,"fixture.system","System Tool",system=true),fixture(root,"fixture.updated","Updated Tool",system=true,updated=true));packages.forEach{shadowOf(app.packageManager).installPackage(it)};val rows=InstalledApps.list(app).filter{it.packageName.startsWith("fixture.")};assertEquals(3,rows.size);assertEquals(2,rows.count{it.downloaded});val row=rows.first{it.packageName=="fixture.player"};assertEquals(2,row.parts);assertTrue(row.apkBytes!!>0);assertEquals("2.4.0",row.version);assertEquals(24L,row.versionCode);assertFalse(rows.first{it.packageName=="fixture.system"}.canUninstall);val snapshot=InstalledApps.snapshot(app,"fixture.player");assertEquals(2,snapshot.sources.size);assertTrue(InstalledApps.sameVersion(app,snapshot))}finally{root.deleteRecursively()}}
 @Test fun selectionShowsActionsAndSystemUninstallIntent(){val root=Files.createTempDirectory("installed-actions").toFile();val app=RuntimeEnvironment.getApplication();shadowOf(app.packageManager).installPackage(fixture(root,"fixture.player","Sample Player",split=true));val controller=Robolectric.buildActivity(InstalledAppsActivity::class.java).setup().visible();val activity=controller.get();val decor=activity.window.decorView;try{
  val deadline=System.nanoTime()+5000000000;while(find(decor){it is TextView && it.text.toString()=="Sample Player"}==null && System.nanoTime()<deadline){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
  val item=find(decor){it is TextView && it.text.toString()=="Sample Player"};assertNotNull(item)
  val list=find(decor){it is android.widget.ListView} as android.widget.ListView;val position=(0 until list.adapter.count).first{(list.adapter.getItem(it) as InstalledApps.App).packageName=="fixture.player"};list.onItemLongClickListener.onItemLongClick(list,list.getChildAt(position),position,position.toLong());shadowOf(Looper.getMainLooper()).idle()
  for(action in listOf("Backup","Uninstall","Share","Open","Store"))assertNotNull(find(decor){it.contentDescription?.toString()==action})
  find(decor){it.contentDescription?.toString()=="Uninstall"}!!.performClick();val intent=shadowOf(activity).nextStartedActivityForResult.intent;assertEquals(android.content.Intent.ACTION_UNINSTALL_PACKAGE,intent.action);assertEquals("package:fixture.player",intent.dataString);assertTrue(intent.getBooleanExtra(android.content.Intent.EXTRA_RETURN_RESULT,false))
 }finally{controller.pause().stop().destroy();root.deleteRecursively()}}
 @Test @Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi") @GraphicsMode(GraphicsMode.Mode.NATIVE)
 fun installedAppScreenRenders(){val root=Files.createTempDirectory("apps-render").toFile();val app=RuntimeEnvironment.getApplication();for((pkg,name)in listOf("fixture.reader" to "Document Reader","fixture.player" to "Sample Player","fixture.notes" to "Notes"))shadowOf(app.packageManager).installPackage(fixture(root,pkg,name,split=pkg.endsWith("player")));val controller=Robolectric.buildActivity(InstalledAppsActivity::class.java).setup().visible();val decor=controller.get().window.decorView;try{val end=System.nanoTime()+5000000000;while(find(decor){it is TextView&&it.text.toString()=="Sample Player"}==null&&System.nanoTime()<end){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)};assertNotNull(find(decor){it is TextView&&it.text.toString()=="Sample Player"});val output=File("build/interface-preview/Files-apps.png");output.parentFile!!.mkdirs();val bitmap=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(bitmap));output.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
 val list=find(decor){it is android.widget.ListView} as android.widget.ListView;val position=(0 until list.adapter.count).first{(list.adapter.getItem(it) as InstalledApps.App).packageName=="fixture.player"};list.onItemLongClickListener.onItemLongClick(list,list.getChildAt(position),position,position.toLong());shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480);decor.draw(Canvas(bitmap));File(output.parentFile,"Files-apps-selection.png").outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
 }finally{controller.pause().stop().destroy();root.deleteRecursively()}}
 @Test @Config(sdk=[24,34]) fun splitShareUsesReadOnlyProviderAndIncludesAllParts(){
  val root=Files.createTempDirectory("apps-share").toFile();val app=RuntimeEnvironment.getApplication();shadowOf(app.packageManager).installPackage(fixture(root,"fixture.share","Share Sample",split=true));val controller=Robolectric.buildActivity(InstalledAppsActivity::class.java).setup().visible();val activity=controller.get();val decor=activity.window.decorView
  try{
   fun pump(){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
   val deadline=System.nanoTime()+5000000000;while(find(decor){it is TextView&&it.text.toString()=="Share Sample"}==null && System.nanoTime()<deadline)pump()
   val list=find(decor){it is android.widget.ListView} as android.widget.ListView;val position=(0 until list.adapter.count).first{(list.adapter.getItem(it) as InstalledApps.App).packageName=="fixture.share"};list.onItemLongClickListener.onItemLongClick(list,list.getChildAt(position),position,position.toLong());find(decor){it.contentDescription?.toString()=="Share"}!!.performClick()
   val end=System.nanoTime()+5000000000;var chooser:android.content.Intent?=null;while(chooser==null && System.nanoTime()<end){pump();chooser=shadowOf(activity).nextStartedActivity}
   assertEquals(android.content.Intent.ACTION_CHOOSER,chooser!!.action)
   @Suppress("DEPRECATION") val send=chooser!!.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_INTENT)!!
   assertEquals(android.content.Intent.ACTION_SEND_MULTIPLE,send.action);assertEquals("application/vnd.android.package-archive",send.type);assertTrue(send.flags and android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION!=0);assertEquals(0,send.flags and android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
   @Suppress("DEPRECATION") val uris=send.getParcelableArrayListExtra<android.net.Uri>(android.content.Intent.EXTRA_STREAM)!!;assertEquals(2,uris.size);assertEquals(2,send.clipData!!.itemCount)
   val contents=uris.map{uri->assertEquals("content",uri.scheme);activity.contentResolver.openInputStream(uri)!!.use{it.readBytes().toString(Charsets.UTF_8)}}
   assertEquals(setOf("APK sample data for Share Sample","SPLIT config data"),contents.toSet())

  }finally{controller.pause().stop().destroy();root.deleteRecursively()}
 }
 @Test @Config(sdk=[24,34]) fun multipleAppsShareEverySeparateApkPart(){
  val root=Files.createTempDirectory("apps-multiple-share").toFile();val app=RuntimeEnvironment.getApplication()
  shadowOf(app.packageManager).installPackage(fixture(root,"fixture.multi.split","Split App",split=true));shadowOf(app.packageManager).installPackage(fixture(root,"fixture.multi.single","Single App"))
  val controller=Robolectric.buildActivity(InstalledAppsActivity::class.java).setup().visible();val activity=controller.get();val decor=activity.window.decorView
  try{
   fun pump(){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
   val end=System.nanoTime()+5000000000;while(find(decor){it is TextView && it.text.toString()=="Split App"}==null && System.nanoTime()<end)pump()
   val list=find(decor){it is android.widget.ListView} as android.widget.ListView
   for(pkg in listOf("fixture.multi.single","fixture.multi.split")){val position=(0 until list.adapter.count).first{(list.adapter.getItem(it) as InstalledApps.App).packageName==pkg};list.onItemLongClickListener.onItemLongClick(list,list.getChildAt(position),position,position.toLong())}
   find(decor){it.contentDescription?.toString()=="Share"}!!.performClick()
   var chooser:android.content.Intent?=null;val deadline=System.nanoTime()+5000000000;while(chooser==null && System.nanoTime()<deadline){pump();chooser=shadowOf(activity).nextStartedActivity}
   assertNotNull("Share chooser did not start",chooser);assertEquals(android.content.Intent.ACTION_CHOOSER,chooser!!.action)
   @Suppress("DEPRECATION") val send=chooser.getParcelableExtra<android.content.Intent>(android.content.Intent.EXTRA_INTENT)!!
   assertEquals(android.content.Intent.ACTION_SEND_MULTIPLE,send.action);assertEquals("application/vnd.android.package-archive",send.type);assertEquals(3,send.clipData!!.itemCount);assertTrue(send.flags and android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION!=0);assertEquals(0,send.flags and android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
   @Suppress("DEPRECATION") val uris=send.getParcelableArrayListExtra<android.net.Uri>(android.content.Intent.EXTRA_STREAM)!!;assertEquals(3,uris.size)
   val data=uris.map{activity.contentResolver.openInputStream(it)!!.use{input->input.readBytes()}}
   assertEquals(setOf("APK sample data for Single App","APK sample data for Split App","SPLIT config data"),data.map{String(it,Charsets.UTF_8)}.toSet())

  }finally{controller.pause().stop().destroy();root.deleteRecursively()}
 }
}
