package com.example.httpsserver

import android.Manifest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi",shadows=[GrantedStorageEnvironment::class])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class InterfaceRenderTest {
 private fun find(view:View,predicate:(View)->Boolean):View?{if(predicate(view))return view;return if(view is ViewGroup)(0 until view.childCount).firstNotNullOfOrNull{find(view.getChildAt(it),predicate)}else null}
 private fun save(view:View,name:String){
  view.forceLayout();view.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));view.layout(0,0,720,1480)
  val bitmap=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);view.draw(Canvas(bitmap));val output=File("build/interface-preview/$name.png");output.parentFile!!.mkdirs();output.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
 }
 @Test fun homeAndDrawerRenderWithCompactIconGrid(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);Environment.getExternalStorageDirectory().mkdirs()
  val controller=Robolectric.buildActivity(FilesActivity::class.java).setup().visible();val activity=controller.get();val decor=activity.window.decorView
  try{
   shadowOf(Looper.getMainLooper()).idle();save(decor,"Files-home")
   val main=find(decor){it is TextView && it.text.toString()=="Main storage"};assertNotNull(main)
   assertNull(find(decor){it is TextView && it.visibility==View.VISIBLE && it.text.toString()=="On this device"})
   val menu=find(decor){it.contentDescription?.toString()=="Open menu"};assertNotNull(menu);menu!!.performClick();shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1));save(decor,"Files-drawer")
   assertNotNull(find(decor){it is TextView && it.text.toString()=="Recycle Bin"})
   activity.onBackPressed();assertFalse("Back must close the drawer, not finish Files",activity.isFinishing);(find(decor){it is androidx.drawerlayout.widget.DrawerLayout} as androidx.drawerlayout.widget.DrawerLayout).closeDrawer(android.view.Gravity.LEFT,false);shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1))
   val root=Environment.getExternalStorageDirectory();File(root,"Documents").mkdirs();File(root,"notes.txt").writeText("A sample document for the interface preview.")
   var tile=find(decor){it.contentDescription?.toString()=="Main storage"}!!
   while(!tile.hasOnClickListeners())tile=tile.parent as View
   tile.performClick()
   val deadline=System.currentTimeMillis()+3000
   while(find(decor){it is TextView && it.text.toString()=="notes.txt"}==null && System.currentTimeMillis()<deadline){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
   save(decor,"Files-list")
   fun description(v:View):String=(if(v is TextView)"[${v.text}]" else if(v is android.widget.AbsListView)"[list=${v.count},children=${v.childCount},size=${v.width}x${v.height}]" else "")+(if(v is ViewGroup)(0 until v.childCount).joinToString{description(v.getChildAt(it))}else "")
   assertNotNull(description(decor),find(decor){it is TextView && it.text.toString()=="notes.txt"})
  }finally{controller.pause().stop().destroy()}
 }
}
