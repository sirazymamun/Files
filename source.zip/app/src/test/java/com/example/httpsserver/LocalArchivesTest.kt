package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.EncryptionMethod
class LocalArchivesTest{
 private fun run(block:(File)->Unit){val r=Files.createTempDirectory("files-archive").toFile();try{block(r)}finally{r.deleteRecursively()}}
 @Test fun zipRoundTripMultipleFilesAndEmptyFolder()=run{r->val folder=File(r,"Folder").apply{mkdir()};File(folder,"empty").mkdir();File(folder,"বাংলা.txt").writeText("hello");val file=File(r,"zero.txt").apply{writeText("")};val zip=File(r,"sample.zip");assertEquals(2,LocalArchives.compress(r,listOf(folder,file),zip));val out=File(r,"extracted");assertEquals(2,LocalArchives.extract(r,zip,out));assertEquals("hello",File(out,"Folder/বাংলা.txt").readText());assertTrue(File(out,"Folder/empty").isDirectory);assertTrue(File(out,"zero.txt").isFile)}
 @Test fun unsafeEntryRefusesWholeExtraction()=run{r->val zip=File(r,"bad.zip");ZipOutputStream(zip.outputStream()).use{it.putNextEntry(ZipEntry("../outside.txt"));it.write(1);it.closeEntry()};assertThrows(IllegalArgumentException::class.java){LocalArchives.extract(r,zip,File(r,"out"))};assertFalse(File(r,"out").exists());assertFalse(File(r,"outside.txt").exists())}
 @Test fun destinationNeverOverwritten()=run{r->val f=File(r,"x.txt").apply{writeText("x")};val zip=File(r,"a.zip");LocalArchives.compress(r,listOf(f),zip);val out=File(r,"out").apply{mkdir()};File(out,"x.txt").writeText("old");assertThrows(IllegalArgumentException::class.java){LocalArchives.extract(r,zip,out)};assertEquals("old",File(out,"x.txt").readText())}
 @Test fun aesPasswordZipWorksAndWrongPasswordRollsBack()=run{r->val f=File(r,"secret.txt").apply{writeText("test secret")};val zip=File(r,"encrypted.zip");ZipFile(zip,"password".toCharArray()).use{it.addFile(f,ZipParameters().apply{isEncryptFiles=true;encryptionMethod=EncryptionMethod.AES})};assertThrows(java.io.IOException::class.java){LocalArchives.extract(r,zip,File(r,"wrong"),"bad")};assertFalse(File(r,"wrong").exists());LocalArchives.extract(r,zip,File(r,"ok"),"password");assertEquals("test secret",File(r,"ok/secret.txt").readText())}
 @Test fun actualRar4AndRar5Extract()=run{r->for(name in listOf("rar4.rar","rar5.rar")){val rar=File(r,name);javaClass.getResourceAsStream("/archives/$name")!!.use{input->rar.outputStream().use{input.copyTo(it)}};assertTrue(LocalArchives.entries(rar).isNotEmpty());val out=File(r,name+" extracted");assertTrue(LocalArchives.extract(r,rar,out)>0);assertTrue(out.walkTopDown().any{it.isFile && it.length()>0})}}
 @Test fun projectDotfilesRoundTripWithoutBecomingVisible()=run{r->
  val project=File(r,"Project").apply{mkdir()};val workflow=File(project,".github/workflows").apply{mkdirs()};File(workflow,"app-debug.yml").writeText("name: Build");File(project,".gitignore").writeText("build/")
  val zip=File(r,"project.zip");assertEquals(2,LocalArchives.compress(r,listOf(project),zip));val out=File(r,"Extracted");assertEquals(2,LocalArchives.extract(r,zip,out));assertEquals("name: Build",File(out,"Project/.github/workflows/app-debug.yml").readText());assertNull(SharedFiles(r).resolve("/Extracted/Project/.github/workflows/app-debug.yml"))
 }
 @Test fun protectedChildrenAndLinksStillRefused()=run{r->
  val folder=File(r,"Folder").apply{mkdir()};File(folder,".FilesTrash").mkdir();assertThrows(IllegalArgumentException::class.java){LocalArchives.compress(r,listOf(folder),File(r,"bad.zip"))};assertFalse(File(r,"bad.zip").exists())
  File(folder,".FilesTrash").delete();val target=File(r,"real.txt").apply{writeText("data")};Files.createSymbolicLink(File(folder,"shortcut").toPath(),target.toPath());assertThrows(IllegalArgumentException::class.java){LocalArchives.compress(r,listOf(folder),File(r,"linked.zip"))}
 }
 @Test fun windowsMetadataAndPackageNamedFoldersExtractSafely()=run{r->
  // Common ZIP entry names are not the same thing as protected storage paths.
  val archive=File(r,"windows-runtime.zip")
  val items=linkedMapOf(
   "runtime/desktop.ini" to "desktop metadata",
   "runtime/Thumbs.db" to "thumbnail cache",
   "runtime/Android/lib/example.so" to "library",
   "runtime/LOST.DIR/data.bin" to "data",
   "runtime/System Volume Information/info.txt" to "info"
  )
  ZipOutputStream(archive.outputStream()).use{out->items.forEach{(path,body)->
   out.putNextEntry(ZipEntry(path));out.write(body.toByteArray());out.closeEntry()
  }}
  val folder=File(r,"extracted")
  assertEquals(items.size,LocalArchives.extract(r,archive,folder))
  items.forEach{(path,body)->assertEquals(body,File(folder,path).readText())}
 }
 @Test fun protectedStorageRootAndTrashAreStillRefused()=run{r->
  val archive=File(r,"safe.zip")
  ZipOutputStream(archive.outputStream()).use{out->out.putNextEntry(ZipEntry("normal.txt"));out.write(1);out.closeEntry()}
  assertThrows(IllegalArgumentException::class.java){LocalArchives.extract(r,archive,File(r,"Android/data/private"))}
  assertThrows(IllegalArgumentException::class.java){LocalArchives.extract(r,archive,File(r,"LOST.DIR/injected"))}
  val malicious=File(r,"trash.zip")
  ZipOutputStream(malicious.outputStream()).use{out->out.putNextEntry(ZipEntry("folder/.FilesTrash/item"));out.write(1);out.closeEntry()}
  assertThrows(IllegalArgumentException::class.java){LocalArchives.extract(r,malicious,File(r,"output"))}
  assertFalse(File(r,"output").exists())
 }

}
