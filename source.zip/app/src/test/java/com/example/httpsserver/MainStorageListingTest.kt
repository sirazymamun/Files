package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files

class MainStorageListingTest {
    private fun sandbox(run:(File)->Unit) {
        val root=Files.createTempDirectory("storage-listing").toFile()
        try{run(root)}finally{root.deleteRecursively()}
    }

    @Test fun rootShowsEmptyOrdinaryFoldersAndAndroidShell()=sandbox { root ->
        listOf("Alarms","Audiobooks","Music","Notifications","Podcasts","Recordings","Ringtones","Download").forEach { File(root,it).mkdir() }
        File(root,"Android/media").mkdirs()
        File(root,"Android/data/private").mkdirs()
        File(root,".FilesTrash").mkdirs()
        File(root,"LOST.DIR").mkdir()
        val names=MainStorageListing.children(root,root,SharedFiles(root),false).map{it.name}
        assertTrue(names.containsAll(listOf("Alarms","Audiobooks","Music","Notifications","Podcasts","Recordings","Ringtones","Download","Android")))
        assertFalse(names.contains(".FilesTrash"))
        assertFalse(names.contains("LOST.DIR"))
    }

    @Test fun androidNavigationOnlyShowsSharedMedia()=sandbox { root ->
        val android=File(root,"Android").apply{mkdir()}
        File(android,"media").mkdir()
        File(android,"data").mkdir()
        File(android,"obb").mkdir()
        val policy=SharedFiles(root)
        assertTrue(MainStorageListing.browseable(root,android,policy))
        assertEquals(listOf("media"),MainStorageListing.children(root,android,policy,false).map{it.name})
        assertNull(policy.resolve("Android/data/private"))
        assertNull(policy.resolve("Android/obb/private"))
    }

    @Test fun hideEmptyCanStillBeEnabledByUser()=sandbox { root ->
        File(root,"Alarms").mkdir()
        File(root,"Download").apply{mkdir();File(this,"readme.txt").writeText("ok")}
        val names=MainStorageListing.children(root,root,SharedFiles(root),true).map{it.name}
        assertEquals(listOf("Download"),names)
    }
}
