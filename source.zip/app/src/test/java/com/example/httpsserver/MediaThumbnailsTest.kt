package com.example.httpsserver
import android.Manifest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.media.ThumbnailUtils
import android.os.CancellationSignal
import android.os.Environment
import android.os.Looper
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.*
import java.io.File
import java.nio.file.Files

@Implements(ThumbnailUtils::class)
class ControlledVideoThumbnails{
 companion object{
  var calls=0;var fail=false;var during:(()->Unit)?=null;var modern=false;var signal:CancellationSignal?=null
  @JvmStatic @Resetter fun reset(){calls=0;fail=false;during=null;modern=false;signal=null}
  private fun frame(path:String):Bitmap{calls++;during?.invoke();if(fail)throw IllegalArgumentException("Unsupported test codec");val portrait=path.contains("portrait",true);return Bitmap.createBitmap(if(portrait)450 else 800,if(portrait)800 else 450,Bitmap.Config.ARGB_8888).apply{eraseColor(Color.rgb(28,130,148));val canvas=Canvas(this);val paint=android.graphics.Paint().apply{color=Color.rgb(242,171,72)};canvas.drawRect(0f,0f,width*.42f,height.toFloat(),paint);paint.color=Color.WHITE;paint.strokeWidth=12f;canvas.drawLine(0f,height.toFloat(),width.toFloat(),0f,paint)}}
  @JvmStatic @Implementation(maxSdk=28) fun createVideoThumbnail(path:String,kind:Int):Bitmap?=frame(path)
  @JvmStatic @Implementation(minSdk=29) fun createVideoThumbnail(file:File,size:Size,cancellation:CancellationSignal?):Bitmap{modern=true;signal=cancellation;return frame(file.path)}
 }
}
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24,34],shadows=[ControlledVideoThumbnails::class,GrantedStorageEnvironment::class])
class MediaThumbnailsTest{
 @org.junit.Before fun reset(){ControlledVideoThumbnails.reset()}
 private fun fixture(block:(File,File)->Unit){val root=Files.createTempDirectory("video-thumbs").toFile();try{block(root,File(root,"movie.MOV").apply{writeText("test video")})}finally{root.deleteRecursively()}}
 @Test fun videoFramesAreBoundedCachedAndInvalidated()=fixture{root,video->val loader=MediaThumbnails();try{val first=loader.load(root,video)!!;assertEquals(256,first.width);assertEquals(144,first.height);assertSame(first,loader.load(root,video));assertEquals(1,ControlledVideoThumbnails.calls);assertEquals(android.os.Build.VERSION.SDK_INT>=29,ControlledVideoThumbnails.modern);video.appendText("changed");assertNotNull(loader.load(root,video));assertEquals(2,ControlledVideoThumbnails.calls)}finally{loader.close()}}
 @Test fun unavailableVideoKeepsFallbackAndProtectedPathsStayBlocked()=fixture{root,video->val loader=MediaThumbnails();try{ControlledVideoThumbnails.fail=true;assertNull(loader.load(root,video));val blocked=File(root,"Android/private.mp4").apply{parentFile!!.mkdirs();writeText("video")};assertNull(loader.load(root,blocked));assertEquals(1,ControlledVideoThumbnails.calls)}finally{loader.close()}}
 @Test fun closingDropsPendingResultAndCancelsModernDecoder()=fixture{root,video->val loader=MediaThumbnails();ControlledVideoThumbnails.during={loader.close()};assertNull(loader.load(root,video));if(android.os.Build.VERSION.SDK_INT>=29)assertTrue(ControlledVideoThumbnails.signal!!.isCanceled);assertNull(loader.load(root,video));assertEquals(1,ControlledVideoThumbnails.calls)}
 @Test @Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi") @GraphicsMode(GraphicsMode.Mode.NATIVE)
 fun nativeVideoRowUsesFrameThumbnail(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().apply{mkdirs()};val video=File(root,"Sample-video.mp4").apply{writeText("test codec fixture")}
  val portrait=File(root,"Portrait-video.mp4").apply{writeText("portrait codec fixture")};val photo=File(root,"Photo.png").apply{outputStream().use{out->Bitmap.createBitmap(800,450,Bitmap.Config.ARGB_8888).apply{eraseColor(Color.rgb(180,75,100))}.compress(Bitmap.CompressFormat.PNG,100,out)}};val document=File(root,"Document.txt").apply{writeText("document preview")};val archive=File(root,"Archive.zip").apply{writeText("archive icon")};val folder=File(root,"Folder").apply{mkdir()};File(folder,"note.txt").writeText("folder content");val other=File(root,"Other.bin").apply{writeText("other icon")}
  val controller=Robolectric.buildActivity(FilesActivity::class.java).setup().visible();val decor=controller.get().window.decorView
  fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
  fun layout(){decor.forceLayout();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480)}
  try{var tile=find(decor){it.contentDescription?.toString()=="Main storage"}!!;while(!tile.hasOnClickListeners())tile=tile.parent as View;tile.performClick();val deadline=System.nanoTime()+5000000000;var row:View?=null;while(row==null && System.nanoTime()<deadline){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();layout();row=find(decor){it is ImageView && it.tag==video.path && it.drawable is BitmapDrawable}};assertNotNull(row);val ready=System.nanoTime()+5000000000;while(find(decor){it is ImageView && it.tag==portrait.path && it.drawable is BitmapDrawable}==null && System.nanoTime()<ready){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();layout()};assertNotNull(find(decor){it is ImageView && it.tag==portrait.path && it.drawable is BitmapDrawable});val out=File("build/interface-preview/Files-compact-mixed-list.png");out.parentFile!!.mkdirs();val bmp=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(bmp));out.outputStream().use{bmp.compress(Bitmap.CompressFormat.PNG,100,it)}
   app.getSharedPreferences("files-manager",0).edit().putBoolean("grid",true).commit();controller.recreate();val gridDecor=controller.get().window.decorView
   val gridReady=System.nanoTime()+5000000000;while(find(gridDecor){it is ImageView && it.tag==portrait.path && it.drawable is BitmapDrawable}==null && System.nanoTime()<gridReady){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle();gridDecor.forceLayout();gridDecor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));gridDecor.layout(0,0,720,1480)}
   val gridBitmap=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);gridDecor.draw(Canvas(gridBitmap));File(out.parentFile,"Files-compact-mixed-grid.png").outputStream().use{gridBitmap.compress(Bitmap.CompressFormat.PNG,100,it)}

  }finally{controller.pause().stop().destroy();video.delete();portrait.delete();photo.delete();document.delete();archive.delete();other.delete();folder.deleteRecursively()}
 }
}
