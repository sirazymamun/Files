package com.example.httpsserver
import android.Manifest
import android.app.Activity
import android.app.Application
import android.graphics.Bitmap
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowEnvironment
import java.io.File
import java.nio.file.Files
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24,34],shadows=[GrantedStorageEnvironment::class])
class NativeFilesTest {
 private fun texts(view:View):List<String> = (if(view is TextView)listOf(view.text.toString())else emptyList()) + if(view is ViewGroup)(0 until view.childCount).flatMap{texts(view.getChildAt(it))}else emptyList()
 private fun allow(){val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);Environment.getExternalStorageDirectory().mkdirs()}
 @Test fun localHomeStartsWithoutServer(){
  allow();val controller=Robolectric.buildActivity(FilesActivity::class.java).setup()
  val labels=texts(controller.get().window.decorView)
  assertTrue(labels.contains("Files"));assertTrue(labels.contains("Main storage"));assertTrue(labels.contains("Images"));assertTrue(labels.contains("Server"))
  assertFalse(ServerService.running);controller.pause().stop().destroy()
 }
 @Test @Config(sdk=[24]) fun deniedPermissionDrawerOnlyOffersSafeActions(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).denyPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE)
  val controller=Robolectric.buildActivity(FilesActivity::class.java).setup();val activity=controller.get()
  fun menu(v:View):View?{if(v.contentDescription?.toString()=="Open menu")return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{menu(v.getChildAt(it))}else null}
  try{menu(activity.window.decorView)!!.performClick();val labels=texts(activity.window.decorView);assertTrue(labels.contains("Allow storage access"));assertFalse(labels.contains("Images"))}finally{controller.pause().stop().destroy()}
 }
 @Test fun imagePropertiesKeepOriginalResolutionAndSeconds(){
  val root=Files.createTempDirectory("files-details").toFile()
  try{val image=File(root,"image.png");image.outputStream().use{Bitmap.createBitmap(31,17,Bitmap.Config.ARGB_8888).compress(Bitmap.CompressFormat.PNG,100,it)};image.setLastModified(1700000000000)
   val info=FileDetails.describe(root,image);assertEquals("31 × 17 px",info["Resolution (width × height)"]);assertTrue(info["Modified"]!!.matches(Regex("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}")));assertTrue(info["Size"]!!.contains("bytes"));assertEquals(image.path,info["Path"])
  }finally{root.deleteRecursively()}
 }
 @Test fun previewDeleteNeedsNoConfirmationAndKeepsNextFile(){
  allow();val app=RuntimeEnvironment.getApplication();val root=Files.createTempDirectory("files-preview").toFile();val a=File(root,"a.txt").apply{writeText("first")};val b=File(root,"b.txt").apply{writeText("second")}
  app.getSharedPreferences("files-preview",0).edit().putString("root",root.path).putString("file",a.path).putString("siblings",org.json.JSONArray(listOf(a.path,b.path)).toString()).commit()
  val controller=Robolectric.buildActivity(FilesPreviewActivity::class.java).setup();val activity=controller.get()
  fun find(v:View):View?{if(v is TextView && v.text.toString()=="Delete")return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it))}else null}
  try{find(activity.window.decorView)!!.performClick();val deadline=System.currentTimeMillis()+5000;while((a.exists() || !texts(activity.window.decorView).contains("b.txt")) && System.currentTimeMillis()<deadline){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle()};shadowOf(Looper.getMainLooper()).idle();assertFalse(a.exists());assertTrue(b.exists());assertTrue(texts(activity.window.decorView).contains("b.txt"))}finally{controller.pause().stop().destroy();root.deleteRecursively()}
 }
}

@org.robolectric.annotation.Implements(Environment::class)
class GrantedStorageEnvironment: ShadowEnvironment(){
 companion object {
  @JvmStatic @org.robolectric.annotation.Implementation(minSdk=30)
  fun isExternalStorageManager() = true
 }
}
