package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.IOException
import java.nio.file.Files
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34])
class NotesCloudSyncTest{
 private class Cloud:NotesRemote{val events=linkedMapOf<String,NoteEvent>();var fail=false;override fun read()=events.values.toList();override fun write(event:NoteEvent){if(fail)throw IOException("offline");events[event.rev]=event}}
 private class Device(val root:File,val state:File,val cloud:Cloud){val store=NotesStore(root);fun sync()=NotesCloudSync(store,state,cloud).sync();fun notes()=store.list().associate{it.title to store.read(it.file).text};fun edit(title:String,body:String){val note=store.list().first{it.title==title};store.save(store.read(note.file),title,body)}}
 private fun fixture(run:(Device,Device,Cloud)->Unit){val temp=Files.createTempDirectory("notes-cloud").toFile();val cloud=Cloud();try{val a=Device(File(temp,"a").apply{mkdir()},File(temp,"state-a.json"),cloud);val b=Device(File(temp,"b").apply{mkdir()},File(temp,"state-b.json"),cloud);run(a,b,cloud)}finally{temp.deleteRecursively()}}
 @Test fun createdEditedAndRenamedNotesConvergeAcrossDevices()=fixture{a,b,_->a.store.save(null,"বাংলা","প্রথম");a.sync();b.sync();assertEquals(a.notes(),b.notes());b.edit("বাংলা","দ্বিতীয়");b.sync();a.sync();assertEquals("দ্বিতীয়",a.notes()["বাংলা"]);val note=a.store.read(a.store.list().single().file);a.store.rename(note,"Renamed");a.sync();b.sync();assertEquals(a.notes(),b.notes());assertEquals(setOf("Renamed"),b.notes().keys)}
 @Test fun concurrentEditsPreserveBothBodiesAndSettle()=fixture{a,b,cloud->a.store.save(null,"Plan","start");a.sync();b.sync();a.edit("Plan","device A");b.edit("Plan","device B");a.sync();b.sync();a.sync();b.sync();assertEquals(setOf("device A","device B"),a.notes().values.toSet());assertEquals(a.notes(),b.notes());val count=cloud.events.size;a.sync();b.sync();assertEquals(count,cloud.events.size)}
 @Test fun cloudDeletionMovesLocalCopyToRecycleBin()=fixture{a,b,_->a.store.save(null,"Keep","text");a.sync();b.sync();val n=a.store.read(a.store.list().single().file);a.store.delete(n);a.sync();b.sync();assertTrue(b.notes().isEmpty());assertEquals(1,TrashStore(b.root,true).entries().size)}
 @Test fun simultaneousDeleteAndEditKeepsEditedText()=fixture{a,b,_->a.store.save(null,"Note","before");a.sync();b.sync();a.store.delete(a.store.read(a.store.list().single().file));b.edit("Note","important edit");a.sync();b.sync();a.sync();assertEquals("important edit",a.notes()["Note"]);assertEquals(a.notes(),b.notes())}
 @Test fun pendingOfflineChangeSurvivesRetryWithoutDuplicates()=fixture{a,b,cloud->a.store.save(null,"Offline","saved");cloud.fail=true;assertThrows(IOException::class.java){a.sync()};assertEquals("saved",a.notes()["Offline"]);cloud.fail=false;a.sync();b.sync();assertEquals(1,cloud.events.size);assertEquals(a.notes(),b.notes())}
 @Test fun identicalExistingLocalNoteIsAdoptedAfterReinstall()=fixture{a,b,cloud->a.store.save(null,"Same","value");a.sync();b.store.save(null,"Same","value");b.sync();assertEquals(1,cloud.events.size);assertEquals(1,b.notes().size)}
 @Test fun sameTitleDifferentNewNotesNeverOverwrite()=fixture{a,b,_->a.store.save(null,"Title","first");b.store.save(null,"Title","second");a.sync();b.sync();a.sync();assertEquals(setOf("first","second"),a.notes().values.toSet());assertEquals(setOf("first","second"),b.notes().values.toSet())}
 @Test fun restoredDeletedNoteIsSyncedAgain()=fixture{a,b,_->a.store.save(null,"Restore","value");a.sync();b.sync();val entry=a.store.delete(a.store.read(a.store.list().single().file));a.sync();b.sync();a.store.restore(entry);a.sync();b.sync();assertEquals("value",b.notes()["Restore"])}
}
