package com.example.httpsserver
import android.app.job.JobScheduler
import android.app.job.JobInfo
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34])
class NotesSchedulingTest{
 @Test fun notesSyncRequiresOptInAndOnlySchedulesNetworkJobs(){val app=RuntimeEnvironment.getApplication();val scheduler=app.getSystemService(JobScheduler::class.java);NotesSync.disable(app);NotesSync.request(app);assertTrue(scheduler.allPendingJobs.isEmpty());NotesSync.enable(app,"demo@example.test");val jobs=scheduler.allPendingJobs;assertEquals(2,jobs.size);assertTrue(jobs.all{it.networkType==JobInfo.NETWORK_TYPE_ANY});val periodic=jobs.single{it.isPeriodic};assertTrue(periodic.intervalMillis>=15*60*1000L);assertTrue(periodic.isPersisted);NotesSync.request(app);assertEquals(2,scheduler.allPendingJobs.size);NotesSync.disable(app);assertFalse(NotesSync.enabled(app));assertTrue(scheduler.allPendingJobs.isEmpty())}
}
