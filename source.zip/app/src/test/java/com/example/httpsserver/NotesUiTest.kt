package com.example.httpsserver
import android.Manifest
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.*
import org.robolectric.shadows.ShadowAlertDialog
import java.io.File
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[24,34],shadows=[GrantedStorageEnvironment::class])
class NotesUiTest{
 private fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
 @Test fun createEditDeleteUndoAndDraftRecovery(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().apply{mkdirs()};val c=Robolectric.buildActivity(NotesActivity::class.java).setup().visible();var activity=c.get();var decor=activity.window.decorView
  fun pump(){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle()}
  fun tap(text:String){find(decor){it is android.widget.Button && it.text.toString()==text}!!.performClick();shadowOf(Looper.getMainLooper()).idle()}
  fun edit(hint:String,value:String){(find(decor){it is EditText && it.hint?.toString()==hint} as EditText).setText(value)}
  fun waitText(value:String){val end=System.nanoTime()+5000000000;while(find(decor){it is TextView && it !is EditText && it.text.toString()==value}==null && System.nanoTime()<end)pump();assertNotNull(value,find(decor){it is TextView && it !is EditText && it.text.toString()==value})}
  try{tap("New note");edit("Note title","Test note");edit("Write your note…","বাংলা note body");tap("Save");waitText("Test note");assertEquals("বাংলা note body",File(root,"Notes/Test note.txt").readText())
   val list=find(decor){it is android.widget.ListView} as android.widget.ListView;list.onItemClickListener!!.onItemClick(list,list.getChildAt(0),0,0);val end=System.nanoTime()+5000000000;while(find(decor){it is EditText && it.hint?.toString()=="Write your note…"}==null && System.nanoTime()<end)pump();edit("Write your note…","draft recovered");c.recreate();activity=c.get();decor=activity.window.decorView;assertEquals("draft recovered",(find(decor){it is EditText && it.hint?.toString()=="Write your note…"} as EditText).text.toString());tap("Save");waitText("Test note")
   val updated=find(decor){it is android.widget.ListView} as android.widget.ListView;updated.onItemLongClickListener!!.onItemLongClick(updated,updated.getChildAt(0),0,0);val dialog=ShadowAlertDialog.getLatestAlertDialog();dialog.listView.performItemClick(dialog.listView.adapter.getView(4,null,dialog.listView),4,4);shadowOf(Looper.getMainLooper()).idle();waitText("Undo delete");assertFalse(File(root,"Notes/Test note.txt").exists());tap("Undo delete");waitText("Test note");assertEquals("draft recovered",File(root,"Notes/Test note.txt").readText())
  }finally{c.pause().stop().destroy();File(root,"Notes").deleteRecursively()}
 }
 @Test @Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi") @GraphicsMode(GraphicsMode.Mode.NATIVE)
 fun homeFooterAndNotesAreRendered(){
  val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);Environment.getExternalStorageDirectory().mkdirs();val c=Robolectric.buildActivity(FilesActivity::class.java).setup().visible();val decor=c.get().window.decorView
  try{shadowOf(Looper.getMainLooper()).idle();decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480);assertNotNull(find(decor){it.contentDescription?.toString()=="Notes"});val footer=find(decor){it is TextView && it.text.toString()=="A netcolink product"} as TextView;assertEquals(android.view.Gravity.CENTER,footer.gravity);val out=File("build/interface-preview/Files-home-notes.png");out.parentFile!!.mkdirs();val bitmap=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(bitmap));out.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}}finally{c.pause().stop().destroy()}
 }
}
