package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test

class NumericPasswordTest {
    @Test fun generatedPasswordsHaveExactlySixAsciiDigits() {
        repeat(1000) {
            val password = NumericPassword.generate()
            assertEquals(6, password.length)
            assertTrue(password.all { it in '0'..'9' })
        }
    }
    @Test fun validatesLeadingZerosAndRejectsOldAlphabeticPasswords() {
        assertTrue(NumericPassword.isValid("012345"))
        assertTrue(NumericPassword.isValid("000000"))
        for (value in listOf(null, "", "12345", "1234567", "12345678", "abc123", "１２３４５６", "১২৩৪৫৬")) {
            assertFalse(value, NumericPassword.isValid(value))
        }
    }
    @Test fun copyBlockIncludesAddressAndPasswordOnly() {
        val text = ConnectionInfo.text("https://10.190.98.65:8443", "012345")
        assertEquals("https://10.190.98.65:8443\nPassword: 012345", text)
        assertEquals(2, text.lines().size)
    }
    @Test fun bothFullAddressesAndPasswordAreCopiedTogether() {
        val block = ConnectionInfo.addresses("https://192.168.0.120:8443", "https://tv2u-server.netcolink.com:8443")
        assertEquals("IP: https://192.168.0.120:8443\nDomain: https://tv2u-server.netcolink.com:8443", block)
        assertEquals("$block\nPassword: 012345", ConnectionInfo.text(block, "012345"))
        assertEquals(3, ConnectionInfo.text(block,"012345").lines().size)
    }

}
