package com.example.httpsserver
import android.Manifest
import android.content.Intent
import android.content.pm.*
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File
@RunWith(RobolectricTestRunner::class) @Config(sdk=[24,34],shadows=[GrantedStorageEnvironment::class])
class OfficePreviewTest{
 private fun find(v:View,text:String):View?{if(v is TextView && v.text.toString()==text)return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),text)}else null}
 private fun fixture(ext:String,run:(android.app.Application,File)->Unit){val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().canonicalFile.apply{mkdirs()};val f=File(root,"office-test.$ext").apply{writeText("fixture")};app.getSharedPreferences("files-preview",0).edit().putString("root",root.path).putString("file",f.path).putString("siblings",JSONArray().put(f.path).toString()).apply();try{run(app,f)}finally{f.delete()}}
 @Test fun xlsxDelegatesWithCorrectMimeAndReadOnlyUriGrant()=fixture("xlsx"){app,file->val uri=FileProvider.getUriForFile(app,"${app.packageName}.files",file);val view=Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");val info=ResolveInfo().apply{activityInfo=ActivityInfo().apply{packageName="example.viewer";name="Viewer";applicationInfo=ApplicationInfo().apply{packageName="example.viewer"}};isDefault=true};shadowOf(app.packageManager).addResolveInfoForIntent(view,info);val c=Robolectric.buildActivity(FilesPreviewActivity::class.java).setup();try{val chooser=shadowOf(c.get()).nextStartedActivity;assertEquals(Intent.ACTION_CHOOSER,chooser.action);val request=chooser.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)!!;assertEquals(view.type,request.type);assertEquals(uri,request.data);assertTrue(request.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION!=0);assertEquals(0,request.flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION);assertTrue(c.get().isFinishing)}finally{c.pause().stop().destroy()}}
 @Test fun missingWordViewerShowsSpecificTypeInsteadOfGenericBlankPreview()=fixture("doc"){_,_->val c=Robolectric.buildActivity(FilesPreviewActivity::class.java).setup();try{assertNotNull(find(c.get().window.decorView,"Word document"));assertNull(find(c.get().window.decorView,"No built-in preview for this format."))}finally{c.pause().stop().destroy()}}
}
