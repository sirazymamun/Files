package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test

class PasswordSessionsTest {
    @Test fun correctPasswordCreatesRandomSessionWithoutUsername() {
        val auth=PasswordSessions();val token=auth.login("client","012345","012345")!!
        assertEquals(64,token.length);assertTrue(auth.valid(token,"012345"));assertFalse(auth.valid(null,"012345"))
        assertNotEquals(token,auth.login("client","012345","012345"))
    }
    @Test fun wrongMalformedOrOldPasswordsCannotLogin() {
        val auth=PasswordSessions()
        for(pw in listOf("12345678","abcdef","１２３４５６","654321"))assertNull(auth.login(pw,pw,"012345"))
        assertFalse(auth.valid("forged-token","012345"))
    }
    @Test fun repeatedAttemptsAreLimitedAndRecover() {
        var time=1000L;val auth=PasswordSessions { time }
        repeat(5){assertNull(auth.login("same","999999","012345"))}
        assertTrue(auth.blocked("same"));assertNull(auth.login("same","012345","012345"))
        assertNotNull(auth.login("other","012345","012345"))
        time+=60_001;assertFalse(auth.blocked("same"));assertNotNull(auth.login("same","012345","012345"))
    }
    @Test fun sessionExpiresAfterTwelveHours() {
        var time=1000L;val auth=PasswordSessions{time};val token=auth.login("a","012345","012345")!!
        time+=12*60*60*1000L;assertFalse(auth.valid(token,"012345"))
    }
    @Test fun logoutAndPasswordChangeRejectExistingSession() {
        val auth=PasswordSessions();val token=auth.login("a","012345","012345")!!
        assertFalse(auth.valid(token,"123456"));auth.logout(token);assertFalse(auth.valid(token,"012345"))
    }
    @Test fun sessionCacheIsBounded() {
        val auth=PasswordSessions();val first=auth.login("a","012345","012345")!!
        repeat(64){assertNotNull(auth.login("a","012345","012345"))}
        assertFalse(auth.valid(first,"012345"))
    }
}
