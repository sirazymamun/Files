package com.example.httpsserver
import android.Manifest
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.*
import java.io.File
@RunWith(RobolectricTestRunner::class) @Config(sdk=[34],qualifiers="w360dp-h740dp-xhdpi",shadows=[GrantedStorageEnvironment::class]) @GraphicsMode(GraphicsMode.Mode.NATIVE)
class PreviewToolbarTest{
 private fun find(v:View,p:(View)->Boolean):View?{if(p(v))return v;return if(v is ViewGroup)(0 until v.childCount).firstNotNullOfOrNull{find(v.getChildAt(it),p)}else null}
 @Test fun pdfUsesClearHeaderAndSingleCompactActionRow(){val app=RuntimeEnvironment.getApplication();shadowOf(app).grantPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,Manifest.permission.WRITE_EXTERNAL_STORAGE);val root=Environment.getExternalStorageDirectory().canonicalFile.apply{mkdirs()};val file=File(root,"Sample cost report with a long filename.pdf");javaClass.getResourceAsStream("/fixtures/preview.pdf")!!.use{input->file.outputStream().use{input.copyTo(it)}}
  app.getSharedPreferences("files-preview",0).edit().putString("root",root.path).putString("file",file.path).putString("siblings",JSONArray().put(file.path).toString()).apply();val c=Robolectric.buildActivity(FilesPreviewActivity::class.java).setup().visible()
  try{val decor=c.get().window.decorView;val menu=find(decor){it.contentDescription?.toString()=="More options"};assertTrue(menu is ImageButton);val labels=listOf("Previous","Properties","Open with","Delete","Next");val views=labels.map{label->find(decor){it is Button && it.text.toString()==label}!!};assertEquals(1,views.map{it.parent}.distinct().size);assertNotNull(find(decor){it is Button && it.text.toString()=="Page ›"});val end=System.nanoTime()+3000000000;while(System.nanoTime()<end && find(decor){it is TextView && it.text.toString()=="1 / 2"}==null){Thread.sleep(20);shadowOf(Looper.getMainLooper()).idle()};/* Robolectric does not decode PdfRenderer here. Inject a raster of our sample PDF only for toolbar/layout visual QA. */
val preview=find(decor){it is ImageView && it !is ImageButton} as ImageView;javaClass.getResourceAsStream("/fixtures/preview-page.png")!!.use{preview.setImageBitmap(BitmapFactory.decodeStream(it))};(find(decor){it is TextView && it.text.toString().startsWith("PDF preview unavailable")} as? TextView)?.text="1 / 1 · Sample PDF";(find(decor){it is TextView && it.parent is LinearLayout && (it as? TextView)?.text.toString()==""} as? TextView)?.text="1 / 2"
;decor.measure(View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1480,View.MeasureSpec.EXACTLY));decor.layout(0,0,720,1480);val out=File("build/interface-preview/Files-pdf-preview.png");out.parentFile!!.mkdirs();val b=Bitmap.createBitmap(720,1480,Bitmap.Config.ARGB_8888);decor.draw(Canvas(b));out.outputStream().use{b.compress(Bitmap.CompressFormat.PNG,100,it)}}finally{c.pause().stop().destroy();file.delete()}
 }
}
