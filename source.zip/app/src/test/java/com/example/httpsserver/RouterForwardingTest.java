package com.example.httpsserver;
import org.junit.Test;
import static org.junit.Assert.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.concurrent.atomic.AtomicReference;

public class RouterForwardingTest {
    @Test public void portsAreBounded(){assertEquals(443,RouterForwarding.port("443"));assertEquals(65535,RouterForwarding.port("65535"));for(String s:new String[]{"0","65536","-1","443;bad","","9999999999"})try{RouterForwarding.port(s);fail(s);}catch(IllegalArgumentException expected){}}
    @Test public void excludesPrivateSharedAndReserved(){for(String ip:new String[]{"10.0.0.1","192.168.0.1","172.31.1.1","100.64.0.1","100.127.255.1","127.0.0.1","169.254.1.1","224.1.2.3","203.0.113.1","1.2.3.999","999999999.2.3.4","abc"})assertFalse(ip,RouterForwarding.publicIPv4(ip));assertTrue(RouterForwarding.publicIPv4("8.8.8.8"));}
    @Test public void rejectsXmlEntities()throws Exception{try{RouterForwarding.xml("<!DOCTYPE x [<!ENTITY a SYSTEM 'file:///etc/passwd'>]><x>&a;</x>");fail();}catch(java.io.IOException expected){}}
    @Test public void namespacedXmlWorks()throws Exception{assertEquals("8.8.8.8",RouterForwarding.value(RouterForwarding.xml("<s:r xmlns:s='test'><NewExternalIPAddress>8.8.8.8</NewExternalIPAddress></s:r>"),"NewExternalIPAddress"));}
    @Test public void onlyLocalRouterUrls()throws Exception{RouterForwarding.Gateway g=new RouterForwarding.Gateway(new URL("http://8.8.8.8/control"),"urn:schemas-upnp-org:service:WANIPConnection:1","192.168.1.2");try{RouterForwarding.externalIp(g);fail();}catch(java.io.IOException expected){assertTrue(expected.getMessage().contains("local IPv4"));}}
    @Test public void routerAddVerifyRemoveAndConflict()throws Exception{
        final boolean[] exists={false};final String[] client={"192.168.1.2"};final int[] mutations={0};
        ServerSocket server=new ServerSocket(0,20,InetAddress.getByName("127.0.0.1"));
        AtomicReference<Throwable> failure=new AtomicReference<>();
        Thread responder=new Thread(()->{while(!server.isClosed())try(Socket socket=server.accept()) {
            BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));
            String line=in.readLine(),action="";int length=0;
            while((line=in.readLine())!=null && !line.isEmpty()) {
                if(line.toLowerCase().startsWith("soapaction:"))action=line.substring(11).trim();
                if(line.toLowerCase().startsWith("content-length:"))length=Integer.parseInt(line.substring(15).trim());
            }
            char[] content=new char[length];int total=0;while(total<length){int n=in.read(content,total,length-total);if(n<0)break;total+=n;}
            String body=new String(content);String response="<r/>";int status=200;
            if(action.contains("GetExternalIPAddress"))response="<r><NewExternalIPAddress>8.8.8.8</NewExternalIPAddress></r>";
            else if(action.contains("GetSpecificPortMappingEntry")){
                if(!exists[0]){status=500;response="<r><errorCode>714</errorCode></r>";}
                else response="<r><NewInternalClient>"+client[0]+"</NewInternalClient><NewInternalPort>8443</NewInternalPort><NewPortMappingDescription>TV2U HTTPS</NewPortMappingDescription></r>";
            } else if(action.contains("AddPortMapping")){assertTrue(body.contains("<NewProtocol>TCP</NewProtocol>"));assertTrue(body.contains("<NewInternalPort>8443</NewInternalPort>"));exists[0]=true;mutations[0]++;}
            else if(action.contains("DeletePortMapping")){exists[0]=false;mutations[0]++;}
            byte[] b=response.getBytes(StandardCharsets.UTF_8);
            OutputStream out=socket.getOutputStream();out.write(("HTTP/1.1 "+status+" Result\r\nContent-Length: "+b.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));out.write(b);out.flush();
        }catch(Exception e){if(!server.isClosed())failure.set(e);}catch(AssertionError e){failure.set(e);}});
        responder.setDaemon(true);responder.start();try{
            RouterForwarding.Gateway g=new RouterForwarding.Gateway(new URL("http://127.0.0.1:"+server.getLocalPort()+"/control"),"urn:schemas-upnp-org:service:WANIPConnection:1","192.168.1.2");
            assertEquals("8.8.8.8",RouterForwarding.externalIp(g));RouterForwarding.add(g,9443,8443);assertTrue(exists[0]);assertEquals(1,mutations[0]);
            try{RouterForwarding.add(g,9443,8443);fail();}catch(java.io.IOException expected){}assertEquals(1,mutations[0]);
            client[0]="192.168.1.3";try{RouterForwarding.remove(g,9443,8443);fail();}catch(java.io.IOException expected){}assertEquals(1,mutations[0]);
            client[0]="192.168.1.2";RouterForwarding.remove(g,9443,8443);assertFalse(exists[0]);assertEquals(2,mutations[0]);
        }finally{server.close();responder.join(2000);}
        if(failure.get()!=null)throw new AssertionError(failure.get());
    }
}
