package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test

class ServerDomainTest {
    @Test fun normalizesEditableDomain() {
        assertEquals("tv2u-server.netcolink.com", ServerDomain.normalize(" TV2U-SERVER.netcolink.com. "))
    }
    @Test fun rejectsAddressesAndInvalidDomains() {
        for (value in listOf("", "localhost", "192.168.0.120", "https://test.example.com", "test.example.com:8443", "test.example.com/path", "a..example.com", "-bad.example.com", "*.example.com")) {
            assertTrue(value, runCatching { ServerDomain.normalize(value) }.isFailure)
        }
    }
    @Test fun oldCertificateCannotMatchNewDomain() {
        assertFalse(ServerDomain.matchesName("new.example.com", "old.example.com"))
        assertTrue(ServerDomain.matchesName("new.example.com", "new.example.com"))
        assertTrue(ServerDomain.matchesName("new.example.com", "*.example.com"))
        assertFalse(ServerDomain.matchesName("sub.new.example.com", "*.example.com"))
        assertFalse(ServerDomain.matchesName("example.com", "*.example.com"))
    }
}
