package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test

class StorageDecisionTest {
    @Test fun permissionRequiredForStart() {
        assertFalse(StorageDecision.canStart(false)); assertTrue(StorageDecision.canStart(true))
    }
    @Test fun revokeStopsSharing() {
        assertFalse(StorageDecision.canContinue(false)); assertTrue(StorageDecision.canContinue(true))
    }
}
