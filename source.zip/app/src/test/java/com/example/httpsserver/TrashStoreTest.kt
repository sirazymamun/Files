package com.example.httpsserver
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files
class TrashStoreTest{
 private fun run(block:(File)->Unit){val r=Files.createTempDirectory("files-trash").toFile();try{block(r)}finally{r.deleteRecursively()}}
 @Test fun deletedItemHiddenButRecoverable()=run{r->val file=File(r,"a.txt").apply{writeText("keep me")};val store=TrashStore(r);val entry=store.put(file);assertFalse(file.exists());assertEquals(1,store.entries().size);assertFalse(SharedFiles(r).visibleInListing(File(r,".FilesTrash")));assertEquals("keep me",store.restore(entry).readText());assertEquals(0,store.entries().size)}
 @Test fun restoreNeverOverwritesExistingFile()=run{r->val file=File(r,"a.txt").apply{writeText("old")};val store=TrashStore(r);val entry=store.put(file);file.writeText("new");val restored=store.restore(entry);assertEquals("new",file.readText());assertEquals("old",restored.readText());assertEquals("txt",restored.extension)}
 @Test fun folderRestoreAndPurge()=run{r->val folder=File(r,"Folder").apply{mkdir()};File(folder,"child.txt").writeText("x");val store=TrashStore(r);val entry=store.put(folder);assertFalse(folder.exists());val restored=store.restore(entry);assertEquals("x",File(restored,"child.txt").readText());val again=store.put(restored);store.purge(again);assertEquals(0,store.entries().size)}
 @Test fun hiddenMetadataPreservedAndPurgeNeverFollowsLinks()=run{r->val folder=File(r,"Folder").apply{mkdir()};File(folder,".secret").writeText("hidden");val store=TrashStore(r);val entry=store.put(folder);val restored=store.restore(entry);assertEquals("hidden",File(restored,".secret").readText());val outside=File(r,"outside.txt").apply{writeText("untouched")};Files.createSymbolicLink(File(restored,"link.txt").toPath(),outside.toPath());store.purge(store.put(restored));assertEquals("untouched",outside.readText())}
}
