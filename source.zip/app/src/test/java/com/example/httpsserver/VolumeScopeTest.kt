package com.example.httpsserver

import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicReference
import org.junit.Assert.*
import org.junit.Test

class VolumeScopeTest {
    private fun scope() = VolumeScope(listOf(StorageVolumeRoot("primary","Internal",File("/storage/emulated/0")), StorageVolumeRoot("storage1","SD",File("/storage/ABCD"))))
    @Test fun explicitVolumeAndClear() {
        val s=scope();assertEquals("primary",s.current.id)
        assertEquals("storage1",s.select("storage1")!!.id);assertEquals(File("/storage/ABCD"),s.current.folder)
        s.clear();assertEquals("primary",s.current.id)
    }
    @Test fun unknownVolumeNeverResolvesToRequestedPath() {
        val s=scope();assertNull(s.select("../../data"));assertNull(s.select("missing"))
    }
    @Test fun simultaneousRequestsKeepIndependentVolumes() {
        val s=scope();val selected=CountDownLatch(1);val finish=CountDownLatch(1);val result=AtomicReference<String>()
        val thread=Thread { s.select("storage1");selected.countDown();finish.await();result.set(s.current.id);s.clear() }
        thread.start();selected.await();s.select("primary");assertEquals("primary",s.current.id)
        finish.countDown();thread.join(2000);assertEquals("storage1",result.get())
    }
}
