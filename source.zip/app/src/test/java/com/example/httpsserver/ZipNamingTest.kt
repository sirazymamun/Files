package com.example.httpsserver

import org.junit.Assert.*
import org.junit.Test

class ZipNamingTest {
 @Test fun folderNameGivesSuggestedZipName(){assertEquals("Movies.zip",ZipNaming.suggest("Movies"))}
 @Test fun existingZipSuffixIsNotDuplicated(){assertEquals("Movies.zip",ZipNaming.suggest("Movies.zip"))}
 @Test fun emptyFolderNameFallsBackToFiles(){assertEquals("Files.zip",ZipNaming.suggest(""))}
 @Test fun duplicateNameSuggestsNewName(){assertEquals("Movies (1).zip",ZipNaming.alternative("Movies.zip"))}
 @Test fun unsafeZipNameIsRejected(){assertTrue(runCatching{ZipNaming.ensureExtension("../outside")}.isFailure)}
}
